# Paper เริ่มต้นสำหรับ UniFlow EV

ค้นหาและตรวจแหล่งข้อมูลวันที่ 15 ตุลาคม 2569

รายการนี้คัดจากความเกี่ยวข้องกับ Feedback เรื่องการเข้าเรียนทัน ข้อมูลความต้องการเดินทาง การจัดเส้นทางและตารางรถ ความคุ้มค่าของรถ และการจำลอง เป็นการคัดกรองจากบทคัดย่อ ข้อมูลบรรณานุกรม และเนื้อหาบางส่วนที่เข้าถึงได้ ยังไม่ใช่การอ่านและตรวจสมการหรือผลทดลองครบทุกบทความ

ลิงก์หลักใช้หน้าสำนักพิมพ์ คลังบทความของผู้เขียนหรือมหาวิทยาลัย และเว็บไซต์ผู้พัฒนาเครื่องมือ บางเว็บไซต์จำกัดการเปิดฉบับเต็ม จึงไม่ถือว่าการมีลิงก์หมายถึงตรวจฉบับเต็มสำเร็จแล้ว

## ลำดับอ่านที่แนะนำ

1. อ่าน P7 เพื่อจัดหมวดปัญหาและขอบเขต
2. อ่าน P1 เพื่อเชื่อมการถึงทันเวลาเรียนกับ Routing/Scheduling
3. อ่าน P2 เพื่อดูกรณีรถ EV มหาวิทยาลัย ความถี่ ความจุ และต้นทุน
4. อ่าน P3 และ P5 เพื่อศึกษาวิธี Optimization ที่ต่อยอดจาก SA ได้
5. อ่าน P6 เพื่อทบทวนสมมติฐานเวลารอและพฤติกรรมมาถึงป้าย
6. อ่าน P4 และ P10 เพื่อออกแบบการจำลองและการประเมิน
7. อ่าน P8 และ P9 เพื่อดูแนวทางใหม่และการขยายไปสู่ข้อจำกัดรถไฟฟ้า

## P1. การถึงทันเวลาเรียนและการจัดรถในมหาวิทยาลัย

**A smart school routing and scheduling problem for the new normalcy**

- ผู้เขียน: Jenny Díaz-Ramírez, Carlos Mario Leal-Garza และ Carlos Gómez-Acosta
- ปี/แหล่งตีพิมพ์: 2022, Computers & Industrial Engineering, 168, 108101
- DOI: [10.1016/j.cie.2022.108101](https://doi.org/10.1016/j.cie.2022.108101)
- แหล่งข้อมูล: [สำนักพิมพ์](https://www.sciencedirect.com/science/article/pii/S0360835222001711), [PubMed](https://pubmed.ncbi.nlm.nih.gov/36569989/), [ฉบับบทความใน PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC9758004/)

เนื้อหา: จัดเส้นทางและตารางรถในบริบทมหาวิทยาลัยที่มีเวลาเข้าเรียนหลายช่วง ภายใต้ความจุและทรัพยากรจำกัด ใช้แนวทางแยกการสร้างเส้นทางกับการจัดตาราง แล้วต่อยอดการปรับเส้นทางตามความต้องการ มีการเปรียบเทียบวิธีแก้ปัญหา รวมถึง Tabu Search ที่ปรับสำหรับโจทย์นี้

การนำมาใช้ที่เสนอ: นิยามการถึงทันเวลาเรียน การแยกปัญหาวางแผนล่วงหน้ากับปรับระหว่างบริการ และการกำหนด Input ต้นทาง–ปลายทางพร้อมเวลาที่ต้องถึง

ข้อแตกต่าง: มีเงื่อนไขจาก COVID-19 การรับนักศึกษาต่างเวลาเรียนร่วมคัน และการข้ามป้าย ต้องเลือกเฉพาะส่วนที่ตรงกับขอบเขต UniFlow EV

## P2. ตารางรถ EV ความถี่ ความจุ และต้นทุน

**Enhancing Electric Shuttle Bus Efficiency: A Case Study on Timetabling and Scheduling Optimization**

- ผู้เขียน: Kayhan Alamatsaz, Frédéric Quesnel และ Ursula Eicker
- ปี/แหล่งตีพิมพ์: 2024, Energies, 17(13), 3149
- DOI: [10.3390/en17133149](https://doi.org/10.3390/en17133149)
- แหล่งข้อมูล: [บทความสำนักพิมพ์](https://www.mdpi.com/1996-1073/17/13/3149), [รายการผลงาน Concordia University](https://www.concordia.ca/research/chairs/smart-cities/publications.html)

เนื้อหา: ศึกษารถรับส่งไฟฟ้าของ Concordia University เชื่อมการกำหนด Headway กับการจัดตารางรถ โดยคำนึงถึงเวลารอ ที่นั่ง และต้นทุน ใช้แบบจำลอง MILP สำหรับการจัดตาราง และพิจารณาข้อจำกัดการชาร์จ

การนำมาใช้ที่เสนอ: ออกแบบตัวชี้วัดความคุ้มค่ารถและความจุ รวมถึงอธิบายว่าการเปลี่ยนความถี่ส่งผลต่อผู้โดยสารและผู้ให้บริการอย่างไร

ข้อแตกต่าง: มีรายละเอียดการชาร์จและต้นทุนที่ UniFlow EV ยังต้องเก็บข้อมูลเพิ่ม จึงไม่ควรนำค่าต้นทุนหรือข้อจำกัดมาใช้โดยตรง

## P3. จัดเส้นทางและความถี่ร่วมกันด้วยหลายเป้าหมาย

**Approximate multi-objective optimization for integrated bus route design and service frequency setting**

- ผู้เขียน: Zeke Ahern, Alexander Paz และ Paul Corry
- ปี/แหล่งตีพิมพ์: 2022, Transportation Research Part B: Methodological, 155, 1–25
- DOI: [10.1016/j.trb.2021.10.007](https://doi.org/10.1016/j.trb.2021.10.007)
- แหล่งข้อมูล: [บทความสำนักพิมพ์](https://www.sciencedirect.com/science/article/pii/S0191261521001910)

เนื้อหา: เชื่อมการออกแบบเครือข่ายเส้นทาง ความถี่ และการเลือกเดินทางของผู้โดยสาร ใช้ Multi-objective Simulated Annealing เพื่อพิจารณาเป้าหมายของผู้โดยสารและผู้ให้บริการร่วมกัน

การนำมาใช้ที่เสนอ: ต่อยอด SA เดิมของโปรเจกต์ และออกแบบการเปรียบเทียบระหว่างคุณภาพบริการกับการใช้ทรัพยากร โดยตรวจเรื่องความจุและการกระจายผู้โดยสารควบคู่กัน

ข้อแตกต่าง: เป็นเครือข่ายขนส่งทั่วไป ไม่ได้กำหนดการเข้าเรียนทันเป็นเป้าหมายเฉพาะ ต้องเพิ่มเงื่อนไขเวลาเรียนของเราเอง

## P4. เชื่อม Optimization กับ Simulation ในมหาวิทยาลัย

**An Optimization-and-Simulation Framework for Redesigning University Campus Bus System with Social Distancing**

- ผู้เขียน: Gongyu Chen, Xinyu Fei, Huiwen Jia, Xian Yu และ Siqian Shen
- รุ่นที่อ้างในรายการนี้: arXiv Preprint เริ่มเผยแพร่ 2020 และปรับปรุงเป็น v3 ในปี 2021
- ลิงก์: [arXiv:2010.10630](https://arxiv.org/abs/2010.10630), [หน้าผลงาน UC Berkeley IEOR](https://ieor.berkeley.edu/publication/an-optimization-and-simulation-framework-for-redesigning-university-campus-bus-system-with-social-distancing/)

เนื้อหา: ใช้ Mixed-integer Programming และ Simulation ออกแบบเส้นทางกับตารางรถของ University of Michigan อาศัยข้อมูลกิจกรรมนักศึกษา และประเมินหลายสถานการณ์ เช่น ความต้องการช่วงพีคและรถเสีย

การนำมาใช้ที่เสนอ: แยกขั้นค้นหาแผนออกจากขั้นตรวจแผนด้วย Simulation และออกแบบสถานการณ์ทดสอบความทนทานของแผนเดินรถ

ข้อแตกต่าง: มีเป้าหมายด้าน Social distancing ระบุรายการนี้เป็น Preprint ที่ตรวจพบ ไม่ถือว่า arXiv เป็นการรับรอง Peer review และยังไม่ได้ยืนยันฉบับวารสารของงานนี้ในการค้นครั้งนี้

## P5. ลดจำนวนรถและระยะทางด้วย SA กับ Local Search

**Exact and Metaheuristic Approaches for a Bi-Objective School Bus Scheduling Problem**

- ผู้เขียน: Xiaopan Chen, Yunfeng Kong, Lanxue Dang, Yane Hou และ Xinyue Ye
- ปี/แหล่งตีพิมพ์: 2015, PLOS ONE, 10(7), e0132600
- DOI/บทความ: [10.1371/journal.pone.0132600](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0132600)
- เอกสารแก้ไขปี 2016: [Correction](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0153614)

เนื้อหา: จัดตารางให้บริการเที่ยวรถที่กำหนดภายใน Time windows เปรียบเทียบ MIP กับแนวทาง SA ร่วมกับ Local Search โดยมีเป้าหมายลดจำนวนรถและระยะทางรวม

การนำมาใช้ที่เสนอ: ศึกษาการแทนคำตอบ การสร้างคำตอบข้างเคียง และการเปรียบเทียบ Metaheuristic กับแบบจำลองคณิตศาสตร์ในกรณีเล็ก

ข้อแตกต่าง: มีเที่ยวรถเป็นข้อมูลตั้งต้นและเป็นบริบทหลายโรงเรียน ต้องแยกจากการออกแบบเส้นทางใหม่ รายงานนี้มี Correction จึงต้องอ่านเอกสารแก้ไขก่อนอ้างผลตัวเลข

## P6. เวลารอ Headway และพฤติกรรมผู้โดยสาร

**Waiting time and headway modelling for urban transit systems – a critical review and proposed approach**

- ผู้เขียน: Mohammad Ansari Esfeh, S. C. Wirasinghe, Saeid Saidi และ Lina Kattan
- ปี/แหล่งตีพิมพ์: 2021, Transport Reviews, 41(2), 141–163; เผยแพร่ออนไลน์ครั้งแรกปี 2020
- DOI/บทความ: [10.1080/01441647.2020.1806942](https://www.tandfonline.com/doi/full/10.1080/01441647.2020.1806942)

เนื้อหา: ทบทวนแบบจำลองเวลารอ โดยพิจารณารูปแบบบริการและความแตกต่างระหว่างผู้โดยสารที่วางแผนการเดินทางกับผู้ที่มาถึงป้ายแบบไม่วางแผน

การนำมาใช้ที่เสนอ: ทบทวนสมมติฐานเวลามาถึงป้ายของนักศึกษาที่มีเวลาเรียนกำหนด และตรวจว่าความสัมพันธ์ระหว่างเวลารอกับ Headway ที่นำมาใช้เหมาะกับบริการของเราหรือไม่

ข้อแตกต่าง: ให้ฐานคิดเรื่องเวลารอ ไม่ใช่ Algorithm สำหรับสร้างตารางรถโดยตรง

## P7. Review เพื่อจัดขอบเขตปัญหา

**The school bus routing problem: A review**

- ผู้เขียน: Junhyuk Park และ Byung-In Kim
- ปี/แหล่งตีพิมพ์: 2010, European Journal of Operational Research, 202(2), 311–319
- DOI: [10.1016/j.ejor.2009.05.017](https://doi.org/10.1016/j.ejor.2009.05.017)
- แหล่งข้อมูล: [บทความสำนักพิมพ์](https://www.sciencedirect.com/science/article/pii/S037722170900349X)

เนื้อหา: ทบทวนการเตรียมข้อมูล การเลือกป้าย การสร้างเส้นทาง การปรับเวลาเริ่มเรียน และการจัดตารางรถ รวมถึงข้อจำกัดความจุ เวลาบนรถ และกรอบเวลาถึงโรงเรียน

การนำมาใช้ที่เสนอ: จัดหมวด Literature review และระบุว่า UniFlow EV แก้ปัญหาย่อยใด โดยเฉพาะแยก Routing, Timetabling และ Vehicle scheduling

ข้อแตกต่าง: เป็นงานพื้นฐานเก่า ควรใช้ร่วมกับงานใหม่ และไม่ถือว่าการปรับเวลาเรียนอยู่ในขอบเขตของ UniFlow EV โดยอัตโนมัติ

## P8. งานใหม่เรื่องรถรับส่งมหาวิทยาลัยและการไหลของนักศึกษา

**An optimization model for the university school bus routing problem**

- ผู้เขียน: Marco Antonio Sánchez-Carmona, J. Raymundo Marcial-Romero, Lourdes Loza-Hernandez และ J. A. Hernández-Servín
- ปี/แหล่งตีพิมพ์: 2026, Discover Vehicles, 2, Article 12; เผยแพร่ 2 พฤษภาคม 2026
- DOI/บทความ: [10.1007/s44465-026-00017-0](https://link.springer.com/article/10.1007/s44465-026-00017-0)

เนื้อหา: ใช้ DBSCAN และ Convex hull เตรียมป้ายและจุดตั้งต้น ก่อนสร้าง ILP ที่เชื่อม VRP กับ Maximum Flow เพื่อพิจารณาต้นทุนและจำนวนผู้โดยสาร พร้อมเวลาออกเดินทาง ใช้ COIN-OR Branch and Cut แก้แบบจำลอง

การนำมาใช้ที่เสนอ: ดูตัวอย่างเป้าหมายด้านจำนวนผู้โดยสารที่ขนส่งได้ ควบคู่กับต้นทุนเวลา และการเชื่อมข้อมูลกับแบบจำลองคณิตศาสตร์

ข้อแตกต่าง: มีการเลือกป้ายและขอบเขตบริการนอกเหนือจากรถวนภายในมหาวิทยาลัย หากใช้ป้ายเดิมของ TU ให้ศึกษาส่วนแบบจำลองที่เกี่ยวข้องก่อน

## P9. ข้อจำกัดพลังงานและต้นทุนรถ EV ในมหาวิทยาลัย

**A Multiple objective formulation of an electric vehicle routing problem for shuttle bus fleet at a university campus**

- ผู้เขียน: Selin Hulagu และ Hilmi Berk Celikoglu
- ปี/แหล่งตีพิมพ์: 2019, 6th International Conference on Models and Technologies for Intelligent Transportation Systems (MT-ITS), IEEE
- DOI: [10.1109/MTITS.2019.8883344](https://doi.org/10.1109/MTITS.2019.8883344)
- แหล่งข้อมูล: [คลังผลงาน Istanbul Technical University](https://research.itu.edu.tr/en/publications/a-multiple-objective-formulation-of-an-electric-vehicle-routing-p/)

เนื้อหา: แบบจำลอง Integer Programming หลายเป้าหมายสำหรับรถรับส่งไฟฟ้าในมหาวิทยาลัย คำนึงถึงต้นทุนเดินรถ ชาร์จ และสถานีชาร์จ รวมถึงระยะทางที่วิ่งได้ก่อนชาร์จ

การนำมาใช้ที่เสนอ: ช่วยกำหนดว่าข้อจำกัดใดจำเป็นเมื่ออ้างว่าเป็นการจัดรถ EV และวางแนวทางขยายต้นทุนหรือพลังงานภายหลัง

ข้อแตกต่าง: พลังงานและโครงสร้างพื้นฐานการชาร์จต้องมีข้อมูลเพิ่ม จึงเป็นงานขยายที่ต้องตกลงขอบเขตก่อน

## P10. Paper อ้างอิงเครื่องมือ SUMO

**Microscopic Traffic Simulation using SUMO**

- ผู้เขียน: Pablo Alvarez Lopez และคณะ
- ปี/แหล่งตีพิมพ์: 2018, IEEE ITSC, 2575–2582
- DOI: [10.1109/ITSC.2018.8569938](https://doi.org/10.1109/ITSC.2018.8569938)
- แหล่งข้อมูล: [DLR พร้อมลิงก์ฉบับเต็ม](https://elib.dlr.de/127994/), [หน้าอ้างอิงทางการ SUMO](https://sumo.dlr.de/userdoc/Publications.html)

เนื้อหา: อธิบาย SUMO การจำลองการเดินทางหลายรูปแบบ การเชื่อมเครื่องจำลอง และการพัฒนา/ตรวจสอบแบบจำลอง

การนำมาใช้ที่เสนอ: อ้างอิงเครื่องมือใน Methodology และวางกระบวนการสร้างโครงข่าย ความต้องการเดินทาง การติดตามรถ/ผู้โดยสาร และการตรวจผลเชิงตัวเลข

ข้อแตกต่าง: เป็น Paper เครื่องมือ ไม่ใช่หลักฐานว่า Algorithm ของ UniFlow EV ดีขึ้น

เอกสารประกอบการนำไปทำจริง: [Public Transport](https://sumo.dlr.de/docs/Simulation/Public_Transport.html), [Public Transport Tutorial](https://sumo.dlr.de/docs/Tutorials/PublicTransport.html) ซึ่งเป็นคู่มือ ไม่ใช่ Paper วิจัยเพิ่มเติม

## จับคู่กับ Feedback อาจารย์

| Feedback | Paper เริ่มอ่าน | ประเด็นที่จะนำมาออกแบบ |
|---|---|---|
| Goal function และการเข้าเรียนทัน | P1, P5, P7 | Time windows ความสำเร็จของบริการ และเงื่อนไขเวลาถึง |
| เวลารอและกรอบเวลามาถึงป้าย | P6, P2 | พฤติกรรมผู้โดยสาร Headway และที่นั่ง |
| ใช้รถให้คุ้มและลดทรัพยากร | P2, P3, P5 | ระดับบริการเทียบต้นทุน จำนวนรถและระยะทาง |
| อยากเห็น Mobility และจำนวนคน | P4, P8, P10 | ข้อมูลต้นทาง–ปลายทาง การไหลของผู้โดยสาร และการจำลอง |
| Algorithm และกราฟ Objective | P1, P3, P5 | ตัวแปรตัดสินใจ Neighborhood งบการค้นหา และการเปรียบเทียบ |
| รถเสียหรือความต้องการเปลี่ยน | P4 | สถานการณ์ทดลองและความทนทานของแผน |
| ข้อจำกัดเฉพาะ EV | P2, P9 | พลังงาน ระยะวิ่งและการชาร์จ |

การจับคู่และลำดับอ่านเป็นข้อเสนอสำหรับ UniFlow EV จากการคัดกรองครั้งนี้ ไม่ได้หมายความว่าต้องเพิ่มทุกฟังก์ชันในโปรเจกต์

## สิ่งที่ต้องดึงออกมาหลังอ่านฉบับเต็ม

สำหรับแต่ละงาน ให้จดปัญหา Input ตัวแปรตัดสินใจ สมการ Objective Constraints วิธีแก้ Parameter เกณฑ์หยุด ข้อมูลทดลอง วิธีเปรียบเทียบ และข้อจำกัด พร้อมเลขสมการ/ตาราง/หน้าที่ตรวจจริง

จากนั้นแยกให้ชัดว่า UniFlow EV จะนำอะไรมาใช้ ปรับอะไร และยังไม่ครอบคลุมอะไร โดยไม่คัดลอกค่าตัวเลข สมมติฐาน หรือผลปรับปรุงมาใช้เป็นผลของโครงงานเรา

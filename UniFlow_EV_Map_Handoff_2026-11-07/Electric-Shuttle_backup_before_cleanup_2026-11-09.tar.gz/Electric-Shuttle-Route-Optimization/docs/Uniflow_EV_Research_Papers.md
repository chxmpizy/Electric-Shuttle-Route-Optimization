# รวบรวมงานวิจัย (Research Papers) ด้าน Mobility, Bus Routing/Scheduling และแนวทางประยุกต์ใช้กับโครงงาน Uniflow EV

เอกสารฉบับนี้รวบรวมงานวิจัยหลักตั้งแต่ระดับพื้นฐานไปจนถึงเทคโนโลยีล่าสุด ด้าน Mobility, การจัดเส้นทางและตารางเดินรถโดยสาร (Bus Routing & Scheduling) รวมถึงงานวิจัยที่คัดสรรมาเพื่อสนับสนุนโครงงาน **“ยูนิโฟลว์ อีวี: อัลกอริทึมจัดตารางเดินรถอีวีตามตารางเรียนเพื่อการเข้าเรียนที่ตรงเวลา” (Uniflow EV)** โดยเฉพาะ พร้อมรูปแบบการอ้างอิงแบบ IEEE สำหรับนำไปใช้ในเล่มรายงาน

---

## ส่วนที่ 1: งานวิจัยหลักด้าน Mobility, Bus Routing/Scheduling และ Transportation (ภาพรวม)

### 1.1 กลุ่มปูพื้นฐานและภาพรวมการออกแบบโครงข่าย (Foundational & Comprehensive Reviews)
เหมาะสำหรับอ่านเพื่อทำความเข้าใจโครงสร้างปัญหาทั้งหมด (Strategic, Tactical และ Operational Planning) รวมถึงสมการคณิตศาสตร์พื้นฐาน

* **Transit network design and scheduling: A global review (2008)**
  * **ผู้แต่ง:** Valérie Guihaire, Jin-Kao Hao (*Transportation Research Part A: Policy and Practice*)
  * **จุดเด่น:** เปเปอร์คลาสสิกที่อธิบาย 5 ขั้นตอนหลักของการวางแผนระบบรถโดยสาร ได้แก่ การออกแบบเส้นทาง (Network Design), การกำหนดความถี่ (Frequency Setting), การจัดตารางเวลา (Timetabling), การจัดตารางเดินรถ (Vehicle Scheduling) และการจัดตารางพนักงานขับรถ (Crew Scheduling)
* **Planning, operation, and control of bus transport systems: A literature review (2015)**
  * **ผู้แต่ง:** O.J. Ibarra-Rojas และคณะ (*Transportation Research Part B: Methodological*)
  * **จุดเด่น:** เจาะลึกวิธีแก้ปัญหาเชิง Optimization ในแต่ละขั้นตอน พร้อมเชื่อมโยงไปถึงการควบคุมการเดินรถแบบ Real-time
* **Transit network design problem: a half century of methodological research (2025)**
  * **ผู้แต่ง:** ตีพิมพ์ในวารสาร *Innovative Infrastructure Solutions*
  * **จุดเด่น:** รวบรวมและวิเคราะห์งานวิจัยกว่า 170 ชิ้นตั้งแต่ปี 1970–2024 ชี้ให้เห็นการเปลี่ยนผ่านจากโมเดลคณิตศาสตร์ดั้งเดิม (Mathematical Programming / Metaheuristics) สู่การออกแบบโครงข่ายด้วย AI ที่คำนึงถึงความยืดหยุ่นและความเท่าเทียม (Equity)

### 1.2 กลุ่มการใช้ AI และ Deep Reinforcement Learning (AI & Dynamic Control)
งานวิจัยยุคใหม่ที่เปลี่ยนจากการจัดตารางแบบคงที่ (Static) มาเป็นการปรับเปลี่ยนตามสภาพจราจรและความต้องการจริงแบบ Real-time

* **Learning Heuristics for Transit Network Design and Improvement with Deep Reinforcement Learning (2024/2025)**
  * **ผู้แต่ง:** Andrew Holliday, Ahmed El-Geneidy, Gregory Dudek (*Transportmetrica B: Transport Dynamics*)
  * **จุดเด่น:** ใช้ Graph Neural Networks (GNN) ร่วมกับ Deep Reinforcement Learning (DRL) เพื่อสร้างและปรับปรุงเส้นทางเดินรถเมล์อัตโนมัติ โดยสามารถหาคำตอบได้เร็วกว่าวิธี Metaheuristics แบบดั้งเดิมและนำไปทดลองกับข้อมูลเมืองจริง
* **Deep Reinforcement Learning-Based Holding Control for Bus Bunching under Stochastic Travel Time and Demand (2023)**
  * **ผู้แต่ง:** Dong Liu, Feng Xiao, Jian Luo, Fan Yang (*Sustainability*)
  * **จุดเด่น:** แก้ปัญหาคลาสสิกของระบบรถเมล์ที่เรียกว่า **"Bus Bunching"** (รถเมล์สายเดียวกันวิ่งมาติดกันเป็นขบวน) โดยใช้ DRL คำนวณเวลาที่รถควรจอดรอที่ป้าย (Holding Control) ภายใต้ความไม่แน่นอนของจำนวนผู้โดยสารและสภาพจราจร

### 1.3 กลุ่มรถโดยสารไฟฟ้าและการจัดตารางชาร์จไฟ (Electric Bus Routing & Charging Scheduling)
หัวข้อที่กำลังได้รับความนิยมสูงสุดในปัจจุบัน เนื่องจากมีข้อจำกัดด้านระยะทางวิ่ง (Range Anxiety), เวลาในการชาร์จ และผลกระทบต่อโครงข่ายไฟฟ้า

* **Electric bus planning & scheduling: A review of related problems and methodologies (2022)**
  * **ผู้แต่ง:** Shyam S.G. Perumal, Richard M. Lusby, Jesper Larsen (*European Journal of Operational Research*)
  * **จุดเด่น:** เปเปอร์รีวิวหลักสำหรับผู้ที่ทำวิจัยเรื่อง Electric Vehicle Scheduling Problem (E-VSP) รวบรวมโมเดลทางคณิตศาสตร์ เช่น Column Generation และ Branch-and-Price สำหรับการจัดตารางเดินรถควบคู่กับการวางแผนจุดชาร์จ
* **Charging facility planning and scheduling problems for battery electric bus systems: A comprehensive review (2024)**
  * **ผู้แต่ง:** Yu Zhou และคณะ (*Transportation Research Part E: Logistics and Transportation Review*)
  * **จุดเด่น:** เน้นการวางแผนโครงสร้างพื้นฐานจุดชาร์จ (Depot Charging vs. En-route Fast Charging) และการจัดการความเสื่อมของแบตเตอรี่ควบคู่ไปกับตารางเดินรถ
* **En-route charge scheduling for an electric bus network: Stochasticity and real-world practice (2024)**
  * **ผู้แต่ง:** Ziling Zeng, Tingsong Wang, Xiaobo Qu (*Transportation Research Part E*)
  * **จุดเด่น:** นำเสนอ Robust Optimization สำหรับจัดการตารางชาร์จไฟระหว่างวัน (En-route charging) โดยคำนึงถึงความไม่แน่นอนของเวลาเดินทางและการใช้พลังงานจริง

### 1.4 กลุ่มระบบขนส่งตามความต้องการและ Mobility สมัยใหม่ (Demand-Responsive Transit & MaaS)
เน้นการเชื่อมต่อ First-mile / Last-mile และการผสมผสานระหว่างรถเมล์เส้นทางคงที่ (Fixed-route) กับรถที่วิ่งตามการกดเรียกของผู้โดยสาร (On-demand)

* **Demand responsive transit systems: A review of optimization problems and solution methods (2022)**
  * **ผู้แต่ง:** Pieter Vansteenwegen และคณะ (*European Journal of Operational Research*)
  * **จุดเด่น:** สรุปภาพรวมของระบบ DRT (หรือ Dial-a-Ride Problem: DARP) การจัดเส้นทางแบบ Dynamic และการผสานระบบเข้ากับขนส่งมวลชนหลัก
* **Adaptive Transit Solutions: A Comparative Review of Demand-Responsive Public Transit Systems for Sustainable Urban Mobility and Environment (2025/2026)**
  * **ผู้แต่ง:** Sanaz Sadat Hosseini และคณะ
  * **จุดเด่น:** วิเคราะห์กรณีศึกษาการนำระบบ DRT ไปใช้จริงกว่า 65 งานวิจัย เปรียบเทียบประสิทธิภาพด้านต้นทุน เวลารอคอย และการใช้อัลกอริทึม AI ในการปรับเส้นทางตามความหนาแน่นของเมือง

### ตารางสรุปเปรียบเทียบแนวทางและคำสำคัญสำหรับค้นหาต่อ

| กลุ่มหัวข้อวิจัย | ปัญหาหลักที่สนใจ (Core Problems) | คำสำคัญสำหรับค้นหา (Search Keywords) | วารสารชั้นนำที่แนะนำ |
| :--- | :--- | :--- | :--- |
| **Transit Network Design** | ออกแบบเส้นทางใหม่, กำหนดความถี่การปล่อยรถ | `TNDP`, `TRNDP`, `Frequency Setting`, `Multi-objective Transit Optimization` | *Transportation Research Part A / Part B* |
| **Vehicle & Crew Scheduling** | จัดตารางรถและคนขับให้ใช้ทรัพยากรต่ำสุด | `MDVSP` (Multi-Depot Vehicle Scheduling), `Crew Rostering`, `Column Generation` | *European Journal of Operational Research (EJOR)*, *Transportation Science* |
| **Real-time Control & AI** | แก้ปัญหารถเมล์วิ่งกระจุกตัว, ปรับตารางเวลาอัตโนมัติ | `Bus Bunching`, `Holding Control`, `Deep Reinforcement Learning in Transit` | *Transportation Research Part C: Emerging Technologies*, *IEEE T-ITS* |
| **Electric Bus (E-Bus)** | วางจุดชาร์จ, จัดตารางเดินรถภายใต้ข้อจำกัดแบตเตอรี่ | `E-VSP`, `Electric Bus Scheduling`, `En-route Charging`, `Battery Degradation` | *Transportation Research Part E*, *Applied Energy* |
| **On-Demand Mobility** | รถรับส่งตามคำขอ, เชื่อมต่อระบบราง (Feeder) | `DRT` (Demand-Responsive Transit), `DARP`, `Microtransit`, `First-mile Last-mile` | *Transportation Research Part C*, *Public Transport* |

---

## ส่วนที่ 2: งานวิจัยเฉพาะเจาะจงสำหรับโครงงาน Uniflow EV (มธ. ศูนย์รังสิต)

โครงงาน Uniflow EV มีแกนหลักทางเทคนิคคือ **Simulation-Based Optimization (SBO)** โดยใช้ **Discrete Event Simulation (DES)** ประเมินค่า Fitness Function จากเวลารอและเวลาเดินทาง ร่วมกับ **Metaheuristics 4 ตัว (GA, SA, PSO, ACO)** เพื่อจัดสรรรถ EV 30 คันใน 6 สายโดยอิงจากตารางเรียนนักศึกษา และแสดงผลผ่าน **SUMO ร่วมกับ OSMnx**

### 2.1 กลุ่มการจัดเส้นทางและตารางรถรับส่งในมหาวิทยาลัย (Campus Shuttle & School Bus Scheduling)
โครงงานใช้ **ตารางเรียนของนักศึกษาหอใน** เป็นตัวแปรหลักในการกำหนด Demand ช่วงเวลาเร่งด่วน ซึ่งตรงกับปัญหา **University Shuttle Routing** และ **School Bus Routing Problem (SBRP) with Bell Times**

* **A review of the school bus routing problem: Methodologies and applications (2010)**
  * **ผู้แต่ง:** Junhyuk Park, Byung-In Kim (*European Journal of Operational Research*)
  * **การนำไปประยุกต์ใช้ในเล่ม:** อธิบายโครงสร้างปัญหาการจัดรถรับส่งนักเรียน/นักศึกษาให้ไปถึงอาคารเรียนก่อนเวลาเริ่มคาบเรียน (Time Windows / Bell Time Constraints) ใช้เป็นทฤษฎีอ้างอิงในบทที่ 2 และ 3 ได้ว่าทำไมการอิงข้อมูลจาก "ตารางเรียน" ถึงแตกต่างจากการเดินรถเมล์สาธารณะทั่วไป
* **Optimization of Campus Shuttle Bus Route and Scheduling Based on Passenger Flow**
  * **แนวคิดหลัก:** การจัดสรรจำนวนรถ (Fleet Allocation) และความถี่การปล่อยรถ (Headway / Frequency Setting) ภายในมหาวิทยาลัยที่มีความต้องการพุ่งสูงเป็นช่วงๆ (Peak-hour spikes ก่อนเริ่มคาบเรียน เช่น 08:30 น., 09:00 น., 13:00 น.) โดยไม่ต้องเพิ่มจำนวนรถทั้งหมดที่มีอยู่

### 2.2 กลุ่ม Simulation-Based Optimization (DES + Metaheuristics)
สถาปัตยกรรมหลักของระบบคือการนำ **Discrete Event Simulation (DES)** มาจำลองคิว (FIFO) การขึ้น-ลงรถ เพื่อคำนวณ `Avg Wait Time` และ `Avg Travel Time` แล้วส่งค่ากลับไปเป็น Fitness Score ให้ **GA, SA, PSO, ACO** ประเมินซ้ำ 5 รอบ

* **Simulation-based optimization for public transport scheduling / frequency setting**
  * **แนวคิดหลัก:** ใช้ Simulation จำลองพฤติกรรมผู้โดยสารที่ป้ายรถเมล์ (เพราะสมการคณิตศาสตร์ปกติไม่สามารถคำนวณเวลารอคอยเมื่อรถเต็มหรือคนตกค้างที่ป้ายได้แม่นยำ) แล้วใช้ Metaheuristics ค้นหาตารางเดินรถที่ดีที่สุด
  * **การนำไปประยุกต์ใช้ในเล่ม:** ใช้ยืนยันความถูกต้องของสถาปัตยกรรมระบบในบทที่ 3 ได้ว่า เหตุผลที่ต้องรัน Simulation ซ้ำ 5 รอบต่อ 1 คำตอบ เป็นเพราะระบบมีตัวแปรสุ่มจากการ Generate Passenger (`Stochastic Simulation Optimization`) การหาค่าเฉลี่ยหลายรอบช่วยให้ค่า Fitness เสถียรขึ้น
* **Efficient transit network design and frequencies setting multi-objective optimization by alternating objective genetic algorithm (2015)**
  * **ผู้แต่ง:** R. O. Arbex, C. B. da Cunha (*Transportation Research Part B: Methodological*)
  * **การนำไปประยุกต์ใช้ในเล่ม:** ช่วยอธิบายวิธีการจัดการกับข้อจำกัดจำนวนรถทั้งหมด (Fleet Size Constraint) การทำ **Repair Operator ใน GA** เมื่อสุ่มจำนวนรถรวมกันแล้วเกินจำนวนรถที่มี และการแปลงค่าคำตอบของ Metaheuristics ให้เป็นจำนวนเต็ม

### 2.3 กลุ่มการกำหนดค่าถ่วงน้ำหนักใน Fitness Function (Waiting Time vs. Travel Time)
ในเล่มรายงานมีการใช้สมการ Fitness Function ที่ถ่วงน้ำหนักระหว่างเวลารอรถ (`Avg_wait_time`) และเวลาเดินทางบนรถ (`Avg_travel_time`)

* **Public transport values of time (2004) & The demand for public transport: a practical guide (2006)**
  * **ผู้แต่ง:** M. Wardman (*Transport Policy*, 2004) และ N. Paulley et al. (*Transport Policy*, 2006)
  * **การนำไปประยุกต์ใช้ในเล่ม:** งานวิจัยด้านพฤติกรรมผู้โดยสารพบว่า ผู้โดยสารมักรับรู้เวลารอรถที่ป้าย (Perceived Waiting Time) ยาวนานและสร้างความไม่พอใจมากกว่าเวลาที่นั่งอยู่บนรถ (In-vehicle Travel Time) ประมาณ 1.5 ถึง 2 เท่า สามารถใช้อ้างอิงในหัวข้อ **3.3.4 การกำหนดค่า Fitness Function** เพื่ออธิบายเหตุผลของการกำหนดค่าน้ำหนัก (Weight) ได้อย่างมีหลักการวิชาการรองรับ

### 2.4 กลุ่มการจำลองการจราจรด้วย SUMO และ OSMnx (Microscopic Traffic Simulation)
เปเปอร์ต้นฉบับ (Official References) ของเครื่องมือแสดงผลกราฟิกและดึงข้อมูลแผนที่ที่ใช้ในโครงงาน:

* **Microscopic Traffic Simulation using SUMO (2018)**
  * **ผู้แต่ง:** Pablo Alvarez Lopez และคณะ (*IEEE Intelligent Transportation Systems Conference - ITSC*)
  * **การนำไปประยุกต์ใช้ในเล่ม:** เปเปอร์อ้างอิงมาตรฐานหลักของซอฟต์แวร์ SUMO สำหรับใส่ในบทที่ 2, บทที่ 3 และรายการอ้างอิงท้ายเล่ม
* **OSMnx: New methods for acquiring, constructing, analyzing, and visualizing complex street networks (2017)**
  * **ผู้แต่ง:** Geoff Boeing (*Computers, Environment and Urban Systems*)
  * **การนำไปประยุกต์ใช้ในเล่ม:** เปเปอร์ต้นฉบับของผู้สร้างไลบรารี `OSMnx` ซึ่งอธิบายการแปลงแผนที่จาก OpenStreetMap มาเป็นกราฟ (`networkx`) เพื่อคำนวณระยะทางและสร้างโครงข่ายถนน

---

## ส่วนที่ 3: รายการอ้างอิงรูปแบบ IEEE (พร้อมนำไปใส่ในหน้า 35 ของเล่มรายงาน)

คุณสามารถคัดลอกรายการอ้างอิงด้านล่างนี้ไปเพิ่มเติมหรือปรับปรุงในหน้า **รายการอ้างอิง** ของเล่มโครงงานได้เลย:

```text
[12] J. P. Talusan, A. Mukhopadhyay, D. Freudberg, and A. Dubey, "On Designing Day-to-Day Dynamic Transit Directives Using Monte Carlo Tree Search," in Proc. ACM/IEEE Int. Conf. Cyber-Physical Systems (ICCPS), 2022.
[13] V. Guihaire and J.-K. Hao, "Transit network design and scheduling: A global review," Transportation Research Part A: Policy and Practice, vol. 42, no. 10, pp. 1251–1273, 2008.
[14] O. J. Ibarra-Rojas, F. Delgado, R. Giesen, and J. C. Muñoz, "Planning, operation, and control of bus transport systems: A literature review," Transportation Research Part B: Methodological, vol. 77, pp. 38–75, 2015.
[15] J. Park and B.-I. Kim, "The school bus routing problem: A review," European Journal of Operational Research, vol. 202, no. 2, pp. 311–319, 2010.
[16] R. O. Arbex and C. B. da Cunha, "Efficient transit network design and frequencies setting multi-objective optimization by alternating objective genetic algorithm," Transportation Research Part B: Methodological, vol. 81, pp. 355–376, 2015.
[17] S. S. G. Perumal, R. M. Lusby, and J. Larsen, "Electric bus planning & scheduling: A review of related problems and methodologies," European Journal of Operational Research, vol. 301, no. 2, pp. 395–413, 2022.
[18] M. Wardman, "Public transport values of time," Transport Policy, vol. 11, no. 4, pp. 363–377, 2004.
[19] P. A. Lopez et al., "Microscopic Traffic Simulation using SUMO," in Proc. 21st Int. Conf. Intelligent Transportation Systems (ITSC), Maui, HI, USA, 2018, pp. 2575–2582.
[20] G. Boeing, "OSMnx: New methods for acquiring, constructing, analyzing, and visualizing complex street networks," Computers, Environment and Urban Systems, vol. 65, pp. 126–139, 2017.
```

---

## ส่วนที่ 4: เช็กลิสต์จุดที่ควรตรวจสอบและแก้ไขในเล่มรายงาน Uniflow EV

1. **ความไม่ตรงกันของสมการ Fitness Function:**
   * ในหน้า **Abstract (หน้า 4)** ระบุสมการเป็น `(0.3 x average waiting time) + (0.7 x average travel time)`
   * ในหน้า **บทที่ 3 (หน้า 20 และ 22)** ระบุสมการเป็น `(0.5 * Avg_wait_time) + (0.5 * avg_travel_time)`
   * **แนวทางแก้ไข:** ปรับตัวเลขให้ตรงกันทั้งเล่ม หรือหากมีการทดลองปรับเปลี่ยนค่าน้ำหนัก ให้เขียนอธิบายเป็น Sensitivity Analysis ในบทผลการทดลอง
2. **ความไม่ตรงกันของชื่อผู้แต่งในหัวข้อ 2.2.2 กับรายการอ้างอิง [12]:**
   * ในเนื้อหาหน้า 17 หัวข้อ **2.2.2 Dynamic Transit Scheduling and Dispatch** เขียนอ้างอิงถึงงานของ *"Talusan และคณะ"* ที่ใช้ Monte Carlo Tree Search (MCTS)
   * แต่ในหน้า **รายการอ้างอิง (หน้า 35)** ลำดับที่ `[12]` กลับเขียนเป็นชื่อ *"S. Deshmukh, A. Patil..."*
   * **แนวทางแก้ไข:** แก้ไขรายการอ้างอิง `[12]` ให้ตรงกับเปเปอร์ของ Talusan et al. (ตามรายการ IEEE ด้านบน) หรือแยกเป็น `[12]` และ `[13]` เพื่อให้สอดคล้องกับเนื้อหาในบทที่ 2

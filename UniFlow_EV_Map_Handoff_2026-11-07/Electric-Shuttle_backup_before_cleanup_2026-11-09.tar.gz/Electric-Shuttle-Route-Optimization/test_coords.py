import sumolib

net = sumolib.net.readNet("src/models/sumo_output/thammasat.net.xml")

stops = {
    "Dome": (100.600383, 14.065709),
    "Hospital": (100.616199, 14.073630),
    "Dorm": (100.594949, 14.077278),
    "Gate1": (100.605096, 14.066285),
    "Library": (100.601640, 14.071229),
    "Park": (100.611659, 14.072180),
    "SC1": (100.604252, 14.069462),
    "SC2_SC3": (100.604594, 14.070692),
    "Green": (100.601626, 14.072717),
    "Convention": (100.612657, 14.066815),
    "Terminal": (100.606835, 14.067434),
    "Lecture": (100.602213, 14.072096),
    "Health": (100.612871, 14.072208),
    "Social": (100.601663, 14.069670),
}

for stop, (lon, lat) in stops.items():
    x, y = net.convertLonLat2XY(lon, lat)
    edges = net.getNeighboringEdges(x, y, 200)
    if not edges:
        print(f"FAILED to find edges for {stop}")
    else:
        # filter for bus
        valid = [e for e, dist in edges if e.allows("bus")]
        if valid:
            print(f"{stop:15s}: OK - nearest bus edge {valid[0].getID()}")
        else:
            print(f"{stop:15s}: NO BUS EDGE nearby")

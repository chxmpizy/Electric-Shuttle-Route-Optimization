"""Resolve the official EV shuttle routes (data/raw/routes.json) onto real OSM roads.

For each route:
  1. Expand the printed stop names. Routes without arrows on their map (return_same_way)
     run START -> END, then come back through the same stops in reverse.
  2. Where a printed name maps to several stop ids (e.g. both sides of a road), choose the
     ids that fit the direction of travel (shortest drive).
  3. Drive the roads between consecutive stops. {"via": ...} entries force the road the
     map draws (routes with arrows). On the way back of a return_same_way route the bus
     prefers the outbound roads in the opposite direction (the other lane).
  4. Add every other stop the bus passes on its side of the road (buses stop at every stop
     they pass).

Routes are loops: after the last stop the bus drives back to the first (the closing leg),
so the path does not repeat the first stop. Each route also gets its legs: road distance
and road geometry from each stop to the next, including the closing leg.

The spec's "baseline_routes" (the project's own 3-route baseline, not printed on any route
card) are resolved the same way; their stops can also be plain stop ids from stops.csv.

Output: src/data/official_routes.json (read by src/data/routes.py and the web export) and
src/data/baseline_routes.json (the simulation baseline, read by src/data/routes.py).
Usage (from the repo root, after scripts/build_osm_distances.py):
  python scripts/build_routes.py
"""
import json
import sys
from pathlib import Path

import networkx as nx
import osmnx as ox
from shapely.geometry import LineString, Point
from shapely.ops import substring

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from build_osm_distances import edge_line, load_graph, snap_stops  # noqa: E402

ROUTES_IN = ROOT / "data/raw/routes.json"
OUT = ROOT / "src/data/official_routes.json"
BASELINE_OUT = ROOT / "src/data/baseline_routes.json"
NOT_PASSENGER_STOPS = {"Depot"}
OTHER_LANE_PENALTY = 4.0  # on the way back, roads not used outbound cost this much more


def hhmm(s: str) -> int:
    h, m = s.split(":")
    return int(h) * 60 + int(m)


def best_key(G, u, v):
    return min(G[u][v], key=lambda k: G[u][v][k]["length"])


class Roads:
    """Road legs between snapped points, as directed edge segments (u, v, from_m, to_m)."""

    def __init__(self, Gp, points):
        self.G, self.p = Gp, points
        self._sp, self._cache = {}, {}

    def _weight(self, prefer):
        if prefer is None:
            return "length"

        def w(u, v, d):
            length = min(a["length"] for a in d.values())
            return length if (u, v) in prefer else length * OTHER_LANE_PENALTY
        return w

    def _paths(self, x, prefer):
        key = (x, id(prefer))
        if key not in self._sp:
            self._sp[key] = nx.single_source_dijkstra(self.G, x, weight=self._weight(prefer))
        return self._sp[key]

    def _cost(self, segs, prefer):
        total = 0.0
        for u, v, f, t in segs:
            m = t - f
            total += m if prefer is None or (u, v) in prefer else m * OTHER_LANE_PENALTY
        return total

    def leg(self, a, b, prefer=None):
        """(cost, metres, segments) from point a to point b."""
        key = (a, b, id(prefer))
        if key in self._cache:
            return self._cache[key]
        sa, sb = self.p[a], self.p[b]
        ua, va, _ = sa["edge"]
        ub, vb, _ = sb["edge"]
        oa, La = sa["offset_m"], sa["length_m"]
        ob, Lb = sb["offset_m"], sb["length_m"]
        cands = []
        # Same road: drive straight from a to b in any direction both stops allow.
        # Each stop's position is expressed in the frame of the directed edge driven.
        a_frames = [((ua, va), oa)] + ([((va, ua), La - oa)] if sa["both_directions"] else [])
        b_frames = [((ub, vb), ob)] + ([((vb, ub), Lb - ob)] if sb["both_directions"] else [])
        for ea, pa in a_frames:
            for eb, pb in b_frames:
                if ea == eb and pb >= pa:
                    cands.append([(ea[0], ea[1], pa, pb)])
        exits = [(va, (ua, va, oa, La))]
        if sa["both_directions"]:
            exits.append((ua, (va, ua, La - oa, La)))
        entries = [(ub, (ub, vb, 0.0, ob))]
        if sb["both_directions"]:
            entries.append((vb, (vb, ub, 0.0, Lb - ob)))
        for x, gx in exits:
            dist, paths = self._paths(x, prefer)
            for y, gy in entries:
                if y not in dist:
                    continue
                p = paths[y]
                mid = [(u, v, 0.0, self.G[u][v][best_key(self.G, u, v)]["length"])
                       for u, v in zip(p, p[1:])]
                cands.append([gx, *mid, gy])
        if not cands:
            raise ValueError(f"no road path {a} -> {b}")
        segs = min(cands, key=lambda s: self._cost(s, prefer))
        out = (self._cost(segs, prefer), sum(t - f for _, _, f, t in segs), segs)
        self._cache[key] = out
        return out

    def hits(self, seg, candidates, exclude):
        """Stops lying on one segment (u, v, f, t), as (offset, stop_id), in order."""
        u, v, f, t = seg
        found = []
        for sid in candidates:
            if sid in exclude:
                continue
            s = self.p[sid]
            su, sv, _ = s["edge"]
            o = None
            if (su, sv) == (u, v):
                o = s["offset_m"]
            elif s["both_directions"] and (sv, su) == (u, v):
                o = s["length_m"] - s["offset_m"]
            if o is not None and f < o < t:
                found.append((o, sid))
        return sorted(found)


def snap_via_point(Gp, lat, lon):
    """A road point used only to force the route's road (not a stop)."""
    crs = Gp.graph["crs"]
    pt, _ = ox.projection.project_geometry(Point(lon, lat), to_crs=crs)
    u, v, k = ox.nearest_edges(Gp, pt.x, pt.y)
    line = edge_line(Gp, u, v, k)
    return {"edge": (u, v, k), "offset_m": line.project(pt), "length_m": line.length,
            "both_directions": Gp.has_edge(v, u)}


def choose_ids(seq, roads, prefer=None, start=None):
    """Pick one id per element (DP, least cost). seq items are lists of candidate ids."""
    first = [start] if start else seq[0]
    best = {sid: (0.0, [sid]) for sid in first}
    for opts in seq[1:]:
        nxt = {}
        for sid in opts:
            choices = [(cost + roads.leg(prev, sid, prefer)[0], path + [sid])
                       for prev, (cost, path) in best.items() if prev != sid]
            if choices:
                nxt[sid] = min(choices, key=lambda c: c[0])
        best = nxt
    return best


OUTBOUND_ONLY = "#outbound-only"  # marks a {"via": ...} that the way back does not repeat


def resolve(route, groups, roads, vias, stops):
    """Waypoint ids (stops and via points) in driving order, ending back at the start."""
    elems, names = [], []
    for item in route["stops"]:
        if isinstance(item, str):
            elems.append(list(groups.get(item, [item])))  # a printed name, or a stop id
            names.append(item)
        else:
            elems.append([vias[id(item)]])
            names.append(OUTBOUND_ONLY if item.get("outbound_only") else None)
    if not route["return_same_way"]:
        best = choose_ids(elems, roads)
        loops = {sid: v for sid, v in best.items() if sid == v[1][0]}
        return min((loops or best).values(), key=lambda c: c[0])[1]
    # START -> END, then back on the same roads in the other lane.
    out_best = choose_ids(elems, roads)
    outbound = min(out_best.values(), key=lambda c: c[0])[1]
    used = set()
    for a, b in zip(outbound, outbound[1:]):
        used.update((u, v) for u, v, _, _ in roads.leg(a, b)[2])
    prefer = frozenset((v, u) for u, v in used)
    skip = set(route.get("return_skip", [])) | {OUTBOUND_ONLY}
    back = [e for e, n in list(zip(elems, names))[::-1][1:-1] if n not in skip]
    # Road points forced only on the way back, just before reaching START again. This end
    # of the trip leaves the outbound roads on purpose, so it takes the plain shortest road.
    tail = [[vias[id(item)]] for item in route.get("return_via_end", [])]
    if tail:
        off_route = set()
        steps = back[-1:] + tail + [elems[0]]
        for opts_a, opts_b in zip(steps, steps[1:]):
            for a in opts_a:
                for b in opts_b:
                    off_route.update((u, v) for u, v, _, _ in roads.leg(a, b)[2])
        prefer = prefer | off_route
    back += tail + [elems[0]]
    back_best = choose_ids([[outbound[-1]], *back], roads, prefer=prefer, start=outbound[-1])
    loops = {sid: v for sid, v in back_best.items() if sid == outbound[0]}
    if route.get("rest_point"):
        loops = {}  # ends at the stop opposite START; the rest point closes the loop
    back_path = min((loops or back_best).values(), key=lambda c: c[0])[1]
    roads.prefer_back = prefer
    ids = outbound + back_path[1:]
    if route.get("rest_point"):
        ids = ids + [route["rest_point"]]
    return ids, len(outbound) - 1, prefer


def _moving(segs):
    return [s for s in segs if s[3] - s[2] > 0.5]


def record_lane_use(route_name, path, legs, points, lane_use):
    """Which lane each route is in when it stops at each stop.

    A stop's own lane is the direction of travel with the stop pin on the left (Thailand
    drives on the left). Stopping from the opposite lane means passengers wait across the
    road - or, with only one physical stop, the bus must loop round to reach it.
    """
    for i, sid in enumerate(path):
        arrive = _moving(legs[i - 1][2])  # legs[i-1] ends at path[i]; legs[-1] is the closing leg
        depart = _moving(legs[i][2])
        if not arrive or sid not in points:
            continue
        au, av = arrive[-1][:2]
        su, sv = points[sid]["edge"][:2]
        use = lane_use.setdefault(sid, {"own": set(), "opposite": set(), "uturn": set()})
        if (au, av) == (sv, su):
            use["opposite"].add(route_name)
        else:
            use["own"].add(route_name)
        if depart and depart[0][:2] == (av, au):
            use["uturn"].add(route_name)


def report_lane_use(lane_use, points):
    print("\nStops used from the opposite lane (need a stop across the road, or the bus loops):")
    any_found = False
    for sid, use in lane_use.items():
        centre = points[sid].get("snap_m", 99) < 2.0
        if use["opposite"] or use["uturn"]:
            any_found = True
            side = "pin on the road centre - side unknown" if centre else "one-sided pin"
            print(f"  {sid:12s} own lane: {sorted(use['own']) or '-'}  opposite lane: {sorted(use['opposite']) or '-'}"
                  f"  U-turn at stop: {sorted(use['uturn']) or '-'}  ({side})")
    if not any_found:
        print("  none")


def report_odd_driving(Gp, crs, points, stops, legs):
    """Print U-turns and roads driven twice in the same direction.

    A bus normally runs straight on in its lane from START to END; turning back usually
    happens only at the end (e.g. round a roundabout to reach the other lane). A U-turn
    or a repeated road elsewhere points at a stop on the wrong road/side or a wrong name.
    """
    flat = [(a, b, seg) for a, b, segs in legs for seg in segs if seg[3] - seg[2] > 0.5]
    for i, (a, b, (u, v, f, t)) in enumerate(flat):
        na, nb, (u2, v2, f2, t2) = flat[(i + 1) % len(flat)]
        if (u2, v2) == (v, u):
            # Where: the node turned at, or mid-road (a both-direction stop) at offset t.
            pt = Point(Gp.nodes[v]["x"], Gp.nodes[v]["y"]) if t >= Gp[u][v][best_key(Gp, u, v)]["length"] - 0.5 \
                else edge_line(Gp, u, v, best_key(Gp, u, v)).interpolate(t)
            ll, _ = ox.projection.project_geometry(pt, crs=crs, to_latlong=True)
            near = min(stops, key=lambda s: Point(
                Gp.nodes[points[s]["edge"][0]]["x"], Gp.nodes[points[s]["edge"][0]]["y"]).distance(pt))
            road = Gp[u][v][best_key(Gp, u, v)].get("name")
            print(f"      U-turn on {road} at ({ll.y:.6f}, {ll.x:.6f}) near {near}, leg {a} → {nb}")
    # The same stretch of road driven twice in the same direction (a detour loop).
    seen = {}
    for a, b, (u, v, f, t) in flat:
        for f0, t0, where in seen.get((u, v), []):
            if min(t, t0) - max(f, f0) > 5:
                road = Gp[u][v][best_key(Gp, u, v)].get("name")
                print(f"      drives {road} twice the same way: legs {where} and {a}→{b}")
        seen.setdefault((u, v), []).append((f, t, f"{a}→{b}"))


def main():
    spec = json.loads(ROUTES_IN.read_text(encoding="utf-8"))
    groups = spec["groups"]
    Gp = ox.project_graph(load_graph(download=False))
    crs = Gp.graph["crs"]
    points = snap_stops(Gp)
    no_pax = {s for s, p in points.items() if p.get("passengers") is False}
    stops = [s for s in points if s not in NOT_PASSENGER_STOPS and s not in no_pax]
    sections = [("routes", OUT), ("baseline_routes", BASELINE_OUT)]
    all_routes = [r for key, _ in sections for r in spec.get(key, [])]
    named = {i for ids in groups.values() for i in ids}
    named |= {i for r in all_routes for i in r["stops"] if isinstance(i, str) and i not in groups}
    missing = sorted(named - set(points))
    if missing:
        raise SystemExit(f"stops missing from data/raw/stops.csv: {missing}")

    # Via entries: a stop id (forced stop on the drawn road) or a [lat, lon] road point.
    vias, via_points = {}, set()
    for r in all_routes:
        for item in r["stops"] + r.get("return_via_end", []):
            if isinstance(item, dict):
                if isinstance(item["via"], str):
                    vias[id(item)] = item["via"]
                else:
                    vid = f"_via_{len(via_points)}"
                    points[vid] = snap_via_point(Gp, *item["via"])
                    vias[id(item)] = vid
                    via_points.add(vid)
    roads = Roads(Gp, points)

    def to_latlon(segs):
        coords = []
        for u, v, f, t in segs:
            if t - f <= 0.01:
                continue
            line = substring(edge_line(Gp, u, v, best_key(Gp, u, v)), f, t)
            if not isinstance(line, LineString) or len(line.coords) < 2:
                continue  # degenerate piece (too short to draw)
            ll, _ = ox.projection.project_geometry(LineString(line.coords), crs=crs, to_latlong=True)
            pts = [[round(lat, 6), round(lon, 6)] for lon, lat in ll.coords]
            if coords and pts and coords[-1] == pts[0]:
                pts = pts[1:]
            coords.extend(pts)
        return coords

    for key, out_file in sections:
        if key not in spec:
            continue
        print(f"\n[{key}]")
        out = []
        lane_use = {}  # stop -> {"own": {...}, "opposite": {...}, "uturn": {...}}
        for r in spec.get(key, []):
            res = resolve(r, groups, roads, vias, stops)
            if r["return_same_way"]:
                ids, turn_idx, prefer = res
            else:
                ids, turn_idx, prefer = res, len(res), None
            if len(ids) > 1 and ids[0] == ids[-1]:
                ids = ids[:-1]  # loop: the closing leg back to the start is implied

            # Drive the whole loop; record a "stop" event at every stop reached or passed.
            events = []  # ("stop", id) or ("seg", u, v, f, t)
            for i, a in enumerate(ids):
                b = ids[(i + 1) % len(ids)]
                pref = prefer if (r["return_same_way"] and i >= turn_idx) else None
                if a not in via_points:
                    events.append(("stop", a))
                for seg in roads.leg(a, b, pref)[2]:
                    u, v, f, t = seg
                    cur = f
                    for o, sid in roads.hits(seg, stops, exclude={a, b}):
                        events.append(("seg", u, v, cur, o))
                        events.append(("stop", sid))
                        cur = o
                    events.append(("seg", u, v, cur, t))

            # Split into stop-to-stop legs (the last leg wraps back to the first stop).
            path, legs, cur = [], [], None
            for e in events:
                if e[0] == "stop":
                    if path and e[1] == path[-1] and not cur:
                        continue
                    if path:
                        legs.append((path[-1], e[1], cur or []))
                    path.append(e[1])
                    cur = []
                else:
                    cur.append(e[1:])
            legs.append((path[-1], path[0], cur or []))
            if len(path) > 1 and path[-1] == path[0]:  # loop already back at the start
                path.pop()
                last = legs.pop()
                legs[-1] = (legs[-1][0], path[0], legs[-1][2] + last[2])

            if r.get("rest_point") in path:
                j = path.index(r["rest_point"])
                path, legs = path[j:] + path[:j], legs[j:] + legs[:j]
            leg_out = [{"from": a, "to": b, "km": round(sum(t - f for _, _, f, t in segs) / 1000, 3),
                        "coords": to_latlon(segs)} for a, b, segs in legs]
            km = sum(lg["km"] for lg in leg_out)
            out.append({
                "id": r["id"], "name": r["name"], "color": r["color"], "colorName": r["color_name"],
                "startTime": hhmm(r["start"]), "endTime": hhmm(r["end"]),
                "headwayMin": r["headway_min"], "returnSameWay": r["return_same_way"],
                "officialStops": [s if isinstance(s, str) else s for s in r["stops"]],
                "path": path, "legs": leg_out, "loopKm": round(km, 3),
            })
            print(f"สาย {r['name']:>2}: {km:5.2f} km, {len(path)} stops: " + " → ".join(path))
            report_odd_driving(Gp, crs, points, stops, legs)
            record_lane_use(r["name"], path, legs, points, lane_use)

        report_lane_use(lane_use, points)
        out_file.write_text(json.dumps(out, ensure_ascii=False, indent=1) + "\n")
        print(f"\nWrote {out_file.relative_to(ROOT)}")


if __name__ == "__main__":
    main()

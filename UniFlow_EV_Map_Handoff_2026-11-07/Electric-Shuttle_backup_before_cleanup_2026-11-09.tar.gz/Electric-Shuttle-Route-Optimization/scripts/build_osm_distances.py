"""Snap campus stops onto the OpenStreetMap drive network and build a road-distance matrix.

Outputs (read by src/data/graph.py):
  src/data/osm_stops.json        stop -> snapped lon/lat on the road + original lon/lat
  src/data/osm_distance_km.json  directed road distance (km) between every pair of stops

Stops are read from data/raw/stops.csv (lat/lon as copied from Google Maps). Each stop
is projected onto its nearest drivable road segment, on the side of the road it sits on
(Thailand drives on the left), and distances are measured along the road from that exact
point, so one-way streets and opposite-side stops are respected.

Usage (from the repo root):
  python scripts/build_osm_distances.py            # reuse src/map/tu_rangsit_drive.graphml
  python scripts/build_osm_distances.py --download # refetch roads from OpenStreetMap
"""
import argparse
import csv
import json
from pathlib import Path

import networkx as nx
import osmnx as ox
from shapely.geometry import LineString, Point

ROOT = Path(__file__).resolve().parents[1]
GRAPHML = ROOT / "src/map/tu_rangsit_drive.graphml"
STOPS_OUT = ROOT / "src/data/osm_stops.json"
DIST_OUT = ROOT / "src/data/osm_distance_km.json"

STOPS_CSV = ROOT / "data/raw/stops.csv"
CENTERLINE_M = 2.0  # stops closer than this to the road centreline serve both directions
OPPOSITE_MAX_M = 60.0  # max distance along the road between a stop and its across-the-road partner


def load_stops() -> dict:
    """id -> (lon, lat) from data/raw/stops.csv (columns: id,name_th,lat,lon,...)."""
    with STOPS_CSV.open(encoding="utf-8") as f:
        return {r["id"]: (float(r["lon"]), float(r["lat"])) for r in csv.DictReader(f)}


def load_road_hints() -> dict:
    """Optional 'road' column: snap the stop onto the nearest road with this name (used
    when a closer unnamed lane would otherwise win, e.g. TU Dome on ถนนศรีธรรมศาสตร์)."""
    with STOPS_CSV.open(encoding="utf-8") as f:
        return {r["id"]: r["road"].strip() for r in csv.DictReader(f) if (r.get("road") or "").strip()}


def load_one_sided() -> set:
    """Stops marked sides=one: only the lane the pin is on stops there, even with no
    partner across the road (e.g. DLUXX: buses in the other lane do not stop)."""
    with STOPS_CSV.open(encoding="utf-8") as f:
        return {r["id"] for r in csv.DictReader(f) if (r.get("sides") or "").strip().lower() == "one"}


def load_explicit_pairs() -> list:
    """(a, b) pairs from the 'opposite' column: b is the stop across the road from a."""
    with STOPS_CSV.open(encoding="utf-8") as f:
        return [(r["id"], r["opposite"].strip()) for r in csv.DictReader(f) if (r.get("opposite") or "").strip()]


def load_no_passenger() -> set:
    """Stops marked passengers=no (bus rest points): no boarding or alighting."""
    with STOPS_CSV.open(encoding="utf-8") as f:
        return {r["id"] for r in csv.DictReader(f) if (r.get("passengers") or "").strip().lower() == "no"}


ORIGINAL_STOPS = load_stops()
NO_PASSENGERS = load_no_passenger()
ONE_SIDED = load_one_sided()
ROAD_HINTS = load_road_hints()


def load_both_sided() -> set:
    """Stops marked sides=both: served in both directions whatever side the pin is on
    (e.g. a bus bay off the road that buses pass both ways)."""
    with STOPS_CSV.open(encoding="utf-8") as f:
        return {r["id"] for r in csv.DictReader(f) if (r.get("sides") or "").strip().lower() == "both"}


BOTH_SIDED = load_both_sided()
EXPLICIT_PAIRS = load_explicit_pairs()


def load_graph(download: bool) -> nx.MultiDiGraph:
    if download or not GRAPHML.exists():
        lons = [p[0] for p in ORIGINAL_STOPS.values()]
        lats = [p[1] for p in ORIGINAL_STOPS.values()]
        pad = 0.004
        bbox = (min(lons) - pad, min(lats) - pad, max(lons) + pad, max(lats) + pad)
        G = ox.graph_from_bbox(bbox, network_type="drive", simplify=True)
        GRAPHML.parent.mkdir(parents=True, exist_ok=True)
        ox.save_graphml(G, GRAPHML)
        return G
    return ox.load_graphml(GRAPHML)


def edge_line(G, u, v, k) -> LineString:
    data = G[u][v][k]
    if "geometry" in data:
        return data["geometry"]
    return LineString([(G.nodes[u]["x"], G.nodes[u]["y"]), (G.nodes[v]["x"], G.nodes[v]["y"])])


def _side(line: LineString, offset: float, pt: Point) -> float:
    """>0 if pt is left of the line's direction at `offset`, <0 if right."""
    a = line.interpolate(max(0.0, offset - 1.0))
    b = line.interpolate(min(line.length, offset + 1.0))
    return (b.x - a.x) * (pt.y - a.y) - (b.y - a.y) * (pt.x - a.x)


def snap_stops(Gp):
    """Project each stop onto its nearest road segment (metres, UTM), on the correct side.

    Thailand drives on the left, so a stop on the left of a direction of travel is served
    by buses going that way. On a two-way road, a stop on the right of edge u->v is put on
    the reverse edge v->u instead. Stops within CENTERLINE_M of the centreline (or with no
    clear side) are served in both directions.
    """
    crs = Gp.graph["crs"]
    snapped = {}
    for name, (lon, lat) in ORIGINAL_STOPS.items():
        pt, _ = ox.projection.project_geometry(Point(lon, lat), to_crs=crs)
        hint = ROAD_HINTS.get(name, "")
        # road="@lat lon": the pin stays where it is, but the bus stops at the road nearest
        # this point (for a pin whose closest road is a dead end the route does not use).
        at = pt
        if hint.startswith("@"):
            hint_lat, hint_lon = map(float, hint[1:].split())
            at, _ = ox.projection.project_geometry(Point(hint_lon, hint_lat), to_crs=crs)
        u, v, k = ox.nearest_edges(Gp, at.x, at.y)
        if hint and not hint.startswith("@"):
            want = hint
            named = [(a, b, c, d) for a, b, c, d in Gp.edges(keys=True, data=True)
                     if want in str(d.get("name"))]
            # Prefer the main road over service lanes that share its name (car-park entries).
            main = [e for e in named if "service" not in str(e[3].get("highway"))]
            named = [e[:3] for e in (main or named)]
            if named:
                u, v, k = min(named, key=lambda e: edge_line(Gp, *e).distance(pt))
        line = edge_line(Gp, u, v, k)
        offset = line.project(at)
        on_road = line.interpolate(offset)
        dist = pt.distance(on_road)
        two_way = Gp.has_edge(v, u)
        both = two_way and ((dist < CENTERLINE_M and name not in ONE_SIDED) or name in BOTH_SIDED)
        if two_way and not both and _side(line, offset, at) < 0:
            k2 = min(Gp[v][u], key=lambda kk: abs(Gp[v][u][kk]["length"] - Gp[u][v][k]["length"]))
            u, v, k = v, u, k2
            line = edge_line(Gp, u, v, k)
            offset = line.project(at)
            on_road = line.interpolate(offset)
        ll, _ = ox.projection.project_geometry(on_road, crs=crs, to_latlong=True)
        snapped[name] = {
            "edge": (u, v, k), "offset_m": offset, "length_m": line.length,
            "both_directions": bool(both),
            "lon": round(ll.x, 6), "lat": round(ll.y, 6),
            "original_lon": lon, "original_lat": lat,
            "snap_m": round(dist, 1),
            "road": Gp[u][v][k].get("name"),
            "two_way": two_way,
            "opposite": None,
            "passengers": name not in NO_PASSENGERS,
        }
    _pair_opposite_stops(snapped, Gp)
    return snapped


def _heading(Gp, s):
    u, v, _ = s["edge"]
    return (Gp.nodes[v]["x"] - Gp.nodes[u]["x"], Gp.nodes[v]["y"] - Gp.nodes[u]["y"])


def _flip(Gp, s):
    """Put a snapped stop on the reverse direction of its (two-way) road."""
    u, v, k = s["edge"]
    k2 = min(Gp[v][u], key=lambda kk: abs(Gp[v][u][kk]["length"] - Gp[u][v][k]["length"]))
    line = edge_line(Gp, v, u, k2)
    s["offset_m"] = max(0.0, min(line.length, line.length - s["offset_m"]))
    s["length_m"] = line.length
    s["edge"] = (v, u, k2)


def _apply_explicit_pairs(snapped, Gp):
    """Pairs declared in stops.csv ('opposite'): serve opposite directions of the road.

    Used where automatic pairing cannot tell (stops on different road segments, or a pin on
    the road centre): the stop with a clear side keeps it, its partner takes the other.
    """
    for a, b in EXPLICIT_PAIRS:
        if a not in snapped or b not in snapped:
            continue
        sa, sb = snapped[a], snapped[b]
        if not (sa["two_way"] and sb["two_way"]):
            # Divided road: each lane is already one-way, so just record the pair.
            sa["opposite"], sb["opposite"] = b, a
            continue
        if sa["both_directions"] and not sb["both_directions"]:
            sa, sb = sb, sa  # keep the side of the stop whose side is known
        ha, hb = _heading(Gp, sa), _heading(Gp, sb)
        if ha[0] * hb[0] + ha[1] * hb[1] > 0:  # same direction of travel -> flip the partner
            _flip(Gp, sb)
        sa["both_directions"] = sb["both_directions"] = False
        snapped[a]["opposite"], snapped[b]["opposite"] = b, a


def _pair_opposite_stops(snapped, Gp):
    """Keep a stop one-directional only when it has a partner across the road.

    A pair (e.g. LC3 / ลานจอดรถตรงข้าม LC3) sits on opposite directions of the same road
    within OPPOSITE_MAX_M of each other: each side serves its own direction. A stop with no
    partner is a single named stop that buses stop at in both directions (the route cards
    print one name for both directions), so it is served both ways.
    """
    _apply_explicit_pairs(snapped, Gp)
    one_way = {n: s for n, s in snapped.items()
               if s["two_way"] and not s["both_directions"] and s["opposite"] is None}
    for n, s in one_way.items():
        u, v, _ = s["edge"]
        for m, t in one_way.items():
            if m == n:
                continue
            tu, tv, _ = t["edge"]
            if (tu, tv) != (v, u):
                continue
            # Position of t measured from s's edge start u.
            t_from_u = t["length_m"] - t["offset_m"]
            if abs(s["offset_m"] - t_from_u) <= OPPOSITE_MAX_M:
                s["opposite"] = m
                break
    for n, s in snapped.items():
        if s["two_way"] and not s["both_directions"] and s["opposite"] is None and n not in ONE_SIDED:
            s["both_directions"] = True


def exits_and_entries(Gp, s):
    """Nodes a bus can drive to from the stop (exits) and arrive from (entries), with metres."""
    u, v, _ = s["edge"]
    a, L = s["offset_m"], s["length_m"]
    exits, entries = [(v, L - a)], [(u, a)]
    if s["both_directions"]:  # can also leave towards u / arrive from v
        exits.append((u, a))
        entries.append((v, L - a))
    return exits, entries


def same_segment_m(sa, sb):
    """Direct distance when both stops sit on the same road segment, else None.

    Each stop's position is expressed in the frame of every direction it can be served
    from, so stops recorded on opposite directions of the same road are handled too.
    """
    def frames(s):
        u, v, _ = s["edge"]
        out = [((u, v), s["offset_m"])]
        if s["both_directions"]:
            out.append(((v, u), s["length_m"] - s["offset_m"]))
        return out

    best = None
    for ea, pa in frames(sa):
        for eb, pb in frames(sb):
            if ea == eb and pb >= pa and (best is None or pb - pa < best):
                best = pb - pa
    return best


def road_distance_matrix(Gp, snapped):
    names = list(snapped)
    ee = {n: exits_and_entries(Gp, snapped[n]) for n in names}
    sp_cache = {}

    def node_dist(x):
        if x not in sp_cache:
            sp_cache[x] = nx.single_source_dijkstra_path_length(Gp, x, weight="length")
        return sp_cache[x]

    matrix = {}
    for a in names:
        matrix[a] = {}
        for b in names:
            if a == b:
                matrix[a][b] = 0.0
                continue
            direct = same_segment_m(snapped[a], snapped[b])
            best = direct if direct is not None else float("inf")
            for x, cx in ee[a][0]:
                dx = node_dist(x)
                for y, cy in ee[b][1]:
                    if y in dx:
                        best = min(best, cx + dx[y] + cy)
            matrix[a][b] = round(best / 1000, 3) if best < float("inf") else None
    return matrix


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--download", action="store_true", help="refetch roads from OpenStreetMap")
    args = ap.parse_args()

    G = load_graph(args.download)
    Gp = ox.project_graph(G)
    snapped = snap_stops(Gp)
    matrix = road_distance_matrix(Gp, snapped)

    stops_json = {
        n: {k: s[k] for k in ("lon", "lat", "original_lon", "original_lat", "snap_m", "road",
                               "both_directions", "opposite")} | {"passengers": n not in NO_PASSENGERS}
        for n, s in snapped.items()
    }
    STOPS_OUT.write_text(json.dumps(stops_json, indent=2, ensure_ascii=False) + "\n")
    DIST_OUT.write_text(json.dumps(matrix, indent=2) + "\n")

    for n, s in stops_json.items():
        print(f"{n:12s} moved {s['snap_m']:6.1f} m onto {s['road']} -> ({s['lon']}, {s['lat']})"
              f"{'  [both directions]' if s['both_directions'] else ''}")
    missing = [(a, b) for a in matrix for b in matrix[a] if matrix[a][b] is None]
    print(f"\nWrote {STOPS_OUT.relative_to(ROOT)} and {DIST_OUT.relative_to(ROOT)}; "
          f"unreachable pairs: {missing or 'none'}")


if __name__ == "__main__":
    main()

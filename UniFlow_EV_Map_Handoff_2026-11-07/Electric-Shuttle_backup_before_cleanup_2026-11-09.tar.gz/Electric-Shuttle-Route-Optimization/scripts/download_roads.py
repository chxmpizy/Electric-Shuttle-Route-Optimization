"""Download the campus road network, including campus service roads, from the OSM API.

The default OSMnx "drive" network drops highway=service, but several campus roads the EV
shuttles use are mapped as service roads (e.g. ถนนศรีธรรมศาสตร์ between TU Dome and
ประตูเชียงราก 1). This keeps every road a bus can drive on: public roads plus service
roads, but not parking aisles, driveways, footpaths or roads marked access=no/private.

Uses the main OSM API (api.openstreetmap.org/api/0.6/map), which works when the Overpass
servers are busy. Output: src/map/tu_rangsit_drive.graphml (read by build_osm_distances.py).
Usage (from the repo root): python scripts/download_roads.py [--offline]
  --offline rebuilds from the saved src/map/tu_rangsit_roads.osm instead of downloading.
"""
from pathlib import Path

import networkx as nx
import osmnx as ox
import requests

ROOT = Path(__file__).resolve().parents[1]
GRAPHML = ROOT / "src/map/tu_rangsit_drive.graphml"
RAW = ROOT / "src/map/tu_rangsit_roads.osm"
BBOX = (100.5916, 14.0625, 100.6193, 14.0815)  # W, S, E, N - same area as before

DRIVABLE = {"motorway", "trunk", "primary", "secondary", "tertiary", "unclassified", "residential",
            "living_street", "service", "motorway_link", "trunk_link", "primary_link",
            "secondary_link", "tertiary_link", "road"}
EXCLUDED_SERVICE = {"parking_aisle", "parking", "driveway", "drive-through", "emergency_access"}
# Ways kept even though their tags would drop them: lanes the shuttles are known to use.
ALWAYS_KEEP_WAYS = {
    1372697900, 199926253, 1372685040, 1372697901,  # รพ.ธรรมศาสตร์ drop-off loop (one-way driveways)
    228625813,  # car-park aisle to the route 3 rest point (ที่จอดรถ/ที่พักรถ) off ถนนเอเซี่ยนเกมส์
}


def _first(v):
    return v[0] if isinstance(v, list) else v


def download():
    """Download the raw OSM data for the campus area."""
    url = "https://api.openstreetmap.org/api/0.6/map?bbox=" + ",".join(f"{x:.4f}" for x in BBOX)
    r = requests.get(url, timeout=180, headers={"User-Agent": "uniflow-ev-research"})
    r.raise_for_status()
    RAW.write_bytes(r.content)
    return RAW


def build(raw: Path):

    G = ox.graph_from_xml(raw, simplify=False, retain_all=True)
    drop = []
    for u, v, k, d in G.edges(keys=True, data=True):
        hw = _first(d.get("highway"))
        restricted = (_first(d.get("access")) in ("no", "private")
                      or _first(d.get("motor_vehicle")) in ("no", "private"))
        # Campus gate lanes on public-class roads are often access=no for general traffic
        # but used by the shuttles (e.g. the outbound lane of ถนนประชาสันติ at ประตูเชียงราก 1),
        # so only restricted *service* roads (car parks, back lanes) are dropped.
        ids = d.get("osmid") if isinstance(d.get("osmid"), list) else [d.get("osmid")]
        if any(int(i) in ALWAYS_KEEP_WAYS for i in ids if i is not None):
            continue
        if (hw not in DRIVABLE or _first(d.get("service")) in EXCLUDED_SERVICE
                or (restricted and hw == "service")):
            drop.append((u, v, k))
    G.remove_edges_from(drop)
    G.remove_nodes_from(list(nx.isolates(G)))
    # Keep the largest strongly connected piece so every stop can reach every other stop.
    G = G.subgraph(max(nx.strongly_connected_components(G), key=len)).copy()
    G = ox.simplify_graph(G)
    ox.save_graphml(G, GRAPHML)
    names = {_first(d.get("name")) for _, _, d in G.edges(data=True)}
    print(f"Wrote {GRAPHML.relative_to(ROOT)}: {len(G.nodes)} nodes, {len(G.edges)} edges; "
          f"ถนนศรีธรรมศาสตร์ included: {'ถนนศรีธรรมศาสตร์' in names}")


def main():
    import sys
    raw = RAW if ("--offline" in sys.argv and RAW.exists()) else download()
    build(raw)


if __name__ == "__main__":
    main()

"""Export stops + road-following route shapes for the web /network page.

Uses the same OSM graph and stop snapping as scripts/build_osm_distances.py, and the
same routes / timing as the Python simulation (data.routes.build_fixed_routes,
data.graph.km_to_min, simulation.engine dwell/layover), so the map matches the model.

Output: web/src/data/osmNetwork.json (stops, official routes, the 3-route baseline) and
web/public/data/road_legs.json (road line and length between every pair of stops, used to draw
the routes an optimiser finds, which can join any two stops).
Usage (from the repo root): python scripts/export_web_network.py
"""
import csv
import json
import sys
from pathlib import Path

import networkx as nx
import osmnx as ox
from shapely.geometry import LineString
from shapely.ops import substring

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from build_osm_distances import edge_line, load_graph, snap_stops  # noqa: E402
from data.graph import build_graph, get_real_dist, km_to_min, make_bidirectional  # noqa: E402
from data.routes import BASELINE_ROUTES, OFFICIAL_ROUTES, build_baseline_routes, build_fixed_routes  # noqa: E402

OFFICIAL_BY_ID = {r["id"]: r for r in OFFICIAL_ROUTES}
BASELINE_BY_ID = {r["id"]: r for r in BASELINE_ROUTES}
from simulation.engine import DWELL_TIME_MIN, LAYOVER_TIME_MIN  # noqa: E402

OUT = ROOT / "web/src/data/osmNetwork.json"
LEGS_OUT = ROOT / "web/public/data/road_legs.json"


def leg_geometry(Gp, sa, sb):
    """Shortest road line (projected metres) from snapped stop sa to snapped stop sb."""
    ua, va, ka = sa["edge"]
    ub, vb, kb = sb["edge"]
    la, lb = edge_line(Gp, ua, va, ka), edge_line(Gp, ub, vb, kb)
    a, b = sa["offset_m"], sb["offset_m"]

    candidates = []
    # Same segment, driving straight along it.
    if (ua, va) == (ub, vb):
        if b >= a:
            candidates.append((b - a, [substring(la, a, b)]))
        elif sa["both_directions"] and sb["both_directions"]:
            candidates.append((a - b, [substring(la, a, b)]))  # reversed direction

    exits = [(va, la.length - a, substring(la, a, la.length))]
    if sa["both_directions"]:
        exits.append((ua, a, substring(la, a, 0)))
    entries = [(ub, b, substring(lb, 0, b))]
    if sb["both_directions"]:
        entries.append((vb, lb.length - b, substring(lb, lb.length, b)))

    for x, cx, gx in exits:
        dist, paths = nx.single_source_dijkstra(Gp, x, weight="length")
        for y, cy, gy in entries:
            if y not in dist:
                continue
            parts = [gx]
            p = paths[y]
            for u, v in zip(p, p[1:]):
                k = min(Gp[u][v], key=lambda kk: Gp[u][v][kk]["length"])
                parts.append(edge_line(Gp, u, v, k))
            parts.append(gy)
            candidates.append((cx + dist[y] + cy, parts))

    _, parts = min(candidates, key=lambda c: c[0])
    coords = []
    for part in parts:
        pts = list(part.coords) if isinstance(part, LineString) else [part.coords[0]]
        if coords and pts and coords[-1] == pts[0]:
            pts = pts[1:]
        coords.extend(pts)
    return LineString(coords) if len(coords) > 1 else LineString(coords * 2)


def to_latlon(line, crs):
    ll, _ = ox.projection.project_geometry(line, crs=crs, to_latlong=True)
    return [[round(lat, 6), round(lon, 6)] for lon, lat in ll.coords]


def net_route(r, resolved, Gp, snapped, crs):
    """One route in the web's format. `resolved` holds the exact roads from build_routes.py."""
    legs = []
    pairs = list(zip(r["path"], r["path"][1:]))
    if r["path"][-1] != r["path"][0]:
        pairs.append((r["path"][-1], r["path"][0]))  # loop back to the first stop
    if resolved and len(resolved["legs"]) == len(pairs):
        for lg in resolved["legs"]:
            km = lg["km"]
            legs.append({"from": lg["from"], "to": lg["to"], "km": round(km, 3),
                         "minutes": km_to_min(km), "coords": lg["coords"]})
    else:
        for a, b in pairs:
            km = get_real_dist(a, b)
            legs.append({
                "from": a, "to": b, "km": round(km, 3), "minutes": km_to_min(km),
                "coords": to_latlon(leg_geometry(Gp, snapped[a], snapped[b]), crs),
            })
    return {
        "id": r["route_id"], "name": r.get("name", str(r["route_id"])),
        "color": r.get("color"), "path": r["path"], "numBus": r["num_bus"],
        "cycleTime": r["cycle_time"], "headway": r["headway"],
        "startTime": r["startTime"], "endTime": r["endTime"],
        "totalKm": round(sum(l["km"] for l in legs), 3), "legs": legs,
    }


def road_legs(stops, Gp, snapped, crs):
    return {
        a: {b: {"km": round(get_real_dist(a, b), 3),
                "coords": to_latlon(leg_geometry(Gp, snapped[a], snapped[b]), crs)}
            for b in stops if b != a}
        for a in stops
    }


def main():
    Gp = ox.project_graph(load_graph(download=False))
    crs = Gp.graph["crs"]
    snapped = snap_stops(Gp)
    graph = make_bidirectional(build_graph())

    stop_routes = {}
    out_routes = []
    for r in build_fixed_routes(graph):
        for s in r["path"]:
            stop_routes.setdefault(s, set()).add(r["route_id"])
        out_routes.append(net_route(r, OFFICIAL_BY_ID.get(r["route_id"]), Gp, snapped, crs))
    baseline_routes = [net_route(r, BASELINE_BY_ID.get(r["route_id"]), Gp, snapped, crs)
                       for r in build_baseline_routes(graph)]

    # Every passenger stop from data/raw/stops.csv (the Depot is a yard, not a stop),
    # including stops that no route serves yet.
    with (ROOT / "data/raw/stops.csv").open(encoding="utf-8") as f:
        verified = {r["id"]: r["verified"].strip().lower() == "yes" for r in csv.DictReader(f)}
    used = [s for s in snapped if s != "Depot"]
    data = {
        "source": "OpenStreetMap drive network (src/map/tu_rangsit_drive.graphml)",
        "speedKmh": round(60 / km_to_min(1.0), 1),
        "dwellMin": DWELL_TIME_MIN,
        "layoverMin": LAYOVER_TIME_MIN,
        "stops": [
            {"id": s, "lat": snapped[s]["lat"], "lon": snapped[s]["lon"],
             "originalLat": snapped[s]["original_lat"], "originalLon": snapped[s]["original_lon"],
             "snapM": snapped[s]["snap_m"], "verified": verified.get(s, False),
             "bothDirections": snapped[s]["both_directions"],
             "passengers": snapped[s].get("passengers", True),
             "routes": sorted(stop_routes.get(s, []))}
            for s in used
        ],
        "routes": out_routes,
        "baselineRoutes": baseline_routes,
    }
    OUT.write_text(json.dumps(data, ensure_ascii=False, indent=1) + "\n")
    LEGS_OUT.parent.mkdir(parents=True, exist_ok=True)
    LEGS_OUT.write_text(json.dumps(road_legs(used, Gp, snapped, crs), ensure_ascii=False, separators=(",", ":")) + "\n",
                        encoding="utf-8")
    print(f"Wrote {LEGS_OUT.relative_to(ROOT)}")
    print(f"Wrote {OUT.relative_to(ROOT)}: {len(used)} stops, {len(out_routes)} routes")
    for r in out_routes:
        print(f"  route {r['id']}: {r['totalKm']:.2f} km, cycle {r['cycleTime']} min, "
              f"{sum(len(l['coords']) for l in r['legs'])} points")


if __name__ == "__main__":
    main()

"""
src/simulation/engine.py
=========================
Discrete-Event Bus-Passenger Simulation Engine

การเปลี่ยนแปลงจากเวอร์ชันก่อน:
  1. รองรับ passenger_demand (list[PassengerDemand]) แทนการสุ่ม
  2. เวลาเดินทางระหว่างป้ายดึงจาก Network Graph จริง ไม่ใช่หารเฉลี่ย
  3. ผลลัพธ์รวมสถิติ on_time, late, stranded, delay_minutes
  4. บันทึก Event Log สำหรับ Monitor และ Mobility Visualization
"""
from __future__ import annotations
import heapq
import random
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    import networkx as nx

from .Bus import Bus
from .Passenger import Passenger

try:  # stops facing each other across a road count as one place for passengers
    from data.graph import NO_PASSENGER_STOPS, STOP_PARTNER
except ImportError:  # pragma: no cover - engine used without the data package
    STOP_PARTNER, NO_PASSENGER_STOPS = {}, set()


def _place(stop: str) -> str:
    partner = STOP_PARTNER.get(stop)
    return min(stop, partner) if partner else stop


# A normal passenger takes a bus heading to their stop, not one that goes the long way
# round: they skip a bus whose ride is longer than this compared with the fastest bus
# serving the same trip from the same place (either side of the road).
DETOUR_FACTOR: float = 1.5
DETOUR_SLACK_MIN: float = 5.0


def _ride_table(route: list[str], seg_times: list[float]) -> list[dict[str, float]]:
    """For each index i: minutes riding from route[i] to each place ahead in this loop."""
    n = len(route)
    table = []
    for i in range(n):
        rides: dict[str, float] = {}
        minutes = 0.0
        for j in range(i + 1, n + 1):  # j == n means arriving back at route[0] (end of loop)
            minutes += seg_times[(j - 1) % len(seg_times)] if seg_times else 1.0
            stop = route[j % n]
            if stop not in NO_PASSENGER_STOPS:
                rides.setdefault(_place(stop), minutes)
            minutes += DWELL_TIME_MIN
        table.append(rides)
    return table


def _places_ahead(route: list[str], index: int) -> set[str]:
    """Places a passenger boarding at route[index] can still reach in this loop.

    Each loop runs from START (route[0], or the stop after a rest point) to the end of
    the path and back to route[0]; everyone is off by then, so a passenger only boards
    for a stop later in the same loop (no riding on into the next loop).
    """
    ahead = {_place(s) for s in route[index + 1:] if s not in NO_PASSENGER_STOPS}
    if route[0] not in NO_PASSENGER_STOPS:
        ahead.add(_place(route[0]))  # arriving back at START ends the loop
    return ahead

# ─── Legacy STOP_WEIGHTS ใช้สำหรับ Random Mode เท่านั้น ────────────────────
STOP_WEIGHTS = {
    "Dome": 81, "Hospital": 200, "Dorm": 2500, "Gate1": 80,
    "Library": 846, "Park": 200, "SC1": 600, "SC2_SC3": 600,
    "Green": 100, "Convention": 150, "Terminal": 212,
    "Lecture": 1100, "Health": 1023, "Social": 1500,
}

DWELL_TIME_MIN: float = 1.5   # นาทีหยุดรับ-ส่งที่ป้าย
LAYOVER_TIME_MIN: float = 5.0  # นาทีพักปลายรอบ


def _get_segment_time(
    graph: "nx.DiGraph",
    from_stop: str,
    to_stop: str,
    fallback_min: float = 3.0,
) -> float:
    """
    ดึงเวลาเดินทาง (นาที) จาก Network Graph จริง
    ใช้ Edge Weight โดยตรง ไม่หารเฉลี่ย
    """
    try:
        return float(graph[from_stop][to_stop]["weight"])
    except (KeyError, TypeError):
        pass
    try:
        import networkx as nx
        return float(nx.shortest_path_length(graph, from_stop, to_stop, weight="weight"))
    except Exception:
        return fallback_min


def _build_segment_times(
    route_path: list[str],
    graph: Optional["nx.DiGraph"],
    cycle_time: float,
) -> list[float]:
    """
    สร้าง list ของเวลาเดินทางแต่ละช่วงใน route_path
    ถ้ามี graph ใช้ข้อมูลจริง ถ้าไม่มี fallback เป็นการหารเฉลี่ย
    """
    if graph is not None:
        times = []
        for i in range(len(route_path) - 1):
            times.append(_get_segment_time(graph, route_path[i], route_path[i + 1]))
        # Routes are loops: the bus wraps from the last stop back to index 0, so add the
        # closing leg (last -> first); otherwise the wrap reuses the previous leg's time.
        if len(route_path) > 1 and route_path[-1] != route_path[0]:
            times.append(_get_segment_time(graph, route_path[-1], route_path[0]))
        return times
    # Fallback: หารเฉลี่ย (legacy)
    n = max(1, len(route_path) - 1)
    avg = cycle_time / n
    return [avg] * n


def _would_be_on_time(passenger: Passenger, t: float, ride: float) -> bool:
    """
    ถ้าผู้โดยสารได้ขึ้นรถคันนี้ที่เวลา t จะถึงอาคารทันเรียนหรือไม่
    ใช้แยกกรณี "รถเต็ม" (รถคันที่ทันมาแล้วแต่ขึ้นไม่ได้) ออกจาก "มาไม่ทัน"
    """
    if passenger.class_start_time is None:
        return True
    arrive = t + DWELL_TIME_MIN + ride + passenger.walk_time_minutes
    return arrive <= passenger.class_start_time


def run_simulation(
    active_routes: list[dict],
    stops: list[str],
    simulation_time: int = 60,
    bus_capacity: int = 30,
    passenger_demands=None,   # list[PassengerDemand] | None
    graph=None,               # nx.DiGraph | None
    seed: Optional[int] = None,
) -> dict:
    """
    จำลองการเดินรถบัสและผู้โดยสาร

    Parameters
    ----------
    active_routes      : รายการ route dict จาก chromosome
    stops              : ป้ายทั้งหมดในระบบ
    simulation_time    : ระยะเวลาจำลอง (นาที, นับจาก t=0)
    bus_capacity       : ความจุรถ (ที่นั่ง)
    passenger_demands  : list[PassengerDemand] จาก timetable (None = สุ่ม)
    graph              : NetworkX DiGraph สำหรับคำนวณเวลาระหว่างป้าย
    seed               : Random seed สำหรับ reproducibility

    Returns
    -------
    dict ของสถิติการจำลอง รวมถึง on_time_rate, avg_delay, stranded_count
    """
    # ใช้ RNG เฉพาะของ simulation — ห้าม random.seed() ตัว global เพราะจะรีเซ็ต
    # ลำดับสุ่มของ algorithm ทุกครั้งที่ evaluate ทำให้ seed ของ benchmark ไม่มีผล
    rng = random.Random(seed)

    # ─── 1. สร้างคิวผู้โดยสารแต่ละป้าย ────────────────────────────────────
    # Queues are per place: a pair of stops facing each other across a road (e.g. SC1 /
    # SC1_Opp) is one place. A passenger crosses to whichever side has a bus going their
    # way, so they can board a bus on either side (if their stop is ahead in its loop).
    queues: dict[str, list[Passenger]] = {_place(stop): [] for stop in stops}
    all_passengers: list[Passenger] = []

    if passenger_demands is not None:
        # โหมดตารางเรียน: แปลง PassengerDemand → Passenger
        for d in passenger_demands:
            if _place(d.origin) not in queues:
                queues[_place(d.origin)] = []
            p = Passenger(
                passenger_id=d.passenger_id,
                origin=d.origin,
                destination=d.destination,
                arrival_time=d.arrival_at_stop,
                class_start_time=d.class_start_time,
                walk_time_minutes=d.walk_time_minutes,
                arrive_before_min=15.0,
                course_code=d.course_code,
            )
            all_passengers.append(p)
    else:
        # โหมด Legacy: สุ่มผู้โดยสาร (ไว้ใช้ทดสอบและ Benchmark กับ Baseline)
        first_service = min((r["startTime"] for r in active_routes), default=0)
        last_service = max((r["endTime"] for r in active_routes), default=simulation_time)
        pid = 0
        for t in range(simulation_time):
            if not (first_service <= t <= last_service):
                continue
            hour = t / 60
            demand_prob = 0.8 if 7.5 <= hour < 10 or 11.5 <= hour < 13.5 else 0.25
            if rng.random() >= demand_prob:
                continue
            pax_stops = [s for s in stops if s not in NO_PASSENGER_STOPS]
            wts = [STOP_WEIGHTS.get(s, 100) for s in pax_stops]
            origin = rng.choices(pax_stops, weights=wts, k=1)[0]
            dest = rng.choices(pax_stops, weights=wts, k=1)[0]
            while _place(dest) == _place(origin):
                dest = rng.choices(pax_stops, weights=wts, k=1)[0]
            p = Passenger(
                passenger_id=pid,
                origin=origin,
                destination=dest,
                arrival_time=float(t),
            )
            all_passengers.append(p)
            pid += 1

    # ใส่คิวตามเวลามาถึง (จะ enqueue ตอนครบเวลาใน loop)
    pending = sorted(all_passengers, key=lambda p: p.arrival_time)

    # ─── 2. สร้างรถบัสพร้อม segment times จากกราฟจริง ─────────────────────
    buses: list[Bus] = []
    bus_id = 0
    ride_tables: dict[int, list[dict[str, float]]] = {}
    for route_info in active_routes:
        route_path = route_info["path"]
        num_bus = route_info.get("num_bus", 5)
        start_time = route_info["startTime"]
        headway = route_info["headway"]
        cycle_time = route_info.get("cycle_time", len(route_path) - 1)
        end_time = route_info["endTime"]

        seg_times = _build_segment_times(route_path, graph, cycle_time)
        ride_tables[id(route_path)] = _ride_table(route_path, seg_times)

        for i in range(num_bus):
            buses.append(Bus(
                bus_id=bus_id,
                capacity=bus_capacity,
                route=route_path,
                headway=headway,
                next_depart_time=round(start_time + (i * headway), 2),
                end_time=end_time,
                segment_times=seg_times,
            ))
            bus_id += 1

    # Fastest ride for each (origin place, destination place) over all routes / sides.
    best_ride: dict[tuple[str, str], float] = {}
    for route_info in active_routes:
        path = route_info["path"]
        for i, rides in enumerate(ride_tables[id(path)]):
            if path[i] in NO_PASSENGER_STOPS:
                continue
            for dest_place, minutes in rides.items():
                key = (_place(path[i]), dest_place)
                if minutes < best_ride.get(key, float("inf")):
                    best_ride[key] = minutes

    # ─── 3. Event Log สำหรับ Monitor / Visualization ───────────────────────
    event_log: list[dict] = []

    # ─── 4. Simulation Loop ────────────────────────────────────────────────
    # Event-driven: 1 event = รถถึงป้าย ณ เวลาจริง ไม่ปัดเป็นนาทีเต็ม รอบรถจึงเท่ากับ cycle_time
    # เวลาเท่ากันให้รถลำดับก่อนทำงานก่อน เพื่อให้ผลซ้ำได้
    arrival_events = [(bus.next_depart_time, i) for i, bus in enumerate(buses)]
    heapq.heapify(arrival_events)
    next_passenger = 0

    while arrival_events:
        t, bus_index = heapq.heappop(arrival_events)
        if t >= simulation_time:
            break

        # Enqueue ผู้โดยสารที่ถึงป้ายแล้ว
        while next_passenger < len(pending) and pending[next_passenger].arrival_time <= t:
            p = pending[next_passenger]
            if _place(p.origin) in queues:
                queues[_place(p.origin)].append(p)
            next_passenger += 1

        # เคลื่อนรถและรับ-ส่งผู้โดยสาร
        bus = buses[bus_index]
        if t > bus.endTime:
            continue

        # เวลาออกจากป้ายนี้ = ถึงป้าย + จอดรับส่ง (+ พักปลายรอบที่ป้ายแรก)
        depart = t + DWELL_TIME_MIN
        if bus.started:
            # เคลื่อนมาถึงป้ายถัดไป
            bus.current_index = (bus.current_index + 1) % len(bus.route)
            if bus.current_index == 0:
                depart += LAYOVER_TIME_MIN
                bus.trip_count += 1
        else:
            bus.started = True
        # เวลาถึงป้ายถัดไป = ออกจากป้าย + เวลาวิ่งช่วงป้ายนี้ → ป้ายถัดไป
        # (segment i = route[i] → route[i+1] เหมือน _ride_table)
        seg = bus.segment_times[bus.current_index % len(bus.segment_times)] if bus.segment_times else 1.0
        bus.next_depart_time = round(depart + seg, 2)  # กันเศษทศนิยมสะสม (เวลาช่วงป้ายละเอียด 0.01 นาที)
        heapq.heappush(arrival_events, (bus.next_depart_time, bus_index))

        current_stop = bus.route[bus.current_index]

        # ลงรถ  (ไม่มีการขึ้น-ลงที่จุดพักรถ)
        alighted = []
        remaining_on_bus = []
        here = _place(current_stop)
        no_service = current_stop in NO_PASSENGER_STOPS
        for p in bus.passengers:
            if not no_service and _place(p.destination) == here:
                p.alight(t)
                alighted.append(p)
            else:
                remaining_on_bus.append(p)
        bus.passengers = remaining_on_bus

        # ขึ้นรถ
        boarded = []
        new_queue = []
        # Board only if this bus reaches the passenger's stop later in this loop, and not
        # by going much further round than the fastest bus for that trip.
        rides = {} if no_service else ride_tables[id(bus.route)][bus.current_index]
        for p in queues.get(here, []):
            dest = _place(p.destination)
            ride = rides.get(dest)
            ok = ride is not None and ride <= best_ride.get((here, dest), ride) * DETOUR_FACTOR + DETOUR_SLACK_MIN
            if len(bus.passengers) < bus.capacity and ok:
                p.board(t)
                bus.passengers.append(p)
                boarded.append(p)
            else:
                if ok and _would_be_on_time(p, t, ride):
                    # รถที่ยังพาไปทันเรียนมาถึงแล้ว แต่เต็ม → กรณี BUS_FULL
                    p.denied_full_count += 1
                new_queue.append(p)
        if here in queues:
            queues[here] = new_queue

        # สะสม counter รายคัน (feedback #6: Monitor utilization)
        bus.total_boarded += len(boarded)
        bus.total_alighted += len(alighted)

        # บันทึก Event
        if alighted or boarded:
            event_log.append({
                "t": t,
                "bus_id": bus.id,
                "stop": current_stop,
                "boarded": len(boarded),
                "alighted": len(alighted),
                "on_bus": len(bus.passengers),
                "queue_remaining": len(queues.get(here, [])),
            })

    # คนที่มาถึงป้ายหลังรถคันสุดท้าย ยังรออยู่จนจบการจำลอง
    for p in pending[next_passenger:]:
        if p.arrival_time < simulation_time and _place(p.origin) in queues:
            queues[_place(p.origin)].append(p)

    # ─── 5. สิ้นสุด Simulation: Mark คนตกค้าง ────────────────────────────
    for stop, q in queues.items():
        for p in q:
            p.strand()
    for bus in buses:
        for p in bus.passengers:
            # คนค้างบนรถ = ไม่ถึงปลายทาง ถือเป็น stranded ด้วย
            p.strand()

    # ─── 6. รวมสถิติ ──────────────────────────────────────────────────────
    served = [p for p in all_passengers if p.is_served]
    stranded = [p for p in all_passengers if p.is_stranded]
    with_class = [p for p in served if p.class_start_time is not None]
    on_time = [p for p in with_class if p.is_on_time]
    late_pax = [p for p in with_class if not p.is_on_time]

    wait_times = [p.wait_time for p in served if p.board_time is not None]
    travel_times = [p.travel_time for p in served if p.drop_time is not None]
    delay_times = [p.delay_minutes for p in late_pax]

    avg_wait = sum(wait_times) / len(wait_times) if wait_times else 0.0
    avg_travel = sum(travel_times) / len(travel_times) if travel_times else 0.0
    avg_delay = sum(delay_times) / len(delay_times) if delay_times else 0.0
    # ตัวหารรวมคนตกค้างด้วย ไม่งั้นตารางที่รับคนได้น้อยจะได้ on-time สูงเกินจริง
    all_with_class = [p for p in all_passengers if p.class_start_time is not None]
    on_time_rate = len(on_time) / len(all_with_class) * 100 if all_with_class else 0.0

    # ─── 3 กรณีของ goal function (ดู Passenger.outcome) ──────────────────
    outcome_counts = {"ON_TIME": 0, "MISSED": 0, "BUS_FULL": 0}
    for p in all_passengers:
        outcome_counts[p.outcome] += 1

    # ─── Per-bus utilization (feedback #6: Monitor each bus) ──────────────
    bus_stats: list[dict] = []
    for b in buses:
        util_pct = (b.total_boarded / (b.trip_count * b.capacity) * 100) if b.trip_count > 0 and b.capacity > 0 else 0.0
        bus_stats.append({
            "bus_id": b.id,
            "route": b.route,
            "capacity": b.capacity,
            "trips": b.trip_count,
            "boarded": b.total_boarded,
            "alighted": b.total_alighted,
            "ended_with_pax": len(b.passengers),
            "utilization_pct": round(util_pct, 2),
        })
    total_trips = sum(b.trip_count for b in buses)
    fleet_util = (sum(b.total_boarded for b in buses) /
                  max(1, total_trips * bus_capacity) * 100) if buses else 0.0

    # ─── Mobility: Origin-Destination matrix (feedback #5) ────────────────
    od_counts: dict[tuple, int] = {}
    for p in all_passengers:
        key = (p.origin, p.destination)
        od_counts[key] = od_counts.get(key, 0) + 1
    od_matrix = [
        {"from": o, "to": d, "count": c}
        for (o, d), c in sorted(od_counts.items(), key=lambda kv: -kv[1])
    ]

    # ─── Mobility: time series — waiting / on-bus / arrived ──────────────
    # Bin by 10-minute buckets so the series is dashboard-friendly
    BUCKET = 10
    n_buckets = (simulation_time // BUCKET) + 1
    arrived_cum = [0] * n_buckets
    boarded_cum = [0] * n_buckets  # cumulative boardings
    arrival_at_stop_cum = [0] * n_buckets  # cumulative passengers who've reached their stop

    for p in all_passengers:
        if p.drop_time is not None:
            idx = min(n_buckets - 1, int(p.drop_time // BUCKET))
            arrived_cum[idx] += 1
        if p.board_time is not None:
            idx = min(n_buckets - 1, int(p.board_time // BUCKET))
            boarded_cum[idx] += 1
        if p.arrival_time is not None:
            idx = min(n_buckets - 1, int(p.arrival_time // BUCKET))
            arrival_at_stop_cum[idx] += 1

    # Convert to running totals
    for i in range(1, n_buckets):
        arrived_cum[i] += arrived_cum[i - 1]
        boarded_cum[i] += boarded_cum[i - 1]
        arrival_at_stop_cum[i] += arrival_at_stop_cum[i - 1]

    timeseries = []
    for i in range(n_buckets):
        t_minute = i * BUCKET
        waiting = arrival_at_stop_cum[i] - boarded_cum[i]  # มาถึงป้ายแล้ว แต่ยังไม่ขึ้นรถ
        on_bus = boarded_cum[i] - arrived_cum[i]           # ขึ้นรถแล้ว แต่ยังไม่ถึงปลายทาง
        timeseries.append({
            "t": t_minute,
            "waiting": max(0, waiting),
            "on_bus": max(0, on_bus),
            "arrived": arrived_cum[i],
        })

    return {
        # ─ เวลาเฉลี่ย (Backward compatible) ─
        "avg_wait_time": round(avg_wait, 2),
        "avg_travel_time": round(avg_travel, 2),
        # ─ ผลตรง ๆ ─
        "total_passengers": len(all_passengers),
        "served_passengers": len(served),
        "stranded_passengers": len(stranded),     # ตกค้างที่ป้าย + ค้างบนรถ
        "waiting_passengers": sum(len(q) for q in queues.values()),  # ยังรอ
        # ─ Punctuality ─
        "passengers_with_class": len(with_class),
        "on_time_passengers": len(on_time),
        "late_passengers": len(late_pax),
        "on_time_rate_pct": round(on_time_rate, 2),
        "avg_delay_minutes": round(avg_delay, 2),
        "max_delay_minutes": round(max(delay_times, default=0.0), 2),
        # ─ 3 กรณีของ goal function ─
        "case_on_time": outcome_counts["ON_TIME"],      # มาทันป้ายและขึ้นรถทัน
        "case_missed": outcome_counts["MISSED"],        # มาไม่ทันป้าย
        "case_bus_full": outcome_counts["BUS_FULL"],    # มาทันป้ายแต่รถเต็ม
        # ─ Monitor per-bus (feedback #6) ─
        "bus_stats": bus_stats,
        "total_buses": len(buses),
        "total_trips": total_trips,
        "fleet_utilization_pct": round(fleet_util, 2),
        # ─ Mobility (feedback #5): O-D matrix + passenger-flow time series ─
        "od_matrix": od_matrix,
        "mobility_timeseries": timeseries,
        # ─ Event log สำหรับ Visualization เชิงลึก ─
        "event_log": event_log,
    }

"""Bootstrap helpers for building the optimization pipeline."""
import random
import networkx as nx
from config.settings import (
    END_TIME,
    MAX_PER_ROUTE,
    MIN_PER_ROUTE,
    RANDOM_SEED,
    START_TIME,
    TOTAL_BUSES,
)
from data.cleaning import load_routes
from data.graph import build_graph, make_bidirectional
from data.timetable import load_cs_student_trips
from data.routes import HUB_STOPS, build_baseline_routes, get_all_stops
from optimization.context import RouteContext
# วันที่จำลอง: อังคาร — นักศึกษาเดินทางครบทั้ง 420 คน (มากที่สุดในสัปดาห์ เท่ากับพฤหัส)
DEMAND_DAY = "อังคาร"
DEMAND_TERM = 1
DEMAND_YEARS = (1, 2, 3)
STUDENTS_PER_YEAR = 70  # ต่อชั้นปี ต่อภาค → ปี 1–3 × ปกติ/พิเศษ = 420 คน


def setup_environment(seed: int = RANDOM_SEED) -> tuple[nx.DiGraph, list[dict], list[str], RouteContext]:
    """Load data, build graph, and return shared optimization context."""
    random.seed(seed)
    _ = load_routes()
    graph = make_bidirectional(build_graph())
    fixed_routes = build_baseline_routes(graph)
    stops = get_all_stops()
    ctx = RouteContext(
        graph=graph,
        stops=stops,
        hub_stops=HUB_STOPS,
        num_routes=len(fixed_routes),
        min_per_route=MIN_PER_ROUTE,
        max_per_route=MAX_PER_ROUTE,
        total_buses=TOTAL_BUSES,
        start_time=START_TIME,
        end_time=END_TIME,
    )
    # Demand ชุดเดียวกับ cs_benchmark.py — นักศึกษา CS 420 คน คนละ 1 เที่ยว: หอพัก → คาบแรกของวัน
    demands = load_cs_student_trips(
        DEMAND_DAY,
        years=DEMAND_YEARS,
        term=DEMAND_TERM,
        graph=graph,
        students_per_year=STUDENTS_PER_YEAR,
    )
    if demands:
        ctx.passenger_demands = demands
        ctx.end_time = max(max(int(d.class_start_time) + 60 for d in demands), 900)
        ctx.eval_seed = seed
    return graph, fixed_routes, stops, ctx
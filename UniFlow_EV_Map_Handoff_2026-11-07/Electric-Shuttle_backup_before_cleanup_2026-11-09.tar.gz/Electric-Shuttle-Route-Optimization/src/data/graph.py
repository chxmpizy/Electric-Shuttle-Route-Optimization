import networkx as nx
def km_to_min(km: float, speed_kmh: float = 50.0) -> float:

    return round(km * 60 / speed_kmh, 2)
def _add_route_edges(graph: nx.DiGraph, edges: list[tuple[str, str, float]]) -> None:

    for source, target, km in edges:
        graph.add_edge(source, target, weight=km_to_min(km))

import json
import math
from pathlib import Path

# Stop coordinates (lon, lat) on the road. Source of truth: data/raw/stops.csv,
# snapped onto OSM roads by scripts/build_osm_distances.py -> osm_stops.json.
_OSM_STOPS_FILE = Path(__file__).with_name("osm_stops.json")
_OSM_STOPS = json.loads(_OSM_STOPS_FILE.read_text(encoding="utf-8"))
GPS_COORDS = {stop: (info["lon"], info["lat"]) for stop, info in _OSM_STOPS.items()}

# Stops facing each other across a road (e.g. SC1 / SC1_Opp) are the same place for a
# passenger: buses in each direction use their own side.
STOP_PARTNER = {stop: info["opposite"] for stop, info in _OSM_STOPS.items() if info.get("opposite")}


# Bus rest points (stops.csv passengers=no): buses stop there but nobody gets on or off.
NO_PASSENGER_STOPS = {stop for stop, info in _OSM_STOPS.items() if info.get("passengers") is False}


def same_place(a: str, b: str) -> bool:
    return a == b or STOP_PARTNER.get(a) == b

def haversine(lon1, lat1, lon2, lat2):
    # Calculate the great circle distance between two points in km.
    R = 6371.0 # Earth radius in km
    dlon = math.radians(lon2 - lon1)
    dlat = math.radians(lat2 - lat1)
    a = math.sin(dlat / 2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

# Directed road distances (km) along real OpenStreetMap roads, one-way streets respected.
# Regenerate with: python scripts/build_osm_distances.py
_OSM_DIST_FILE = Path(__file__).with_name("osm_distance_km.json")
OSM_DIST_KM = json.loads(_OSM_DIST_FILE.read_text()) if _OSM_DIST_FILE.exists() else {}


def get_real_dist(stop1, stop2, routing_factor=1.3):
    """Road distance in km from stop1 to stop2.

    Uses the OSM road-distance matrix when available; otherwise falls back to
    straight-line (haversine) distance x routing_factor.
    """
    osm_km = OSM_DIST_KM.get(stop1, {}).get(stop2)
    if osm_km is not None:
        return max(0.1, osm_km)
    if stop1 not in GPS_COORDS or stop2 not in GPS_COORDS:
        return 1.0
    lon1, lat1 = GPS_COORDS[stop1]
    lon2, lat2 = GPS_COORDS[stop2]
    dist_km = haversine(lon1, lat1, lon2, lat2)
    return max(0.1, dist_km * routing_factor)

def build_graph() -> nx.DiGraph:
 
    graph = nx.DiGraph()
    stops = [
        "Dorm", "Green", "SC2_SC3", "Health", "Lecture",
        "Convention", "Terminal", "Library", "Hospital", "Park",
        "Dome", "Gate1", "SC1", "Social",
    ]
    graph.add_nodes_from(stops)
    
    edges_list = [
        ("Dorm", "Green"), ("Green", "SC2_SC3"), ("SC2_SC3", "Health"), ("Health", "Lecture"), ("Lecture", "Dorm"),
        ("Convention", "Terminal"), ("Terminal", "SC2_SC3"), ("SC2_SC3", "Library"), ("Library", "Dorm"), ("Dorm", "Convention"),
        ("Convention", "Dorm"), ("Dorm", "Library"), ("Library", "SC2_SC3"), ("SC2_SC3", "Terminal"), ("Terminal", "Convention"),
        ("Convention", "Hospital"), ("Hospital", "Health"), ("Health", "Park"), ("Park", "Lecture"), ("Lecture", "Convention"),
        ("Dome", "Gate1"), ("Gate1", "SC1"), ("SC1", "Library"), ("Library", "Green"), ("Green", "Dorm"),
        ("Convention", "Social"), ("Social", "Lecture"), ("Lecture", "Park"), ("Park", "Health"), ("Health", "Hospital")
    ]
    
    for s, t in edges_list:
        km = get_real_dist(s, t)
        graph.add_edge(s, t, weight=km_to_min(km))
        
    return graph
def make_bidirectional(graph: nx.DiGraph) -> nx.DiGraph:
    edges = list(graph.edges(data=True))
    for source, target, data in edges:
        # Road distance is direction-dependent (one-way streets), so use the reverse
        # OSM distance when we have it instead of copying the forward weight.
        if OSM_DIST_KM.get(target, {}).get(source) is not None:
            weight = km_to_min(get_real_dist(target, source))
        else:
            weight = data["weight"]
        graph.add_edge(target, source, weight=weight)
    return graph
def calculate_cycle_time(route_path: list[str], graph: nx.DiGraph) -> float:
  
    # Routes are loops: after the last stop the bus drives back to the first one.
    legs = list(zip(route_path, route_path[1:]))
    if len(route_path) > 1 and route_path[-1] != route_path[0]:
        legs.append((route_path[-1], route_path[0]))
    driving_time = 0.0
    for current_stop, next_stop in legs:
        try:
            driving_time += graph[current_stop][next_stop]["weight"]
        except KeyError:
            try:
                driving_time += nx.shortest_path_length(
                    graph,
                    source=current_stop,
                    target=next_stop,
                    weight="weight",
                )
            except nx.NetworkXNoPath:
                driving_time += 999
                
    # Realistic time factors
    num_stops = len(route_path)
    dwell_time_per_stop = 1.5  # 1.5 minutes for parking, boarding, and alighting per stop
    layover_time = 5.0         # 5 minutes driver rest/buffer time at the end of the loop
    
    total_time = driving_time + (num_stops * dwell_time_per_stop) + layover_time
    return round(total_time, 2)
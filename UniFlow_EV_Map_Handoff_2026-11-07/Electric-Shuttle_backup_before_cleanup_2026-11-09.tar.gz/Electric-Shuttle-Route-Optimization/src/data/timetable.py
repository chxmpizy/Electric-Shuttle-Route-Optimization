"""
src/data/timetable.py
======================
อ่านตารางเรียน CS จาก Excel แล้วแปลงเป็นรายการ PassengerDemand

อ้างอิงวิธีคำนวณเวลาจาก:
  Díaz-Ramírez et al. (2022) "A smart school routing and scheduling problem
  for the new normalcy", Computers & Industrial Engineering 168, 108101.
  DOI: 10.1016/j.cie.2022.108101

  Section 3.1: arrival window ที่ถูกต้องคือช่วงเวลาที่ผู้โดยสาร
               มาถึงได้ "สมเหตุสมผล" — ไม่ช้าเกิน (สาย) ไม่เร็วเกิน (รอนาน)
  Section 3.3: สมการพื้นฐาน
      arrival_at_building = drop_time + walk_time_to_building
      delay               = max(0, arrival_at_building - class_start_time)

  วิธีกำหนดเวลามาถึงป้าย (สอดคล้องกับ paper Section 3.1 & 5.1):
      travel_time_est     = Shortest-Path บนกราฟ (ระยะถนนจริงจาก OSM; ถ้าไม่มีใช้ Haversine × routing_factor)
                            ← paper ใช้ Google Maps API ส่วนเราใช้ OSM-derived graph
      target_at_stop      = class_start - walk_time - travel_time_est - buffer_min
      arrival_at_stop(i)  = target_at_stop + spread(i)   ← กระจาย ±spread_half นาที
                            (สมมติฐาน: นักศึกษาไม่มาพร้อมกันทุกคน)

  หลักการ "ไม่เร็วเกินไป" (Comfort Early Bound ตาม paper Section 3.2):
      comfortable_deadline = class_start - arrive_before_min
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import pandas as pd
import networkx as nx

# ─── Timing parameters (อ้างอิง Díaz-Ramírez et al. 2022) ──────────────────
BUFFER_MIN: float = 5.0          # เผื่อเวลาเดินทางไม่แน่นอน (นาที) → paper ใช้ time-window
ARRIVE_BEFORE_MIN: float = 10.0  # ต้องการถึงก่อนเรียนกี่นาที (Comfort Early Bound)
SPREAD_HALF_MIN: float = 5.0     # กระจายเวลามาถึงป้าย ±5 นาที (สมมติฐาน)
PREPARATION_MIN: float = 3.0     # เวลาเตรียมตัวและเดินจากหอพักถึงป้าย
SLACK_MAX_MIN: float = 10.0      # load_cs_student_trips: มาถึงป้ายก่อนเวลาล่าสุด 0–10 นาที (1 headway)

# ─── Walk time from bus stop to building (นาที) ─────────────────────────────
WALK_TIME_MIN: dict[str, float] = {
    "Lecture":  3.0,   # LC1
    "LC3":      3.0,   # LC3, and LC2 (walk)
    "LC4":      3.0,   # LC4, and LC5 (walk)
    "SC2_SC3":  2.0,   # SC3 stop, in front of SC3
    "SC2":      2.0,   # SC2 stop, in front of SC2
    "SC1":      5.0,   # SC1
    "Social":   3.0,   # คณะสังคมศาสตร์ ฯลฯ
    "Health":   5.0,   # กลุ่มวิทยาศาสตร์สุขภาพ
    "Hospital": 4.0,   # โรงพยาบาล มธ.
    "Library":  2.0,
    "Convention": 3.0,
}
DEFAULT_WALK_MIN: float = 5.0

# ─── Building code → Bus stop ────────────────────────────────────────────────
BUILDING_TO_STOP: dict[str, str] = {
    # LC2 and LC5 have no EV stop: get off at LC3 / LC4 and walk.
    "LC": "Lecture", "LC1": "Lecture", "LC2": "LC3",
    "LC3": "LC3", "LC4": "LC4", "LC5": "LC4",
    # No official EV route passes the SC2_SC3 stop: get off at SC1 (~140 m) and walk.
    # SC1 stop serves the SC building (and LI is a walk from it); SC2 / SC3 have their own
    # stops on the road in front of them (SC2_SC3 is the SC3 stop, SC2 the one opposite).
    "SC": "SC1",  "SC1": "SC1",  "SC2": "SC2",
    "SC3": "SC2_SC3", "SC4": "SC1", "SC5": "SC1", "LI": "SC1",
    "SOC": "Social",  "HUM": "Social",
    "HEA": "Health",  "MED": "Health",  "NUR": "Health",
    "HOSP": "Hospital",
    "LIB": "Library", "CONV": "Convention",
}
DEFAULT_DEST_STOP = "SC1"  # SC buildings; SC2_SC3 is not on any official route
DEFAULT_ORIGIN_STOP = "Dorm"

# ─── Section size: Limited vs General ────────────────────────────────────────
# วิชาที่ขึ้นต้นด้วย prefix เหล่านี้ถือว่า "วิชาทั่วไป" ไม่จำกัดเซค → ขนาดใหญ่กว่า
GENERAL_COURSE_PREFIXES = ("TU", "EL", "EN", "LA", "SC1", "MA", "PH")
LIMITED_SECTION_SIZE = 50      # วิชา CS/IT เฉพาะทาง
GENERAL_SECTION_SIZE = 120     # วิชาทั่วไป (TU100, EL105 ฯลฯ)
STUDENTS_PER_YEAR = 70         # นักศึกษาต่อชั้นปี (ต่อภาค ปกติ/พิเศษ) — แบ่งเท่า ๆ กันตามจำนวนเซคของวิชา

# ─── Day name → index ────────────────────────────────────────────────────────
DAY_MAP = {
    "จันทร์": 0, "อังคาร": 1, "พุธ": 2,
    "พฤหัสบดี": 3, "ศุกร์": 4, "เสาร์": 5, "อาทิตย์": 6,
}


@dataclass
class PassengerDemand:
    """ความต้องการเดินทางของผู้โดยสารหนึ่งคน"""
    passenger_id: int
    origin: str
    destination: str
    arrival_at_stop: float      # นาทีจากเที่ยงคืน — เวลาผู้โดยสารมาถึงป้ายต้นทาง
    class_start_time: float     # นาทีจากเที่ยงคืน — เวลาเริ่มเรียน
    walk_time_minutes: float    # นาที — เดินจากป้ายถึงอาคาร
    target_arrival: float       # นาที — เวลาที่อยากถึงก่อนเรียน (class_start - buffer)
    travel_time_estimate: float = 0.0  # นาที — เวลาเดินทางจากกราฟ (อ้างอิง paper)
    course_code: str = ""
    building: str = ""
    day_of_week: int = 0
    section: str = ""
    is_general_course: bool = False
    group_size: int = 1


def _time_str_to_minutes(t) -> Optional[float]:
    """แปลง '08:00:00' → 480.0"""
    if pd.isna(t):
        return None
    parts = str(t).strip().split(":")
    try:
        return float(int(parts[0]) * 60 + int(parts[1]))
    except Exception:
        return None


def _resolve_stop(building_code: str) -> str:
    if not isinstance(building_code, str) or not building_code.strip():
        return DEFAULT_DEST_STOP
    code = building_code.strip().upper()
    if code in BUILDING_TO_STOP:
        return BUILDING_TO_STOP[code]
    for prefix, stop in BUILDING_TO_STOP.items():
        if code.startswith(prefix.upper()):
            return stop
    return DEFAULT_DEST_STOP


def _is_general(course_code: str) -> bool:
    return any(course_code.upper().startswith(p) for p in GENERAL_COURSE_PREFIXES)


def _get_travel_time(graph: Optional[nx.DiGraph], origin: str, dest: str) -> float:
    """
    คำนวณเวลาเดินทางโดยประมาณจากกราฟ (Shortest Path)
    อ้างอิง: paper ใช้ Google Maps API — เราใช้ OSM-derived DiGraph แทน
    """
    if graph is None:
        return 15.0  # fallback ถ้าไม่มีกราฟ
    try:
        return float(nx.shortest_path_length(graph, origin, dest, weight="weight"))
    except (nx.NetworkXNoPath, nx.NodeNotFound):
        return 15.0


def load_cs_timetable(
    xlsx_path: str | Path = "data/raw/cs_timetable.xlsx",
    day_filter: Optional[list[str]] = None,
    origin_stop: str = DEFAULT_ORIGIN_STOP,
    graph: Optional[nx.DiGraph] = None,
    buffer_min: float = BUFFER_MIN,
    arrive_before_min: float = ARRIVE_BEFORE_MIN,
    spread_half_min: float = SPREAD_HALF_MIN,
    limited_section_size: int = LIMITED_SECTION_SIZE,
    general_section_size: int = GENERAL_SECTION_SIZE,
) -> list[PassengerDemand]:
    """
    อ่านตาราง CS จาก Excel → list[PassengerDemand]

    การคำนวณเวลา (อ้างอิง Díaz-Ramírez et al. 2022, Section 3.1 & 3.3):

        travel_time_est   = shortest_path(origin_stop → dest_stop)   [จากกราฟ]
        walk_time         = WALK_TIME_MIN[dest_stop]                  [สมมติฐาน]
        target_at_stop    = class_start
                            - walk_time          (เดินจากป้ายถึงอาคาร)
                            - travel_time_est    (บนรถ)
                            - buffer_min         (เผื่อไม่แน่นอน)
                            - arrive_before_min  (Comfort Early Bound)
        arrival_at_stop(i)= target_at_stop
                            + spread(i, ±spread_half_min)   (กระจายไม่มาพร้อมกัน)
                            - preparation_min                (เดินจากหอถึงป้าย)
    """
    path = Path(xlsx_path)
    if not path.exists():
        raise FileNotFoundError(f"ไม่พบ: {path}")

    xl = pd.ExcelFile(path)
    sheet = next((s for s in xl.sheet_names if "ตารางรายสัปดาห์" in s), xl.sheet_names[0])
    raw = xl.parse(sheet, header=None)

    header_row = None
    for i, row in raw.iterrows():
        if row.astype(str).str.contains("วิชา").any() and row.astype(str).str.contains("วัน").any():
            header_row = i
            break
    if header_row is None:
        raise ValueError(f"ไม่พบ header ใน sheet '{sheet}'")

    raw.columns = raw.iloc[header_row]
    df = raw.iloc[header_row + 1:].copy()
    df.columns = [str(c).strip() if not pd.isna(c) else f"_c{i}"
                  for i, c in enumerate(df.columns)]
    df = df.dropna(subset=["วิชา"]).reset_index(drop=True)

    demands: list[PassengerDemand] = []
    pid = 0

    for _, row in df.iterrows():
        course = str(row.get("วิชา", "")).strip()
        section = str(row.get("เซค", "")).strip()
        day = str(row.get("วัน", "")).strip()
        building = str(row.get("ตึก", "")).strip()
        start_raw = row.get("เริ่ม", None)

        if not course or not day or pd.isna(start_raw):
            continue
        if day_filter and day not in day_filter:
            continue

        class_start = _time_str_to_minutes(start_raw)
        if class_start is None or class_start < 360 or class_start > 1320:
            continue

        general = _is_general(course)
        n_students = general_section_size if general else limited_section_size
        dest_stop = _resolve_stop(building)
        walk_min = WALK_TIME_MIN.get(dest_stop, DEFAULT_WALK_MIN)
        day_idx = DAY_MAP.get(day, 0)

        # ─── คำนวณเวลา (อ้างอิง paper Section 3.1 & 3.3) ────────────────
        travel_est = _get_travel_time(graph, origin_stop, dest_stop)
        target_at_stop = (
            class_start
            - walk_min           # เดินจากป้ายถึงอาคาร
            - travel_est         # เวลาบนรถ (จากกราฟ)
            - buffer_min         # เผื่อความไม่แน่นอน
            - arrive_before_min  # Comfort Early Bound (ถึงก่อนเรียน)
        )
        target_arrival = class_start - arrive_before_min

        for idx in range(n_students):
            # กระจายเวลา: นักศึกษาคนแรกมาเร็วสุด คนสุดท้ายมาช้าสุด
            frac = idx / max(1, n_students - 1)           # 0.0 → 1.0
            spread = (frac - 0.5) * 2 * spread_half_min   # -spread_half → +spread_half
            arrival = target_at_stop + spread - PREPARATION_MIN

            demands.append(PassengerDemand(
                passenger_id=pid,
                origin=origin_stop,
                destination=dest_stop,
                arrival_at_stop=round(arrival, 1),
                class_start_time=class_start,
                walk_time_minutes=walk_min,
                target_arrival=target_arrival,
                travel_time_estimate=round(travel_est, 1),
                course_code=course,
                building=building,
                day_of_week=day_idx,
                section=section,
                is_general_course=general,
                group_size=1,
            ))
            pid += 1

    demands.sort(key=lambda d: d.arrival_at_stop)
    return demands


def summarize_demands(demands: list[PassengerDemand]) -> dict:
    if not demands:
        return {"total": 0}
    by_dest: dict[str, int] = {}
    by_course: dict[str, int] = {}
    by_hour: dict[int, int] = {}
    limited_count = 0
    general_count = 0
    for d in demands:
        by_dest[d.destination] = by_dest.get(d.destination, 0) + 1
        by_course[d.course_code] = by_course.get(d.course_code, 0) + 1
        hr = int(d.class_start_time // 60)
        by_hour[hr] = by_hour.get(hr, 0) + 1
        if d.is_general_course:
            general_count += 1
        else:
            limited_count += 1
    # Show timing reference for first demand
    sample = demands[0]
    timing_ref = {
        "example_course": sample.course_code,
        "class_start_min": sample.class_start_time,
        "travel_time_est_min": sample.travel_time_estimate,
        "walk_time_min": sample.walk_time_minutes,
        "arrival_at_stop_min": sample.arrival_at_stop,
        "interpretation": (
            f"นักศึกษามาถึงป้ายเวลา {sample.arrival_at_stop:.0f} นาที "
            f"({sample.arrival_at_stop/60:.2f} น.) "
            f"เพื่อขึ้นรถ → เดินทาง ~{sample.travel_time_estimate:.1f} นาที "
            f"→ เดิน {sample.walk_time_minutes:.0f} นาที "
            f"→ ถึงอาคารก่อนเรียน {sample.class_start_time/60:.2f} น."
        )
    }
    return {
        "total_passengers": len(demands),
        "limited_course_passengers": limited_count,
        "general_course_passengers": general_count,
        "unique_courses": len(by_course),
        "by_destination_stop": dict(sorted(by_dest.items())),
        "by_class_hour": dict(sorted(by_hour.items())),
        "top_courses": dict(sorted(by_course.items(), key=lambda x: -x[1])[:8]),
        "time_range_min": (
            min(d.arrival_at_stop for d in demands),
            max(d.arrival_at_stop for d in demands),
        ),
        "timing_reference": timing_ref,
    }


def load_cs_periods_csv(
    normal_csv: str | Path = "data/processed/CS/normal/periods.csv",
    special_csv: str | Path = "data/processed/CS/special/periods.csv",
    day_filter: Optional[list[str]] = None,
    year_filter: Optional[list[int]] = None,
    term_filter: Optional[list[int]] = None,
    include_sections: tuple[str, ...] = ("normal", "special"),
    origin_stop: str = DEFAULT_ORIGIN_STOP,
    graph: Optional[nx.DiGraph] = None,
    buffer_min: float = BUFFER_MIN,
    arrive_before_min: float = ARRIVE_BEFORE_MIN,
    spread_half_min: float = SPREAD_HALF_MIN,
    limited_section_size: int = LIMITED_SECTION_SIZE,
    general_section_size: int = GENERAL_SECTION_SIZE,
    students_per_year: Optional[int] = None,
) -> list[PassengerDemand]:
    """โหลด demand จาก data/processed/CS/{normal,special}/periods.csv ที่ผ่านการ clean แล้ว

    - รวมภาคปกติ + ภาคพิเศษ (เลือกได้ผ่าน include_sections)
    - กรองตามวัน (เช่น ["อังคาร", "พฤหัสบดี"]) และปี (เช่น [1, 2, 3])
    - ตัดแถวที่ไม่มีเวลาจริง (เช่น "ไม่มีคาบประจำ", "ยังไม่ทราบวันเวลา")
    - สูตรเวลาเหมือน load_cs_timetable() เดิม
    - students_per_year: ถ้ากำหนด จะใช้แทนขนาดเซค 50/120 — แต่ละชั้นปีมีนักศึกษา N คน
      แบ่งเท่า ๆ กันตามจำนวนเซคของแต่ละวิชา และตัดคาบซ้ำระหว่างแผน (เช่น ปี 3 SP กับ COOP)
    """
    frames: list[pd.DataFrame] = []
    sources = {
        "normal": Path(normal_csv),
        "special": Path(special_csv),
    }
    for sec in include_sections:
        path = sources.get(sec)
        if path is None or not path.exists():
            continue
        df = pd.read_csv(path)
        day_col = "วัน" if "วัน" in df.columns else "วัน/สถานะ"
        df = df.rename(columns={day_col: "วัน"})
        room_col = "ห้องในต้นทาง" if "ห้องในต้นทาง" in df.columns else "ห้องจากต้นทาง"
        if room_col in df.columns:
            df = df.rename(columns={room_col: "ห้อง"})
        df["_source"] = sec
        frames.append(df)

    if not frames:
        return []

    df = pd.concat(frames, ignore_index=True)
    df["วัน"] = df["วัน"].astype(str).str.strip()
    df = df[df["วัน"].isin(DAY_MAP.keys())]

    def _year_from_code(code: str) -> Optional[int]:
        if not isinstance(code, str):
            return None
        for token in code.split("_"):
            if token.startswith("Y") and len(token) >= 2 and token[1].isdigit():
                return int(token[1])
        return None

    df["_year"] = df["รหัสชุด"].apply(_year_from_code)
    df["_term"] = pd.to_numeric(
        df["รหัสชุด"].astype(str).str.extract(r"_Y\dS(\d)_")[0], errors="coerce"
    )

    if day_filter:
        df = df[df["วัน"].isin(day_filter)]
    if year_filter:
        df = df[df["_year"].isin(year_filter)]
    if term_filter:
        df = df[df["_term"].isin(term_filter)]

    if students_per_year is not None:
        # นักศึกษาชั้นปีเดียวกันคือกลุ่มเดียวกัน → คาบเดียวกันที่อยู่หลายแผนนับครั้งเดียว
        cohort = ["_source", "_year", "_term"]
        df = df.drop_duplicates(cohort + ["วิชา", "เซค", "วัน", "เริ่ม"])
        # แบ่ง N คนตามจำนวนเซคของวิชา เศษให้เซคแรก ๆ
        sec_rank = (df[cohort + ["วิชา", "เซค"]].drop_duplicates()
                    .assign(_n_sec=lambda x: x.groupby(cohort + ["วิชา"])["เซค"].transform("count"),
                            _rank=lambda x: x.groupby(cohort + ["วิชา"]).cumcount()))
        df = df.merge(sec_rank, on=cohort + ["วิชา", "เซค"], how="left")
        df["_n"] = (students_per_year // df["_n_sec"]
                    + (df["_rank"] < students_per_year % df["_n_sec"]).astype(int))

    demands: list[PassengerDemand] = []
    pid = 0

    for _, row in df.iterrows():
        course = str(row.get("วิชา", "")).strip()
        section = str(row.get("เซค", "")).strip()
        day = str(row.get("วัน", "")).strip()
        building = str(row.get("ตึก", "")).strip()
        start_raw = row.get("เริ่ม", None)

        if not course or not day or pd.isna(start_raw):
            continue

        class_start = _time_str_to_minutes(start_raw)
        if class_start is None or class_start < 360 or class_start > 1320:
            continue

        general = _is_general(course)
        if students_per_year is not None:
            n_students = int(row["_n"])
        else:
            n_students = general_section_size if general else limited_section_size
        dest_stop = _resolve_stop(building)
        walk_min = WALK_TIME_MIN.get(dest_stop, DEFAULT_WALK_MIN)
        day_idx = DAY_MAP.get(day, 0)

        travel_est = _get_travel_time(graph, origin_stop, dest_stop)
        target_at_stop = (
            class_start
            - walk_min
            - travel_est
            - buffer_min
            - arrive_before_min
        )
        target_arrival = class_start - arrive_before_min

        for idx in range(n_students):
            frac = idx / max(1, n_students - 1)
            spread = (frac - 0.5) * 2 * spread_half_min
            arrival = target_at_stop + spread - PREPARATION_MIN

            demands.append(PassengerDemand(
                passenger_id=pid,
                origin=origin_stop,
                destination=dest_stop,
                arrival_at_stop=round(arrival, 1),
                class_start_time=class_start,
                walk_time_minutes=walk_min,
                target_arrival=target_arrival,
                travel_time_estimate=round(travel_est, 1),
                course_code=course,
                building=building,
                day_of_week=day_idx,
                section=section,
                is_general_course=general,
                group_size=1,
            ))
            pid += 1

    demands.sort(key=lambda d: d.arrival_at_stop)
    return demands


def _load_periods(sources: dict[str, Path]) -> pd.DataFrame:
    """periods.csv ของภาคปกติ/พิเศษ → คาบที่ต้องเดินทางไปเรียนจริง (มีวันและเวลา)"""
    frames = []
    for sec, path in sources.items():
        if not path.exists():
            continue
        df = pd.read_csv(path).rename(columns={"วัน/สถานะ": "วัน"})
        df["_source"] = sec
        frames.append(df)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["วัน"] = df["วัน"].astype(str).str.strip()
    df = df[df["วัน"].isin(DAY_MAP.keys()) & df["เริ่ม"].notna()]
    # e-learning (ภาคปกติ) และวิชาออนไลน์ (ภาคพิเศษ) ไม่ต้องนั่งรถไปเรียน
    if "ต้องเดินทางตามคาบ" in df.columns:
        df = df[df["ต้องเดินทางตามคาบ"].ne(False)]
    df = df[~df["สถานะข้อมูล"].astype(str).str.startswith("ออนไลน์")]
    code = df["รหัสชุด"].astype(str)
    df["_year"] = pd.to_numeric(code.str.extract(r"_Y(\d)S")[0], errors="coerce")
    df["_term"] = pd.to_numeric(code.str.extract(r"_Y\dS(\d)_")[0], errors="coerce")
    df["_plan"] = code.str.extract(r"_Y\dS\d_([A-Z]+)_")[0]
    return df


def _fastest_bus_ride(origin: str, dest: str) -> Optional[float]:
    """นาทีบนรถที่เร็วที่สุดจาก origin ถึง dest บนสาย EV ที่มีอยู่ (ทางการ + baseline)

    คิดแบบเดียวกับ simulation: ขับตามถนนจริง + จอดทุกป้ายระหว่างทาง (ฝั่งไหนของถนนก็ได้)
    ไม่ขึ้นกับชุดเส้นทางที่อัลกอริทึมเสนอ → demand ชุดเดียวกันสำหรับทุกอัลกอริทึม
    """
    from data.graph import km_to_min
    from data.routes import BASELINE_ROUTES, OFFICIAL_ROUTES
    from simulation.engine import _place, _ride_table

    best = None
    for r in OFFICIAL_ROUTES + BASELINE_ROUTES:
        table = _ride_table(r["path"], [km_to_min(lg["km"]) for lg in r["legs"]])
        for i, stop in enumerate(r["path"]):
            if _place(stop) == _place(origin):
                ride = table[i].get(_place(dest))
                if ride is not None and (best is None or ride < best):
                    best = ride
    return best


def _block(i: int, n: int, k: int) -> int:
    """นักศึกษาคนที่ i จาก n คน อยู่เซคไหนจาก k เซค (แบ่งเท่า ๆ กัน เศษให้เซคแรก ๆ)"""
    start = 0
    for j in range(k):
        size = n // k + (j < n % k)
        if i < start + size:
            return j
        start += size
    return k - 1


def load_cs_student_trips(
    day: str,
    normal_csv: str | Path = "data/processed/CS/normal/periods.csv",
    special_csv: str | Path = "data/processed/CS/special/periods.csv",
    years: tuple[int, ...] = (1, 2, 3),
    term: int = 1,
    students_per_year: int = STUDENTS_PER_YEAR,
    origin_stop: str = DEFAULT_ORIGIN_STOP,
    graph: Optional[nx.DiGraph] = None,
    arrive_before_min: float = ARRIVE_BEFORE_MIN,
    slack_max_min: float = SLACK_MAX_MIN,
) -> list[PassengerDemand]:
    """นักศึกษา 1 คน = เดินทาง 1 เที่ยวต่อวัน: จากหอพักไปคาบแรกของวันนั้น

    - นักศึกษา CS ภาคปกติ + ภาคพิเศษ ชั้นปีละ students_per_year คน (ปี 1–3 × 70 × 2 = 420 คน)
    - จำลองทีละวัน (day) — ไม่เอาหลายวันมาซ้อนกันในวันเดียว
    - แต่ละวิชา: แบ่งนักศึกษาเท่า ๆ กันตามเซค (คนที่ 0.. อยู่เซคแรก) [สมมติฐาน]
    - ชั้นปีที่มีหลายแผน (ปี 3 SP / COOP): แบ่งนักศึกษาสลับกันเท่า ๆ กัน [สมมติฐาน]
    - คนที่ไม่มีคาบที่ต้องเดินทางในวันนั้น ไม่เกิด demand
    - เวลามาถึงป้าย (ตกลงกับผู้ใช้ 2026-11-04):
          ride          = _fastest_bus_ride(หอพัก → ป้ายปลายทาง)   ถ้าไม่มีสายตรง ใช้ shortest path บนกราฟ
          latest_at_stop = class_start - walk - DWELL - ride       (รถคันสุดท้ายที่ยังไปทันมาถึงป้าย)
          arrival(i)    = latest_at_stop - slack(i)                slack กระจายเท่า ๆ กัน 0..slack_max_min
      [สมมติฐาน] ไม่มีข้อมูลจริงว่านักศึกษามาถึงป้ายกี่โมง
    """
    from simulation.engine import DWELL_TIME_MIN

    df = _load_periods({"normal": Path(normal_csv), "special": Path(special_csv)})
    if df.empty:
        return []
    df = df[(df["_term"] == term) & df["_year"].isin(years)]

    # คาบแรกของวันของนักศึกษาแต่ละคน
    firsts = []  # (source, year, student, start, building, course, section)
    for (source, year), cohort in df.groupby(["_source", "_year"]):
        plans = sorted(cohort["_plan"].dropna().unique())
        for i in range(students_per_year):
            plan = cohort[cohort["_plan"] == plans[i % len(plans)]]
            in_plan = students_per_year // len(plans) + (i % len(plans) < students_per_year % len(plans))
            mine = []
            for _, course in plan.groupby("วิชา"):
                secs = sorted(course["เซค"].unique())
                sec = secs[_block(i // len(plans), in_plan, len(secs))]
                mine.append(course[(course["เซค"] == sec) & (course["วัน"] == day)])
            today = pd.concat(mine)
            if today.empty:
                continue
            first = today.sort_values("เริ่ม").iloc[0]
            firsts.append((source, int(year), i, first["เริ่ม"], first["ตึก"],
                           str(first["วิชา"]).strip(), str(first["เซค"]).strip()))

    demands: list[PassengerDemand] = []
    groups: dict[tuple, list[tuple]] = {}
    for f in firsts:
        groups.setdefault((f[3], f[4]), []).append(f)
    for (start_raw, building), members in sorted(groups.items(), key=lambda kv: str(kv[0])):
        class_start = _time_str_to_minutes(start_raw)
        if class_start is None:
            continue
        building = str(building).strip() if isinstance(building, str) else ""
        dest_stop = _resolve_stop(building)
        walk_min = WALK_TIME_MIN.get(dest_stop, DEFAULT_WALK_MIN)
        ride = _fastest_bus_ride(origin_stop, dest_stop)
        if ride is None:
            ride = _get_travel_time(graph, origin_stop, dest_stop)
        latest_at_stop = class_start - walk_min - DWELL_TIME_MIN - ride
        n = len(members)
        for idx, (_, _, _, _, _, course, section) in enumerate(members):
            slack = idx / max(1, n - 1) * slack_max_min
            demands.append(PassengerDemand(
                passenger_id=len(demands),
                origin=origin_stop,
                destination=dest_stop,
                arrival_at_stop=round(latest_at_stop - slack, 1),
                class_start_time=class_start,
                walk_time_minutes=walk_min,
                target_arrival=class_start - arrive_before_min,
                travel_time_estimate=round(ride, 1),
                course_code=course,
                building=building,
                day_of_week=DAY_MAP[day],
                section=section,
                is_general_course=_is_general(course),
                group_size=1,
            ))

    demands.sort(key=lambda d: d.arrival_at_stop)
    return demands


if __name__ == "__main__":
    import json, sys
    sys.path.insert(0, ".")
    from src.data.graph import build_graph, make_bidirectional
    graph = make_bidirectional(build_graph())
    demands = load_cs_student_trips("อังคาร", graph=graph)
    stats = summarize_demands(demands)
    print(json.dumps(stats, ensure_ascii=False, indent=2))

import json
import math
from pathlib import Path

import networkx as nx
from data.graph import calculate_cycle_time, get_real_dist, km_to_min

# Every bus leaves from the EV rest point (ศูนย์ประชุม / จุดพักรถ EV), so routes generated
# by the optimisers start there. The official routes follow the printed route cards
# (route 3 starts at TU Dome).
REST_POINT = "Convention"

# The official TU Rangsit EV shuttle routes 1A, 1B, 2, 3, 5 resolved onto real roads.
# Source: data/raw/routes.json -> scripts/build_routes.py -> official_routes.json
_OFFICIAL_ROUTES_FILE = Path(__file__).with_name("official_routes.json")
OFFICIAL_ROUTES: list[dict] = json.loads(_OFFICIAL_ROUTES_FILE.read_text(encoding="utf-8"))

# The simulation baseline: 3 routes that together serve every stop location on campus.
# Source: data/raw/routes.json "baseline_routes" -> scripts/build_routes.py -> baseline_routes.json
_BASELINE_ROUTES_FILE = Path(__file__).with_name("baseline_routes.json")
BASELINE_ROUTES: list[dict] = json.loads(_BASELINE_ROUTES_FILE.read_text(encoding="utf-8"))

HUB_STOPS = {"Convention", "Lecture", "Terminal"}
CANDIDATE_STOPS = [
    "Dorm",
    "Green",
    "SC2_SC3",
    "Health",
    "Lecture",
]
_LEGACY_STOPS = [
    "Dorm", "Green", "SC2_SC3", "Terminal", "Convention", "Library", "Social",
    "Lecture", "Park", "Health", "Hospital", "SC1", "Gate1", "Dome",
]
# Every stop the simulation knows: the original 14 plus every stop on an official route.
ALL_STOPS = _LEGACY_STOPS + sorted(
    {s for r in OFFICIAL_ROUTES + BASELINE_ROUTES for s in r["path"]} - set(_LEGACY_STOPS)
)


def get_all_stops() -> list[str]:
    return ALL_STOPS.copy()


def _route(
    route_id: int,
    path: list[str],
    graph: nx.DiGraph,
    start_time: int,
    end_time: int,
    num_bus: int | None = None,
    target_headway: float | None = None,
    leg_km: list[float] | None = None,
    **extra,
) -> dict:
    # Make sure every leg the bus drives (including the closing leg back to the first stop)
    # is a direct edge with its real road time, not a shortest path through other stops.
    legs = list(zip(path, path[1:]))
    if path[-1] != path[0]:
        legs.append((path[-1], path[0]))
    if leg_km is not None:
        # Official routes: the road the map draws, which can be longer than the shortest one.
        for (a, b), km in zip(legs, leg_km):
            graph.add_edge(a, b, weight=km_to_min(km))
    for a, b in legs:
        if not graph.has_edge(a, b):
            graph.add_edge(a, b, weight=km_to_min(get_real_dist(a, b)))
    cycle_time = calculate_cycle_time(path, graph)
    if num_bus is None:
        # Enough buses to keep the printed headway ("รถออกทุกๆ ... นาที").
        num_bus = max(1, math.ceil(cycle_time / target_headway)) if target_headway else 5
    return {
        "route_id": route_id,
        "path": path,
        "num_bus": num_bus,
        "cycle_time": cycle_time,
        "headway": round(cycle_time / num_bus, 2),
        "startTime": start_time,
        "endTime": end_time,
        **extra,
    }


def _build(resolved: list[dict], graph: nx.DiGraph) -> list[dict]:
    routes = []
    for r in resolved:
        lo, hi = r["headwayMin"]
        routes.append(_route(
            r["id"], list(r["path"]), graph, r["startTime"], r["endTime"],
            target_headway=(lo + hi) / 2,
            leg_km=[lg["km"] for lg in r["legs"]],
            name=r["name"], color=r["color"],
        ))
    return routes


def build_fixed_routes(graph: nx.DiGraph) -> list[dict]:
    """The official routes 1A, 1B, 2, 3, 5 (weekday hours, printed headways)."""
    return _build(OFFICIAL_ROUTES, graph)


def build_baseline_routes(graph: nx.DiGraph) -> list[dict]:
    """The 3-route simulation baseline (a bus every 10 minutes on each route)."""
    return _build(BASELINE_ROUTES, graph)

// Road network exported from Python (scripts/export_web_network.py) and the
// bus-position model used by the /network page. Timing mirrors the simulation:
// dwell at every stop in the path, drive each leg, then a layover; repeat.
import raw from "@/data/osmNetwork.json";
import { RouteSchedule, ROUTE_COLORS } from "@/types/shuttle";

export function routeColor(route: Pick<NetRoute, "id" | "color">): string {
  return route.color ?? ROUTE_COLORS[(route.id - 1) % ROUTE_COLORS.length].stroke;
}

export type LatLng = [number, number];

export interface NetLeg {
  from: string;
  to: string;
  km: number;
  minutes: number;
  coords: LatLng[];
}

export interface NetRoute {
  id: number;
  name: string; // printed route name: 1A, 1B, 2, 3, 5
  color: string | null; // route colour from the official route card
  path: string[]; // a loop: after the last stop the bus returns to path[0]
  legs: NetLeg[]; // one leg per stop, including the closing leg back to path[0]
  numBus: number;
  cycleTime: number;
  headway: number;
  startTime: number;
  endTime: number;
  totalKm: number;
}

export interface NetStop {
  id: string;
  lat: number;
  lon: number;
  originalLat: number; // hand-placed coordinate before snapping onto the road
  originalLon: number;
  snapM: number; // metres moved from the original coordinate onto the road
  verified: boolean; // coordinate confirmed from Google Maps (data/raw/stops.csv)
  bothDirections: boolean; // on the road centreline, served in both directions
  passengers: boolean; // false for bus rest points: buses stop, nobody gets on or off
  routes: number[]; // empty when no route serves this stop yet
}

export interface NetworkData {
  source: string;
  speedKmh: number;
  dwellMin: number;
  layoverMin: number;
  stops: NetStop[];
  routes: NetRoute[];
  baselineRoutes: NetRoute[]; // the 3-route simulation baseline, on the same roads
}

export const NETWORK = raw as unknown as NetworkData;

/** Road line and length between every pair of stops (web/public/data/road_legs.json). */
export type RoadLegs = Record<string, Record<string, { km: number; coords: LatLng[] }>>;

/** Turn an optimiser's schedule into map routes, following real roads leg by leg. */
export function routesFromSchedule(schedule: RouteSchedule[], roads: RoadLegs): NetRoute[] {
  return schedule.map((r, idx) => {
    const pairs = r.path.slice(1).map((to, i): [string, string] => [r.path[i], to]);
    if (r.path[r.path.length - 1] !== r.path[0]) pairs.push([r.path[r.path.length - 1], r.path[0]]);
    const legs: NetLeg[] = pairs.map(([from, to]) => {
      const road = roads[from]?.[to];
      const km = road?.km ?? 0;
      return { from, to, km, minutes: (km / NETWORK.speedKmh) * 60, coords: road?.coords ?? stopLine(from, to) };
    });
    return {
      id: idx + 1,
      name: String(idx + 1),
      color: null,
      path: r.path,
      legs,
      numBus: r.num_bus,
      cycleTime: r.cycle_time,
      headway: r.headway,
      startTime: r.startTime,
      endTime: r.endTime,
      totalKm: legs.reduce((sum, l) => sum + l.km, 0),
    };
  });
}

function stopLine(from: string, to: string): LatLng[] {
  return [from, to].flatMap((id) => {
    const s = NETWORK.stops.find((x) => x.id === id);
    return s ? [[s.lat, s.lon] as LatLng] : [];
  });
}

export type BusState = "driving" | "dwell" | "layover";

export interface BusPosition {
  routeId: number;
  routeName: string;
  color: string;
  busIdx: number;
  lat: number;
  lng: number;
  state: BusState;
  atStop?: string;
  nextStop: string;
}

interface Phase {
  kind: BusState;
  duration: number;
  leg?: NetLeg;
  stop?: string;
}

interface PreparedLeg {
  leg: NetLeg;
  cum: number[]; // cumulative distance along coords (flat-earth units)
  total: number;
}

function flat(a: LatLng, b: LatLng): number {
  const dLat = b[0] - a[0];
  const dLng = (b[1] - a[1]) * Math.cos((a[0] * Math.PI) / 180);
  return Math.hypot(dLat, dLng);
}

const PREPARED = new Map<NetLeg, PreparedLeg>();
function prepare(leg: NetLeg): PreparedLeg {
  let p = PREPARED.get(leg);
  if (!p) {
    const cum = [0];
    for (let i = 1; i < leg.coords.length; i++) {
      cum.push(cum[i - 1] + flat(leg.coords[i - 1], leg.coords[i]));
    }
    p = { leg, cum, total: cum[cum.length - 1] };
    PREPARED.set(leg, p);
  }
  return p;
}

function pointAlong(leg: NetLeg, frac: number): LatLng {
  const { cum, total } = prepare(leg);
  const c = leg.coords;
  if (c.length < 2 || total <= 0) return c[0];
  const target = Math.min(1, Math.max(0, frac)) * total;
  let i = 1;
  while (i < cum.length - 1 && cum[i] < target) i++;
  const span = cum[i] - cum[i - 1];
  const f = span > 0 ? (target - cum[i - 1]) / span : 0;
  return [c[i - 1][0] + (c[i][0] - c[i - 1][0]) * f, c[i - 1][1] + (c[i][1] - c[i - 1][1]) * f];
}

const PHASES = new WeakMap<NetRoute, { phases: Phase[]; period: number }>();
function phasesFor(route: NetRoute) {
  let entry = PHASES.get(route);
  if (!entry) {
    // Same as the simulation: dwell at each stop, drive to the next (the last leg returns
    // to the first stop), then a layover there before the next loop.
    const phases: Phase[] = [];
    for (const leg of route.legs) {
      phases.push({ kind: "dwell", duration: NETWORK.dwellMin, stop: leg.from });
      phases.push({ kind: "driving", duration: leg.minutes, leg });
    }
    phases.push({ kind: "layover", duration: NETWORK.layoverMin, stop: route.legs[route.legs.length - 1].to });
    entry = { phases, period: phases.reduce((s, p) => s + p.duration, 0) };
    PHASES.set(route, entry);
  }
  return entry;
}

export function cyclePeriod(route: NetRoute): number {
  return phasesFor(route).period;
}

/** Positions of every bus on the route at simulated time t (minutes from midnight). */
export function busPositions(route: NetRoute, t: number): BusPosition[] {
  const { phases, period } = phasesFor(route);
  const headway = period / route.numBus;
  const out: BusPosition[] = [];
  for (let b = 0; b < route.numBus; b++) {
    const depart = route.startTime + b * headway;
    if (t < depart || t > route.endTime) continue;
    let local = (t - depart) % period;
    for (let i = 0; i < phases.length; i++) {
      const ph = phases[i];
      if (local <= ph.duration || i === phases.length - 1) {
        let pos: LatLng;
        let nextStop: string;
        if (ph.kind === "driving" && ph.leg) {
          pos = pointAlong(ph.leg, local / ph.duration);
          nextStop = ph.leg.to;
        } else {
          const stop = NETWORK.stops.find((s) => s.id === ph.stop);
          pos = stop ? [stop.lat, stop.lon] : route.legs[0].coords[0];
          const nextLeg = phases.slice(i + 1).find((p) => p.kind === "driving")?.leg;
          nextStop = nextLeg ? nextLeg.to : route.legs[0].to;
        }
        out.push({
          routeId: route.id,
          routeName: route.name,
          color: routeColor(route),
          busIdx: b,
          lat: pos[0],
          lng: pos[1],
          state: ph.kind,
          atStop: ph.kind === "driving" ? undefined : ph.stop,
          nextStop,
        });
        break;
      }
      local -= ph.duration;
    }
  }
  return out;
}

export function fmtClock(minutes: number): string {
  const m = Math.floor(minutes);
  const h = Math.floor(m / 60) % 24;
  return `${String(h).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
}

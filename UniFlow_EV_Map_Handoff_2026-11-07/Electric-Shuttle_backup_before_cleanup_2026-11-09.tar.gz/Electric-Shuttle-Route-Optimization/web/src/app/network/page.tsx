"use client";

import Link from "next/link";
import NetworkExplorer from "@/components/NetworkExplorer";
import { NETWORK } from "@/lib/osmNetwork";

export default function NetworkPage() {
  return (
    <main className="min-h-screen">
      <header className="border-b border-neutral-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-[18px] font-semibold">แผนที่เครือข่ายรถ EV — มธ. ศูนย์รังสิต</h1>
            <p className="text-[12px] text-neutral-500">
              เส้นทางตามถนนจริงจาก OpenStreetMap · ความเร็ว {NETWORK.speedKmh} กม./ชม. · จอดป้ายละ{" "}
              {NETWORK.dwellMin} นาที · พักปลายสาย {NETWORK.layoverMin} นาที
            </p>
          </div>
          <Link href="/" className="text-[13px] text-neutral-600 hover:text-neutral-900">
            ← กลับหน้าหลัก
          </Link>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-4">
        <NetworkExplorer />
      </div>
    </main>
  );
}

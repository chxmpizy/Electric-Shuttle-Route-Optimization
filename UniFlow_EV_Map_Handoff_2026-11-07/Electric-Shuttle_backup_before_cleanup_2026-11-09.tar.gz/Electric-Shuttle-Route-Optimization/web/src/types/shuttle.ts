export interface TimetableEntry {
  stop: string;
  arrival_time: number;
}

export interface RouteSchedule {
  route_id?: number;
  path: string[];
  num_bus: number;
  cycle_time: number;
  headway: number;
  startTime: number;
  endTime: number;
  timetable?: TimetableEntry[];
}

export interface BusStat {
  bus_id: number;
  route: string[];
  capacity: number;
  trips: number;
  boarded: number;
  alighted: number;
  ended_with_pax: number;
  utilization_pct: number;
}

export interface ODEntry {
  from: string;
  to: string;
  count: number;
}

export interface MobilityPoint {
  t: number;        // simulation minute
  waiting: number;  // reached stop, not yet on bus
  on_bus: number;   // on bus, not yet arrived
  arrived: number;  // cumulative passengers who've arrived at destination
}

export interface SimulationResult {
  baseline_wait: number;
  baseline_travel: number;
  baseline_served?: number;
  baseline_waiting?: number;
  baseline_schedule?: RouteSchedule[];
  optimized_wait: number;
  optimized_travel: number;
  optimized_served?: number;
  optimized_waiting?: number;
  schedule: RouteSchedule[];
  // Feedback #7: convergence + timing from API
  history?: number[];
  elapsed_sec?: number;
  algorithm?: string;
  // Feedback #1,#6: on-time + utilization
  on_time_rate_pct?: number | null;
  late_passengers?: number | null;
  stranded_passengers?: number | null;
  total_passengers?: number | null;
  total_buses?: number | null;
  fleet_utilization_pct?: number | null;
  bus_stats?: BusStat[];
  od_matrix?: ODEntry[];
  mobility_timeseries?: MobilityPoint[];
  data_source?: "live" | "demo";
  // Goal function 3 กรณี: ทันเรียน / มาไม่ทันป้าย / มาทันแต่รถเต็ม
  case_on_time?: number | null;
  case_missed?: number | null;
  case_bus_full?: number | null;
  baseline_case_on_time?: number | null;
  baseline_case_missed?: number | null;
  baseline_case_bus_full?: number | null;
  fitness_breakdown?: FitnessBreakdown;
}

export interface FitnessBreakdown {
  wait_component: number;
  travel_component: number;
  delay_component: number;
  unserved_penalty: number;
  fleet_component: number;
  total_cost: number;
  on_time_rate_pct: number;
  unserved_ratio_pct: number;
}

export interface BenchmarkAlgorithmData {
  algorithm: string;
  wait_time: number;
  travel_time: number;
  total_time: number;
  served: number;
  waiting: number;
  num_routes: number;
  total_buses: number;
  avg_headway: number;
  schedule?: RouteSchedule[];
  on_time_rate_pct?: number | null;
  late_passengers?: number | null;
  stranded_passengers?: number | null;
  total_passengers?: number | null;
  case_on_time?: number | null;
  case_missed?: number | null;
  case_bus_full?: number | null;
  fitness?: number | null;
}

export interface CampusStop {
  id: string;
  nameEn: string;
  nameTh: string;
  lon: number;
  lat: number;
  weight: number;
  desc: string;
  category: "dorm" | "academic" | "hospital" | "transit" | "recreation";
}

export const CAMPUS_STOPS: Record<string, CampusStop> = {
  Dome: {
    id: "Dome",
    nameEn: "TU Dome",
    nameTh: "TU DOME",
    lon: 100.60039,
    lat: 14.065989,
    weight: 81,
    desc: "หอพัก TU Dome และพลาซ่าฝั่งตรงข้าม",
    category: "dorm",
  },
  Hospital: {
    id: "Hospital",
    nameEn: "Thammasat Hospital",
    nameTh: "รพ.ธรรมศาสตร์",
    lon: 100.615804,
    lat: 14.073633,
    weight: 200,
    desc: "โรงพยาบาลธรรมศาสตร์เฉลิมพระเกียรติ",
    category: "hospital",
  },
  Dorm: {
    id: "Dorm",
    nameEn: "Asian Games Dorm",
    nameTh: "หอพักเอเชียนเกมส์",
    lon: 100.595139,
    lat: 14.077233,
    weight: 2500,
    desc: "โซนหอพักนักศึกษา (จุดที่มีความต้องการเดินทางสูงสุด)",
    category: "dorm",
  },
  Gate1: {
    id: "Gate1",
    nameEn: "Chiang Rak Gate 1",
    nameTh: "ประตูเชียงราก 1",
    lon: 100.605096,
    lat: 14.066285,
    weight: 80,
    desc: "ทางเข้าออกหลักฝั่งเชียงราก และจุดรับ-ส่งนักศึกษา",
    category: "transit",
  },
  Library: {
    id: "Library",
    nameEn: "Puey Ungphakorn Library (front)",
    nameTh: "หน้าหอสมุดป๋วย",
    lon: 100.60164,
    lat: 14.071229,
    weight: 846,
    desc: "หอสมุดป๋วย อึ๊งภากรณ์ ศูนย์กลางการเรียนรู้",
    category: "academic",
  },
  Park: {
    id: "Park",
    nameEn: "Puey 100-Year Park",
    nameTh: "อุทยานเรียนรู้ 100 ปี",
    lon: 100.611659,
    lat: 14.07218,
    weight: 200,
    desc: "อุทยานการเรียนรู้ป๋วย 100 ปี และหลังคาสีเขียว",
    category: "recreation",
  },
  SC1: {
    id: "SC1",
    nameEn: "Science Complex 1",
    nameTh: "อาคาร SC1 (ตึก SC, เดินไปตึก LI ได้)",
    lon: 100.604252,
    lat: 14.069462,
    weight: 600,
    desc: "ป้ายตึก SC — เดินไปตึก LI ได้",
    category: "academic",
  },
  SC2_SC3: {
    id: "SC2_SC3",
    nameEn: "SC3 stop (in front of SC3)",
    nameTh: "ป้าย SC3 (หน้าตึก SC3)",
    lon: 100.604594,
    lat: 14.070692,
    weight: 600,
    desc: "ป้ายหน้าตึก SC3 — ฝั่งตรงข้ามคือป้าย SC2",
    category: "academic",
  },
  Green: {
    id: "Green",
    nameEn: "Near Green Canteen / Activity Building",
    nameTh: "ใกล้โรงอาหาร Green / หน้าตึกกิจกรรม",
    lon: 100.601626,
    lat: 14.072717,
    weight: 100,
    desc: "ป้ายหน้าตึกกิจกรรม — เดินอีกประมาณ 5 นาทีถึงโรงอาหาร Green",
    category: "recreation",
  },
  Convention: {
    id: "Convention",
    nameEn: "Convention Center / EV rest point",
    nameTh: "ศูนย์ประชุม / จุดพักรถ EV",
    lon: 100.612688,
    lat: 14.067824,
    weight: 150,
    desc: "ศูนย์ประชุมธรรมศาสตร์ และจุดพักรถ EV",
    category: "transit",
  },
  Terminal: {
    id: "Terminal",
    nameEn: "Faculty of Fine and Applied Arts Practice Building",
    nameTh: "อาคารปฏิบัติการคณะศิลปกรรมศาสตร์",
    lon: 100.606835,
    lat: 14.067434,
    weight: 212,
    desc: "อาคารปฏิบัติการคณะศิลปกรรมศาสตร์",
    category: "transit",
  },
  Lecture: {
    id: "Lecture",
    nameEn: "Lecture Center 1 (LC1)",
    nameTh: "LC1 (อาคารบรรยายรวม 1)",
    lon: 100.602213,
    lat: 14.072096,
    weight: 1100,
    desc: "ป้ายหน้า LC1 บนถนนปรีดี พนมยงค์ (ถนนเดียวกับ LC3 / LC4)",
    category: "academic",
  },
  Health: {
    id: "Health",
    nameEn: "Public Health Building",
    nameTh: "อาคารสาธารณสุขศาสตร์",
    lon: 100.612871,
    lat: 14.072208,
    weight: 1023,
    desc: "ป้ายหน้าอาคารสาธารณสุขศาสตร์",
    category: "academic",
  },
  Social: {
    id: "Social",
    nameEn: "Social Sciences Complex",
    nameTh: "อาคารเรียนรวมสังคมศาสตร์",
    lon: 100.601663,
    lat: 14.06967,
    weight: 1500,
    desc: "กลุ่มอาคารสังคมศาสตร์และโรงอาหาร SC Canteen",
    category: "academic",
  },
  // New stops from Google Maps (data/raw/stops.csv). Not on any route yet, so weight 0.
  Library_LC1: {
    id: "Library_LC1",
    nameEn: "Puey Library side / opposite LC1",
    nameTh: "ข้างหอสมุดป๋วย / ตรงข้าม LC1",
    lon: 100.60189,
    lat: 14.072096,
    weight: 0,
    desc: "ป้ายข้างหอสมุดป๋วย ฝั่งตรงข้าม LC1",
    category: "academic",
  },
  LC3: {
    id: "LC3",
    nameEn: "Lecture Center 3 (LC3)",
    nameTh: "LC3 (ใกล้ LC2)",
    lon: 100.606137,
    lat: 14.072127,
    weight: 0,
    desc: "ป้ายหน้า LC3 — ลงป้ายนี้แล้วเดินไป LC2 (LC2 ไม่มีรถ EV ถึงหน้าตึก)",
    category: "academic",
  },
  LC3_Opp: {
    id: "LC3_Opp",
    nameEn: "Parking lot / opposite LC3",
    nameTh: "ลานจอดรถ / ตรงข้าม LC3",
    lon: 100.60641,
    lat: 14.072128,
    weight: 0,
    desc: "ป้ายฝั่งลานจอดรถ ตรงข้าม LC3 — ลงแล้วข้ามถนนไป LC3",
    category: "academic",
  },
  LC4: {
    id: "LC4",
    nameEn: "Lecture Center 4 (LC4)",
    nameTh: "LC4 (ใกล้ LC5)",
    lon: 100.608006,
    lat: 14.07214,
    weight: 0,
    desc: "ป้ายหน้า LC4 — ลงป้ายนี้แล้วเดินไป LC5 (LC5 ไม่มีรถ EV ถึงหน้าตึก)",
    category: "academic",
  },
  LC4_Opp: {
    id: "LC4_Opp",
    nameEn: "TU Theatre / opposite LC4",
    nameTh: "โรงละคร มธ. / ตรงข้าม LC4",
    lon: 100.608006,
    lat: 14.07214,
    weight: 0,
    desc: "ป้ายหน้าโรงละครแห่งมหาวิทยาลัยธรรมศาสตร์ ตรงข้าม LC4 (วางฝั่งตรงข้ามของ LC4 บนถนนปรีดี พนมยงค์)",
    category: "academic",
  },
  Green_LC1: {
    id: "Green_LC1",
    nameEn: "Near LC1 / opposite Green Canteen",
    nameTh: "ใกล้ LC1 / ตรงข้ามโรงอาหาร Green",
    lon: 100.601621,
    lat: 14.073221,
    weight: 0,
    desc: "ป้าย TU NGV Station 4 ฝั่งรถลงใต้ ตรงข้ามป้ายโรงอาหาร Green",
    category: "recreation",
  },
  DLUXX: {
    id: "DLUXX",
    nameEn: "DLUXX Building",
    nameTh: "ตึก DLUXX",
    lon: 100.598638,
    lat: 14.070728,
    weight: 0,
    desc: "ป้ายหน้าตึก DLUXX",
    category: "academic",
  },
  Dorm_C9: {
    id: "Dorm_C9",
    nameEn: "Dormitory row C9",
    nameTh: "หอใน แถว C9",
    lon: 100.596924,
    lat: 14.072535,
    weight: 0,
    desc: "ป้ายหอพักในมหาวิทยาลัย แถว C9",
    category: "dorm",
  },
  Dorm_C5: {
    id: "Dorm_C5",
    nameEn: "Dormitory row C5",
    nameTh: "หอใน แถว C5",
    lon: 100.596717,
    lat: 14.074294,
    weight: 0,
    desc: "ป้ายหอพักในมหาวิทยาลัย แถว C5",
    category: "dorm",
  },
  Dorm_C2: {
    id: "Dorm_C2",
    nameEn: "Dormitory row C2",
    nameTh: "หอใน แถว C2",
    lon: 100.596687,
    lat: 14.075267,
    weight: 0,
    desc: "ป้ายหอพักในมหาวิทยาลัย แถว C2",
    category: "dorm",
  },
  Tiwson: {
    id: "Tiwson",
    nameEn: "Tiwson Canteen",
    nameTh: "โรงอาหารทิวสน",
    lon: 100.595887,
    lat: 14.0764,
    weight: 0,
    desc: "ป้ายโรงอาหารทิวสน",
    category: "recreation",
  },
  Top: {
    id: "Top",
    nameEn: "Top",
    nameTh: "Top",
    lon: 100.596115,
    lat: 14.076427,
    weight: 0,
    desc: "ป้าย Top",
    category: "recreation",
  },
  Station11: {
    id: "Station11",
    nameEn: "Stadium / opposite Social Sciences (Station 11)",
    nameTh: "ตรงข้ามอาคารเรียนรวมสังคมศาสตร์ (Station 11)",
    lon: 100.601663,
    lat: 14.06969,
    weight: 0,
    desc: "สนามกีฬา / ตรงข้ามอาคารเรียนรวมสังคมศาสตร์",
    category: "recreation",
  },
  PublicBusStop: {
    id: "PublicBusStop",
    nameEn: "Public bus stop",
    nameTh: "ป้ายรถโดยสารประจำทาง",
    lon: 100.601625,
    lat: 14.07566,
    weight: 0,
    desc: "ป้ายรถโดยสารประจำทาง",
    category: "transit",
  },
  Stadium: {
    id: "Stadium",
    nameEn: "Gymnasium 7 (Station 30)",
    nameTh: "ยิมเนเซียม 7",
    lon: 100.601191,
    lat: 14.07049,
    weight: 0,
    desc: "ยิมเนเซียม 7",
    category: "recreation",
  },
  Stadium_Opp: {
    id: "Stadium_Opp",
    nameEn: "Opposite Gymnasium 7",
    nameTh: "ตรงข้ามยิมเนเซียม 7",
    lon: 100.601191,
    lat: 14.07049,
    weight: 0,
    desc: "ตรงข้ามยิมเนเซียม 7",
    category: "recreation",
  },
  Library_Opp: {
    id: "Library_Opp",
    nameEn: "Opposite Puey Library (front)",
    nameTh: "ตรงข้ามหน้าหอสมุดป๋วย",
    lon: 100.60164,
    lat: 14.071229,
    weight: 0,
    desc: "ตรงข้ามหน้าหอสมุดป๋วย",
    category: "academic",
  },
  SC1_Opp: {
    id: "SC1_Opp",
    nameEn: "Science Complex 1 (opposite)",
    nameTh: "อาคาร SC1 (ฝั่งตรงข้าม)",
    lon: 100.604252,
    lat: 14.069462,
    weight: 0,
    desc: "อาคาร SC1 (ฝั่งตรงข้าม)",
    category: "academic",
  },
  Park_Opp: {
    id: "Park_Opp",
    nameEn: "Puey 100-Year Park (opposite)",
    nameTh: "อุทยานเรียนรู้ 100 ปี (ฝั่งตรงข้าม)",
    lon: 100.611659,
    lat: 14.07218,
    weight: 0,
    desc: "อุทยานเรียนรู้ 100 ปี (ฝั่งตรงข้าม)",
    category: "recreation",
  },
  Terminal_Opp: {
    id: "Terminal_Opp",
    nameEn: "SIIT / opposite Bus Terminal",
    nameTh: "SIIT / ตรงข้ามสถานีขนส่ง",
    lon: 100.60719,
    lat: 14.067435,
    weight: 0,
    desc: "SIIT / ตรงข้ามสถานีขนส่ง",
    category: "transit",
  },
  Health_Opp: {
    id: "Health_Opp",
    nameEn: "Public Health Building (opposite)",
    nameTh: "อาคารสาธารณสุขศาสตร์ (ฝั่งตรงข้าม)",
    lon: 100.612871,
    lat: 14.072208,
    weight: 0,
    desc: "อาคารสาธารณสุขศาสตร์ (ฝั่งตรงข้าม)",
    category: "academic",
  },
  Dorm_C9_Opp: {
    id: "Dorm_C9_Opp",
    nameEn: "Dormitory row C9 (opposite)",
    nameTh: "หอใน แถว C9 (ฝั่งตรงข้าม)",
    lon: 100.596924,
    lat: 14.072535,
    weight: 0,
    desc: "หอใน แถว C9 (ฝั่งตรงข้าม)",
    category: "dorm",
  },
  Dorm_C5_Opp: {
    id: "Dorm_C5_Opp",
    nameEn: "Dormitory row C5 (opposite)",
    nameTh: "หอใน แถว C5 (ฝั่งตรงข้าม)",
    lon: 100.596717,
    lat: 14.074294,
    weight: 0,
    desc: "หอใน แถว C5 (ฝั่งตรงข้าม)",
    category: "dorm",
  },
  Dorm_C2_Opp: {
    id: "Dorm_C2_Opp",
    nameEn: "Dormitory row C2 (opposite)",
    nameTh: "หอใน แถว C2 (ฝั่งตรงข้าม)",
    lon: 100.596687,
    lat: 14.075267,
    weight: 0,
    desc: "หอใน แถว C2 (ฝั่งตรงข้าม)",
    category: "dorm",
  },
  Dorm_C1: {
    id: "Dorm_C1",
    nameEn: "Dormitory C1",
    nameTh: "หอพัก C1",
    lon: 100.597287,
    lat: 14.076238,
    weight: 0,
    desc: "หอพัก C1 (ตรงข้ามอาคารยิมเนเซียมอินเตอร์โซน)",
    category: "dorm",
  },
  Station17: {
    id: "Station17",
    nameEn: "Interzone gymnasium (Station 17)",
    nameTh: "อาคารยิมเนเซียมอินเตอร์โซน",
    lon: 100.597263,
    lat: 14.076327,
    weight: 0,
    desc: "อาคารยิมเนเซียมอินเตอร์โซน",
    category: "recreation",
  },
  Station18: {
    id: "Station18",
    nameEn: "TU Kindergarten (Station 18)",
    nameTh: "หน้าโรงเรียนอนุบาลธรรมศาสตร์",
    lon: 100.599095,
    lat: 14.076219,
    weight: 0,
    desc: "หน้าโรงเรียนอนุบาลธรรมศาสตร์",
    category: "academic",
  },
  Station13: {
    id: "Station13",
    nameEn: "Puey Ungphakorn School of Development Studies (Station 13)",
    nameTh: "ป้ายวิทยาลัยพัฒนศาสตร์ ป๋วย อึ๊งภากรณ์",
    lon: 100.60112,
    lat: 14.076032,
    weight: 0,
    desc: "ป้ายวิทยาลัยพัฒนศาสตร์ ป๋วย อึ๊งภากรณ์",
    category: "academic",
  },
  Station19: {
    id: "Station19",
    nameEn: "TU Primary School (Station 19)",
    nameTh: "ป้ายโรงเรียนประถม มธ.",
    lon: 100.600076,
    lat: 14.076174,
    weight: 0,
    desc: "ป้ายโรงเรียนประถม มธ.",
    category: "academic",
  },
  Station18_Opp: {
    id: "Station18_Opp",
    nameEn: "Opposite TU Kindergarten",
    nameTh: "ตรงข้ามโรงเรียนอนุบาลธรรมศาสตร์",
    lon: 100.599099,
    lat: 14.076123,
    weight: 0,
    desc: "ตรงข้ามโรงเรียนอนุบาลธรรมศาสตร์",
    category: "academic",
  },
  Gate2: {
    id: "Gate2",
    nameEn: "Chiang Rak Gate 2",
    nameTh: "ประตูเชียงราก 2",
    lon: 100.611244,
    lat: 14.066826,
    weight: 0,
    desc: "ประตูเชียงราก 2",
    category: "transit",
  },
  VanStop: {
    id: "VanStop",
    nameEn: "TU van terminal",
    nameTh: "ท่ารถตู้",
    lon: 100.607743,
    lat: 14.067426,
    weight: 0,
    desc: "ท่ารถตู้",
    category: "transit",
  },
  VanStop_Opp: {
    id: "VanStop_Opp",
    nameEn: "Opposite TU van terminal",
    nameTh: "ตรงข้ามท่ารถตู้",
    lon: 100.607741,
    lat: 14.067426,
    weight: 0,
    desc: "ตรงข้ามท่ารถตู้",
    category: "transit",
  },
  Theater_Opp: {
    id: "Theater_Opp",
    nameEn: "Opposite Journalism Theater",
    nameTh: "ตรงข้ามโรงภาพยนตร์วารสารศาสตร์",
    lon: 100.605398,
    lat: 14.067852,
    weight: 0,
    desc: "ตรงข้ามโรงภาพยนตร์วารสารศาสตร์",
    category: "academic",
  },
  Engineering_Side: {
    id: "Engineering_Side",
    nameEn: "Side of the Faculty of Engineering",
    nameTh: "ด้านข้างคณะวิศวกรรมศาสตร์",
    lon: 100.605328,
    lat: 14.069032,
    weight: 0,
    desc: "ด้านข้างคณะวิศวกรรมศาสตร์",
    category: "academic",
  },
  LSED: {
    id: "LSED",
    nameEn: "Faculty of Learning Sciences and Education",
    nameTh: "คณะวิทยาการเรียนรู้และศึกษาศาสตร์",
    lon: 100.604591,
    lat: 14.071766,
    weight: 0,
    desc: "คณะวิทยาการเรียนรู้และศึกษาศาสตร์",
    category: "academic",
  },
  LSED_Opp: {
    id: "LSED_Opp",
    nameEn: "Opposite Faculty of Learning Sciences and Education",
    nameTh: "ตรงข้ามคณะวิทยาการเรียนรู้และศึกษาศาสตร์",
    lon: 100.604591,
    lat: 14.071764,
    weight: 0,
    desc: "ตรงข้ามคณะวิทยาการเรียนรู้และศึกษาศาสตร์",
    category: "academic",
  },
  Vitthaya_Opp: {
    id: "Vitthaya_Opp",
    nameEn: "Opposite Witthayaborikan Building",
    nameTh: "ตรงข้ามอาคารวิทยบริการ",
    lon: 100.605202,
    lat: 14.072121,
    weight: 0,
    desc: "ตรงข้ามอาคารวิทยบริการ",
    category: "academic",
  },
  Vitthaya: {
    id: "Vitthaya",
    nameEn: "Witthayaborikan Building",
    nameTh: "อาคารวิทยบริการ",
    lon: 100.605201,
    lat: 14.072121,
    weight: 0,
    desc: "อาคารวิทยบริการ",
    category: "academic",
  },
  TUConvention: {
    id: "TUConvention",
    nameEn: "TU Convention Centre",
    nameTh: "ศูนย์ประชุม มธ.",
    lon: 100.616138,
    lat: 14.068996,
    weight: 0,
    desc: "ศูนย์ประชุม มธ.",
    category: "academic",
  },
  ResearchCenter: {
    id: "ResearchCenter",
    nameEn: "Advanced Research Center",
    nameTh: "ศูนย์วิจัยขั้นสูง",
    lon: 100.613689,
    lat: 14.0688,
    weight: 0,
    desc: "ศูนย์วิจัยขั้นสูง (สาย 2 ขากลับเข้าจุดพักรถ)",
    category: "academic",
  },
  TUMuseum: {
    id: "TUMuseum",
    nameEn: "Thammasat University Museum",
    nameTh: "พิพิธภัณฑ์ธรรมศาสตร์เฉลิมพระเกียรติ",
    lon: 100.604127,
    lat: 14.070269,
    weight: 0,
    desc: "พิพิธภัณฑ์ธรรมศาสตร์เฉลิมพระเกียรติ",
    category: "academic",
  },
  Registrar: {
    id: "Registrar",
    nameEn: "Student Registrar Office",
    nameTh: "สำนักงานทะเบียนนักศึกษา",
    lon: 100.602158,
    lat: 14.070266,
    weight: 0,
    desc: "สำนักงานทะเบียนนักศึกษา",
    category: "academic",
  },
  PueyMonument: {
    id: "PueyMonument",
    nameEn: "Prof. Dr. Puey Ungphakorn Monument",
    nameTh: "อนุสาวรีย์ ศ.ดร.ป๋วย อึ๊งภากรณ์",
    lon: 100.602368,
    lat: 14.070267,
    weight: 0,
    desc: "อนุสาวรีย์ ศ.ดร.ป๋วย อึ๊งภากรณ์",
    category: "academic",
  },
  StaffDorm_Opp: {
    id: "StaffDorm_Opp",
    nameEn: "Opposite 14-storey staff dormitory",
    nameTh: "ตรงข้ามหอพักบุคลากร 14 ชั้น",
    lon: 100.598191,
    lat: 14.07124,
    weight: 0,
    desc: "ตรงข้ามหอพักบุคลากร 14 ชั้น",
    category: "dorm",
  },
  DomeAdmin: {
    id: "DomeAdmin",
    nameEn: "Dome Administration building (Station 3)",
    nameTh: "อาคารโดมบริหาร",
    lon: 100.601627,
    lat: 14.07438,
    weight: 0,
    desc: "อาคารโดมบริหาร",
    category: "academic",
  },
  NSTDA: {
    id: "NSTDA",
    nameEn: "NSTDA stop (Station 1)",
    nameTh: "ป้ายสวทช",
    lon: 100.601629,
    lat: 14.075349,
    weight: 0,
    desc: "ป้ายสวทช",
    category: "academic",
  },
  Gym45: {
    id: "Gym45",
    nameEn: "Gymnasium 4-5 (stadium stop)",
    nameTh: "ยิม 4-5 (สนามกีฬา)",
    lon: 100.604715,
    lat: 14.067457,
    weight: 0,
    desc: "ยิม 4-5 (สนามกีฬา)",
    category: "recreation",
  },
  LawOpp: {
    id: "LawOpp",
    nameEn: "Opposite Law building (stadium stop)",
    nameTh: "ตรงข้ามตึกนิติศาสตร์ (สนามกีฬา)",
    lon: 100.603515,
    lat: 14.067471,
    weight: 0,
    desc: "ตรงข้ามตึกนิติศาสตร์ (สนามกีฬา)",
    category: "recreation",
  },
  JCTheater: {
    id: "JCTheater",
    nameEn: "JC Theater (opposite Gym 4-5)",
    nameTh: "JC Theater (ตรงข้ามยิม 4-5)",
    lon: 100.604156,
    lat: 14.067457,
    weight: 0,
    desc: "JC Theater (ตรงข้ามยิม 4-5)",
    category: "recreation",
  },
  Station6: {
    id: "Station6",
    nameEn: "Law building (Station 6)",
    nameTh: "ป้ายตึกนิติศาสตร์ (Station 6)",
    lon: 100.603101,
    lat: 14.067476,
    weight: 0,
    desc: "ป้ายหน้าตึกนิติศาสตร์ ฝั่งเหนือของถนนสัญญา ธรรมศักดิ์",
    category: "recreation",
  },
  DomeAdmin_Opp: {
    id: "DomeAdmin_Opp",
    nameEn: "Dome Administration building (opposite)",
    nameTh: "อาคารโดมบริหาร (ฝั่งตรงข้าม)",
    lon: 100.601627,
    lat: 14.07438,
    weight: 0,
    desc: "อาคารโดมบริหาร (ฝั่งตรงข้าม)",
    category: "academic",
  },
  SC2: {
    id: "SC2",
    nameEn: "SC2 stop (in front of SC2)",
    nameTh: "ป้าย SC2 (หน้าตึก SC2)",
    lon: 100.604594,
    lat: 14.070692,
    weight: 0,
    desc: "ป้าย SC2 (หน้าตึก SC2)",
    category: "academic",
  },
  TUPress: {
    id: "TUPress",
    nameEn: "TU Printing House (Station 7)",
    nameTh: "โรงพิมพ์ มธ.",
    lon: 100.609203,
    lat: 14.067415,
    weight: 0,
    desc: "โรงพิมพ์ มธ. (ตรงข้ามคณะสถาปัตยกรรมศาสตร์)",
    category: "academic",
  },
  Arch: {
    id: "Arch",
    nameEn: "Faculty of Architecture",
    nameTh: "คณะสถาปัตยกรรมศาสตร์",
    lon: 100.60922,
    lat: 14.067415,
    weight: 0,
    desc: "คณะสถาปัตยกรรมศาสตร์ (ตรงข้ามโรงพิมพ์ มธ.)",
    category: "academic",
  },
  Engineering: {
    id: "Engineering",
    nameEn: "Faculty of Engineering",
    nameTh: "คณะวิศวกรรมศาสตร์",
    lon: 100.605752,
    lat: 14.067448,
    weight: 0,
    desc: "คณะวิศวกรรมศาสตร์",
    category: "academic",
  },
  Station8: {
    id: "Station8",
    nameEn: "Opposite Faculty of Engineering (Station 8)",
    nameTh: "ตรงข้ามคณะวิศวกรรมศาสตร์ (Station 8)",
    lon: 100.605812,
    lat: 14.067447,
    weight: 0,
    desc: "ตรงข้ามคณะวิศวกรรมศาสตร์ (Station 8)",
    category: "academic",
  },
  Dome_Opp: {
    id: "Dome_Opp",
    nameEn: "Opposite TU Dome (route 3 drop-off)",
    nameTh: "ตรงข้าม TU Dome (จุดลงปลายสาย 3)",
    lon: 100.60039,
    lat: 14.065989,
    weight: 0,
    desc: "ตรงข้าม TU Dome (จุดลงปลายสาย 3)",
    category: "transit",
  },
  Rest3: {
    id: "Rest3",
    nameEn: "Stadium 2 Parking, route 3 rest point (no passengers)",
    nameTh: "Stadium 2 Parking จุดพักรถสาย 3 (ไม่รับส่งผู้โดยสาร)",
    lon: 100.599013,
    lat: 14.066801,
    weight: 0,
    desc: "Google Maps (user); route 3 rests here between loops - no boarding or alighting",
    category: "transit",
  },
  Gate1_Opp: {
    id: "Gate1_Opp",
    nameEn: "Opposite Chiang Rak Gate 1",
    nameTh: "ตรงข้ามประตูเชียงราก 1",
    lon: 100.605195,
    lat: 14.066285,
    weight: 0,
    desc: "ป้ายเลนขาออก ตรงข้ามประตูเชียงราก 1",
    category: "transit",
  },
};

export const ROUTE_COLORS = [
  { stroke: "#2563eb", bg: "bg-blue-600", text: "text-blue-600", border: "border-blue-500", name: "Blue" },
  { stroke: "#9333ea", bg: "bg-purple-600", text: "text-purple-600", border: "border-purple-500", name: "Purple" },
  { stroke: "#059669", bg: "bg-emerald-600", text: "text-emerald-600", border: "border-emerald-500", name: "Emerald" },
  { stroke: "#d97706", bg: "bg-amber-600", text: "text-amber-600", border: "border-amber-500", name: "Amber" },
  { stroke: "#e11d48", bg: "bg-rose-600", text: "text-rose-600", border: "border-rose-500", name: "Rose" },
  { stroke: "#0891b2", bg: "bg-cyan-600", text: "text-cyan-600", border: "border-cyan-500", name: "Cyan" },
];

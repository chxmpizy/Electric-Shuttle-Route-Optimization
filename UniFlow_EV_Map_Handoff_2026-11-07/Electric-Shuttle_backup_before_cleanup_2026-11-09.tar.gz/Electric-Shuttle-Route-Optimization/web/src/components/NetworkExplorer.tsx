"use client";

import dynamic from "next/dynamic";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { CAMPUS_STOPS, RouteSchedule } from "@/types/shuttle";
import {
  busPositions,
  cyclePeriod,
  fmtClock,
  NETWORK,
  NetRoute,
  RoadLegs,
  routeColor,
  routesFromSchedule,
} from "@/lib/osmNetwork";

const NetworkMap = dynamic(() => import("@/components/NetworkMap"), {
  ssr: false,
  loading: () => (
    <div className="h-full flex items-center justify-center text-[13px] text-neutral-500">
      กำลังโหลดแผนที่…
    </div>
  ),
});

const SPEEDS = [1, 10, 30, 60];

function stopName(id: string): string {
  return CAMPUS_STOPS[id]?.nameTh ?? id;
}

interface Props {
  /** One column (map above the lists), for narrow pages such as /u. */
  stacked?: boolean;
  /** An optimiser's routes to draw. Leave out to show the 3-route baseline. */
  schedule?: RouteSchedule[];
  /** Which routes are shown, e.g. "Baseline" or "GA". */
  label?: string;
}

// The road table is large and only optimiser routes need it, so it loads once on demand.
let roadLegsRequest: Promise<RoadLegs> | null = null;
function loadRoadLegs(): Promise<RoadLegs> {
  roadLegsRequest ??= fetch("/data/road_legs.json").then((res) => res.json());
  return roadLegsRequest;
}

const NO_ROUTES: NetRoute[] = [];

/** The EV network on OSM roads with animated buses: the baseline, or an optimiser's routes. */
export default function NetworkExplorer({ stacked = false, schedule, label = "Baseline" }: Props) {
  const [roads, setRoads] = useState<RoadLegs | null>(null);
  useEffect(() => {
    if (schedule) loadRoadLegs().then(setRoads);
  }, [schedule]);
  const routes = useMemo(() => {
    if (!schedule) return NETWORK.baselineRoutes;
    return roads ? routesFromSchedule(schedule, roads) : NO_ROUTES;
  }, [schedule, roads]);
  const tMin = routes.length ? Math.min(...routes.map((r) => r.startTime)) : 420;
  const tMax = routes.length ? Math.max(...routes.map((r) => r.endTime)) : 1260;

  const [simTime, setSimTime] = useState(480); // 08:00
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(30); // sim minutes per real minute → see tick below
  const [hidden, setHidden] = useState<Set<number>>(() => new Set());
  const [shownRoutes, setShownRoutes] = useState(routes);
  if (shownRoutes !== routes) {
    setShownRoutes(routes);
    setHidden(new Set());
  }
  const visible = useMemo(() => new Set(routes.map((r) => r.id).filter((id) => !hidden.has(id))), [routes, hidden]);
  const [selectedStop, setSelectedStop] = useState<string | null>(null);
  const [stopsOnly, setStopsOnly] = useState(false);

  // Animation clock: `speed`x real time (1 real second = speed sim seconds).
  const last = useRef<number | null>(null);
  useEffect(() => {
    if (!playing) {
      last.current = null;
      return;
    }
    let raf = 0;
    const tick = (now: number) => {
      if (last.current !== null) {
        const dtMin = ((now - last.current) / 60000) * speed;
        setSimTime((t) => (t + dtMin > tMax ? tMin : t + dtMin));
      }
      last.current = now;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, speed, tMin, tMax]);

  const buses = useMemo(() => routes.flatMap((r) => busPositions(r, simTime)), [routes, simTime]);
  const stops = useMemo(
    () => NETWORK.stops.map((s) => ({ ...s, routes: routes.filter((r) => r.path.includes(s.id)).map((r) => r.id) })),
    [routes]
  );
  const stopNumber = useMemo(() => new Map(NETWORK.stops.map((s, i) => [s.id, i + 1])), []);
  const totalBuses = routes.reduce((s, r) => s + r.numBus, 0);
  const totalKm = routes.reduce((s, r) => s + r.totalKm, 0);
  const runningByRoute = useMemo(() => {
    const m = new Map<number, number>();
    for (const b of buses) m.set(b.routeId, (m.get(b.routeId) ?? 0) + 1);
    return m;
  }, [buses]);
  const busesAtSelected = selectedStop ? buses.filter((b) => b.atStop === selectedStop) : [];

  const toggleRoute = (id: number) =>
    setHidden((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const stats = [
    { label: "ป้ายรถทั้งหมด", value: `${NETWORK.stops.length}`, unit: "ป้าย" },
    { label: `สายรถ · ${label}`, value: `${routes.length}`, unit: "สาย" },
    { label: "รถกำลังให้บริการ", value: `${buses.length}`, unit: `/ ${totalBuses} คัน` },
    { label: "ระยะทางรวมทุกสาย", value: totalKm.toFixed(1), unit: "กม. / รอบ" },
  ];

  return (
    <div className="space-y-4">
      <section className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-neutral-200 bg-white px-4 py-3">
            <div className="text-[12px] text-neutral-500">{s.label}</div>
            <div className="mt-1 flex items-baseline gap-1.5">
              <span className="text-[26px] font-semibold tabular-nums">{s.value}</span>
              <span className="text-[12px] text-neutral-500">{s.unit}</span>
            </div>
          </div>
        ))}
      </section>

      <section className="rounded-xl border border-neutral-200 bg-white px-4 py-3 flex flex-wrap items-center gap-3">
        <div className="flex rounded-lg border border-neutral-200 p-0.5 text-[13px]">
          {[
            { v: true, label: "ป้ายอย่างเดียว" },
            { v: false, label: "ป้าย + สาย + รถ" },
          ].map((o) => (
            <button
              key={o.label}
              onClick={() => setStopsOnly(o.v)}
              className={`rounded-md px-3 py-1 ${
                stopsOnly === o.v ? "bg-neutral-900 text-white" : "text-neutral-600"
              }`}
            >
              {o.label}
            </button>
          ))}
        </div>
        {stopsOnly ? (
          <p className="text-[12px] text-neutral-600 flex-1">
            <span className="text-neutral-900">●</span> ดำ = ยืนยันพิกัดจาก Google Maps แล้ว ·{" "}
            <span className="text-orange-600">●</span> ส้ม = ยังใช้พิกัดเดิม (ยังไม่ยืนยัน) · ○ เทา =
            จุดที่ปักไว้ก่อนย้ายลงถนน · คลิกที่ป้ายเพื่อดูรายละเอียด
          </p>
        ) : (
        <>
        <button
          onClick={() => setPlaying((p) => !p)}
          className="rounded-lg bg-neutral-900 text-white text-[13px] px-3 py-1.5 min-w-[72px]"
        >
          {playing ? "หยุด" : "เล่น"}
        </button>
        <span className="font-mono text-[20px] tabular-nums w-[64px]">{fmtClock(simTime)}</span>
        <input
          type="range"
          min={tMin}
          max={tMax}
          step={0.5}
          value={simTime}
          onChange={(e) => setSimTime(Number(e.target.value))}
          className="flex-1 min-w-[160px] accent-neutral-900"
          aria-label="เวลาจำลอง"
        />
        <div className="flex items-center gap-1 text-[12px]">
          <span className="text-neutral-500 mr-1">ความเร็ว</span>
          {SPEEDS.map((s) => (
            <button
              key={s}
              onClick={() => setSpeed(s)}
              className={`rounded-md px-2 py-1 border ${
                speed === s ? "bg-neutral-900 text-white border-neutral-900" : "border-neutral-200"
              }`}
            >
              ×{s}
            </button>
          ))}
        </div>
        </>
        )}
      </section>

      <section className={`grid gap-4 ${stacked ? "" : "lg:grid-cols-[1fr_320px]"}`}>
        <div className={`rounded-xl border border-neutral-200 bg-white overflow-hidden ${stacked ? "h-[480px] md:h-[560px]" : "h-[560px] lg:h-[680px]"}`}>
          <NetworkMap
            routes={routes}
            stops={stops}
            buses={buses}
            visibleRoutes={visible}
            stopNumber={stopNumber}
            selectedStop={selectedStop}
            onSelectStop={setSelectedStop}
            stopsOnly={stopsOnly}
          />
        </div>

        <aside className="space-y-4">
          <div className={`rounded-xl border border-neutral-200 bg-white ${stopsOnly ? "hidden" : ""}`}>
            <div className="px-4 py-2.5 border-b border-neutral-100 text-[13px] font-medium">
              สายรถ (คลิกเพื่อซ่อน/แสดง)
            </div>
            <ul className="divide-y divide-neutral-100">
              {routes.map((r) => {
                const on = visible.has(r.id);
                return (
                  <li key={r.id}>
                    <button
                      onClick={() => toggleRoute(r.id)}
                      className={`w-full text-left px-4 py-2.5 ${on ? "" : "opacity-40"}`}
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className="inline-flex h-5 min-w-5 px-1 items-center justify-center rounded-full text-[11px] font-bold text-white"
                          style={{ background: routeColor(r) }}
                        >
                          {r.name}
                        </span>
                        <span className="text-[13px] font-medium">สาย {r.name}</span>
                        <span className="ml-auto text-[12px] tabular-nums text-neutral-500">
                          วิ่งอยู่ {runningByRoute.get(r.id) ?? 0}/{r.numBus} คัน
                        </span>
                      </div>
                      <div className="mt-1 text-[11.5px] text-neutral-600 leading-snug">
                        {r.path.map((s) => stopNumber.get(s)).join(" → ")}
                      </div>
                      <div className="mt-0.5 text-[11px] text-neutral-500 tabular-nums">
                        {r.totalKm.toFixed(2)} กม. · รอบละ {cyclePeriod(r).toFixed(1)} นาที · ทุก{" "}
                        {(cyclePeriod(r) / r.numBus).toFixed(1)} นาที · {fmtClock(r.startTime)}–
                        {fmtClock(r.endTime)}
                      </div>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>

          <div className="rounded-xl border border-neutral-200 bg-white">
            <div className="px-4 py-2.5 border-b border-neutral-100 text-[13px] font-medium">
              ป้ายรถ {NETWORK.stops.length} ป้าย
            </div>
            <ul className={`${stopsOnly ? "max-h-[620px]" : "max-h-[300px]"} overflow-y-auto divide-y divide-neutral-100`}>
              {stops.map((s) => (
                <li key={s.id}>
                  <button
                    onClick={() => setSelectedStop(selectedStop === s.id ? null : s.id)}
                    className={`w-full text-left px-4 py-2 flex items-center gap-2 ${
                      selectedStop === s.id ? "bg-neutral-100" : ""
                    }`}
                  >
                    <span
                      className={`inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10.5px] font-bold text-white ${
                        s.verified ? "bg-neutral-900" : "bg-orange-600"
                      }`}
                    >
                      {stopNumber.get(s.id)}
                    </span>
                    <span className="text-[12.5px] flex-1 leading-snug">
                      {stopName(s.id)}
                      {!s.verified && <span className="ml-1 text-[11px] text-orange-600">ยังไม่ยืนยัน</span>}
                      {!s.passengers && <span className="ml-1 text-[11px] text-neutral-500">จุดพักรถ · ไม่รับส่งผู้โดยสาร</span>}
                    </span>
                    <span className="flex gap-0.5">
                      {s.routes.length === 0 && (
                        <span className="text-[11px] text-neutral-400">ไม่มีสาย</span>
                      )}
                      {routes.filter((r) => s.routes.includes(r.id)).map((r) => (
                        <span
                          key={r.id}
                          className="h-2.5 w-2.5 rounded-full"
                          style={{ background: routeColor(r) }}
                          title={`สาย ${r.name}`}
                        />
                      ))}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
            {selectedStop && (
              <div className="border-t border-neutral-100 px-4 py-2.5 text-[12px] text-neutral-600">
                {busesAtSelected.length > 0
                  ? `ตอนนี้มีรถจอดอยู่ ${busesAtSelected.length} คัน (สาย ${[
                      ...new Set(busesAtSelected.map((b) => b.routeName)),
                    ].join(", ")})`
                  : "ตอนนี้ไม่มีรถจอดที่ป้ายนี้"}
              </div>
            )}
          </div>
        </aside>
      </section>
    </div>
  );
}

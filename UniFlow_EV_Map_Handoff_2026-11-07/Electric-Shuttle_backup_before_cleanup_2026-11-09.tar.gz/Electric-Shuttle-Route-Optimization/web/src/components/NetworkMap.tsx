"use client";

import L from "leaflet";
import React, { useEffect, useMemo } from "react";
import {
  CircleMarker,
  MapContainer,
  Marker,
  Polyline,
  Popup,
  TileLayer,
  Tooltip,
  useMap,
} from "react-leaflet";
import { CAMPUS_STOPS } from "@/types/shuttle";
import { BusPosition, NETWORK, NetRoute, NetStop, routeColor } from "@/lib/osmNetwork";

interface Props {
  routes: NetRoute[];
  stops: NetStop[];
  buses: BusPosition[];
  visibleRoutes: Set<number>;
  stopNumber: Map<string, number>;
  selectedStop: string | null;
  onSelectStop: (id: string | null) => void;
  /** Stops-only view: name labels, details popup, and the original (pre-snap) positions. */
  stopsOnly?: boolean;
}

// Fit the map to every stop and every route line.
const BOUNDS = L.latLngBounds([
  ...NETWORK.stops.map((s) => [s.lat, s.lon] as [number, number]),
  ...NETWORK.baselineRoutes.flatMap((r) => r.legs.flatMap((l) => l.coords)),
]);

// The map can mount while its container has no size yet (e.g. a hidden tab or
// pane), which makes the initial fit zoom far out. Refit until the user moves it.
function FitToNetwork() {
  const map = useMap();
  useEffect(() => {
    let userMoved = false;
    const markMoved = () => (userMoved = true);
    map.on("zoomstart", markMoved);
    map.on("dragstart", markMoved);
    const el = map.getContainer();
    const ro = new ResizeObserver(() => {
      map.invalidateSize();
      if (!userMoved && el.clientWidth > 0 && el.clientHeight > 0) {
        map.fitBounds(BOUNDS, { padding: [24, 24], animate: false });
        userMoved = false; // fitBounds itself fires zoomstart
      }
    });
    ro.observe(el);
    return () => {
      ro.disconnect();
      map.off("zoomstart", markMoved);
      map.off("dragstart", markMoved);
    };
  }, [map]);
  return null;
}

// Snapped stops sit on the road centreline, so stops facing each other across a
// road would overlap. Draw one-direction stops a few metres toward their own kerb.
const KERB_OFFSET_M = 6;
function displayPos(s: NetStop): [number, number] {
  if (s.bothDirections || s.snapM <= 0) return [s.lat, s.lon];
  const f = Math.min(1, KERB_OFFSET_M / s.snapM);
  return [s.lat + (s.originalLat - s.lat) * f, s.lon + (s.originalLon - s.lon) * f];
}

const ICON_CACHE = new Map<string, L.DivIcon>();
function busIcon(bus: BusPosition, dwelling: boolean): L.DivIcon {
  const key = `${bus.routeName}-${bus.color}-${dwelling}`;
  let icon = ICON_CACHE.get(key);
  if (!icon) {
    icon = L.divIcon({
      className: "net-bus-marker",
      html: `<div class="net-bus ${dwelling ? "net-bus-dwell" : ""}" style="--c:${bus.color}">${bus.routeName}</div>`,
      iconSize: [22, 22],
      iconAnchor: [11, 11],
    });
    ICON_CACHE.set(key, icon);
  }
  return icon;
}

const STATE_TH: Record<BusPosition["state"], string> = {
  driving: "กำลังวิ่ง",
  dwell: "จอดรับ-ส่ง",
  layover: "พักปลายสาย",
};

function stopName(id: string): string {
  return CAMPUS_STOPS[id]?.nameTh ?? id;
}

export default function NetworkMap({
  routes: allRoutes,
  stops,
  buses,
  visibleRoutes,
  stopNumber,
  selectedStop,
  onSelectStop,
  stopsOnly = false,
}: Props) {
  const routes = useMemo(
    () => (stopsOnly ? [] : allRoutes.filter((r) => visibleRoutes.has(r.id))),
    [allRoutes, visibleRoutes, stopsOnly]
  );

  return (
    <MapContainer bounds={BOUNDS} boundsOptions={{ padding: [24, 24] }} scrollWheelZoom className="h-full w-full">
      <TileLayer
        url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        maxZoom={19}
      />
      <FitToNetwork />

      {routes.map((r) =>
        r.legs.map((leg, i) => (
          <Polyline
            key={`${r.id}-${i}`}
            positions={leg.coords}
            pathOptions={{ color: routeColor(r), weight: 5, opacity: 0.65 }}
          >
            <Tooltip sticky>
              สาย {r.name}: {stopName(leg.from)} → {stopName(leg.to)} · {leg.km.toFixed(2)} กม. · {leg.minutes.toFixed(1)} นาที
            </Tooltip>
          </Polyline>
        ))
      )}

      {stopsOnly &&
        stops.map((s) => (
          <React.Fragment key={`orig-${s.id}`}>
            <Polyline
              positions={[
                [s.originalLat, s.originalLon],
                displayPos(s),
              ]}
              pathOptions={{ color: "#6b7280", weight: 1.5, dashArray: "4 4" }}
            />
            <CircleMarker
              center={[s.originalLat, s.originalLon]}
              radius={5}
              pathOptions={{ color: "#6b7280", weight: 2, fillColor: "#ffffff", fillOpacity: 1 }}
            >
              <Tooltip>
                ตำแหน่งที่ปักไว้ของ {stopName(s.id)}
                {s.verified ? " (จาก Google Maps)" : " (พิกัดเดิมใน repo)"} · ห่างจากจุดบนถนน{" "}
                {s.snapM.toFixed(0)} ม.
              </Tooltip>
            </CircleMarker>
          </React.Fragment>
        ))}

      {stops.map((s) => {
        const selected = selectedStop === s.id;
        const n = stopNumber.get(s.id);
        const pos = displayPos(s);
        const info = CAMPUS_STOPS[s.id];
        return (
          <CircleMarker
            key={`${s.id}-${stopsOnly}`}
            center={pos}
            radius={selected ? 11 : 9}
            pathOptions={{
              color: selected ? "#111827" : "#ffffff",
              weight: selected ? 3 : 2,
              fillColor: !s.passengers ? "#9ca3af" : s.verified ? "#111827" : "#ea580c",
              fillOpacity: 0.9,
            }}
            eventHandlers={{ click: () => onSelectStop(selected ? null : s.id) }}
          >
            {stopsOnly ? (
              <>
                <Tooltip permanent direction="right" offset={[10, 0]} className="net-stop-label">
                  <b>{n}</b> {stopName(s.id)}
                </Tooltip>
                <Popup>
                  <div className="text-[13px] leading-relaxed">
                    <div className="font-semibold">
                      {n}. {stopName(s.id)}
                    </div>
                    {info && <div className="text-neutral-500">{info.nameEn}</div>}
                    {info?.desc && <div className="mt-1">{info.desc}</div>}
                    <div className="mt-1 text-neutral-600">
                      ชื่อในโค้ด: <code>{s.id}</code> · สายที่ผ่าน:{" "}
                      {s.routes.length ? s.routes.join(", ") : "ยังไม่มีสายผ่าน"}
                    </div>
                    <div className={s.verified ? "text-emerald-700" : "text-orange-600"}>
                      {s.verified ? "พิกัดยืนยันจาก Google Maps แล้ว" : "ยังใช้พิกัดเดิมใน repo — ยังไม่ได้ยืนยัน"}
                      {" · "}
                      {s.bothDirections ? "รถจอดได้ทั้งสองทิศ" : "รถจอดได้ทิศเดียว (ฝั่งซ้ายของทิศที่รถวิ่ง)"}
                    </div>
                    <div className="text-neutral-600">
                      พิกัดบนถนน: {s.lat.toFixed(5)}, {s.lon.toFixed(5)}
                    </div>
                    <div className="text-neutral-600">
                      พิกัดที่ปักไว้: {s.originalLat.toFixed(5)}, {s.originalLon.toFixed(5)} (ขยับ{" "}
                      {s.snapM.toFixed(0)} ม.)
                    </div>
                  </div>
                </Popup>
              </>
            ) : (
              <Tooltip permanent direction="center" className="net-stop-num">
                {n}
              </Tooltip>
            )}
          </CircleMarker>
        );
      })}

      {!stopsOnly &&
        buses
        .filter((b) => visibleRoutes.has(b.routeId))
        .map((b) => (
          <Marker
            key={`${b.routeId}-${b.busIdx}`}
            position={[b.lat, b.lng]}
            icon={busIcon(b, b.state !== "driving")}
            zIndexOffset={1000}
          >
            <Tooltip direction="top" offset={[0, -10]}>
              สาย {b.routeName} คันที่ {b.busIdx + 1} · {STATE_TH[b.state]}
              {b.atStop ? ` ที่ ${stopName(b.atStop)}` : ""} · ป้ายถัดไป {stopName(b.nextStop)}
            </Tooltip>
          </Marker>
        ))}
    </MapContainer>
  );
}
